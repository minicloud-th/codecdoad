import { SearchTool } from "@/components/ui/search-tool";

export default function Demo() {
  return (
    <div className="flex items-center justify-center w-full min-h-screen bg-background p-8 overflow-hidden">
      <div className="w-full max-w-md">
        <SearchTool state="searching" query="latest GPU benchmarks" />
      </div>
    </div>
  );
}
