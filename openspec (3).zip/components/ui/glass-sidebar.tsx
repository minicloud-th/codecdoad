"use client";

import * as React from "react";
import { HugeiconsIcon } from "@hugeicons/react";
import { PanelLeftIcon } from "@hugeicons/core-free-icons";
import { AnimatePresence, motion } from "motion/react";
import { Slot } from "radix-ui";

import { cn } from "@/lib/utils";
import { useActiveIndicator } from "@/components/ui/glass-sidebar-utils/use-active-indicator";
import { LiquidGlass } from "@/components/ui/glass-sidebar-utils/liquid-glass";
import { IOS_SNAPPY_SPRING, IOS_SPRING } from "@/src/motion";

type SidebarContextValue = {
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
};

const SidebarContext = React.createContext<SidebarContextValue>({
  collapsed: false,
  setCollapsed: () => {},
});

const useGlassSidebar = () => React.useContext(SidebarContext);

/** Floating glass source list with a sliding selection and icon-only mode. */
function GlassSidebar({
  className,
  children,
  collapsed: collapsedProp,
  defaultCollapsed = false,
  onCollapsedChange,
  ...props
}: React.ComponentProps<"aside"> & {
  collapsed?: boolean;
  defaultCollapsed?: boolean;
  onCollapsedChange?: (collapsed: boolean) => void;
}) {
  const [inner, setInner] = React.useState(defaultCollapsed);
  const collapsed = collapsedProp ?? inner;
  const setCollapsed = React.useCallback(
    (next: boolean) => {
      setInner(next);
      onCollapsedChange?.(next);
    },
    [onCollapsedChange],
  );
  const ref = React.useRef<HTMLDivElement>(null);
  const rect = useActiveIndicator(ref, '[aria-current="page"]');

  return (
    <SidebarContext.Provider value={{ collapsed, setCollapsed }}>
      <LiquidGlass
        asChild
        variant="frosted"
        className={cn(
          "flex h-full flex-col gap-1 overflow-hidden rounded-[26px] p-2 text-(--glass-foreground)",
          className,
        )}
      >
        <motion.aside
          data-slot="glass-sidebar"
          data-collapsed={collapsed || undefined}
          initial={false}
          animate={{ width: collapsed ? 60 : 240 }}
          transition={IOS_SPRING}
          {...(props as Record<string, unknown>)}
        >
          <div
            ref={ref}
            className="relative flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto overflow-x-hidden"
          >
            <AnimatePresence>
              {rect ? (
                <LiquidGlass
                  asChild
                  aria-hidden
                  shadow={false}
                  bezel={10}
                  tint="var(--glass-highlight)"
                  className="pointer-events-none absolute top-0 left-0 rounded-[14px]"
                >
                  <motion.div
                    initial={{
                      opacity: 0,
                      scale: 0.92,
                      x: rect.left,
                      y: rect.top,
                      width: rect.width,
                      height: rect.height,
                    }}
                    animate={{
                      opacity: 1,
                      scale: 1,
                      x: rect.left,
                      y: rect.top,
                      width: rect.width,
                      height: rect.height,
                    }}
                    exit={{ opacity: 0, scale: 0.92 }}
                    transition={IOS_SNAPPY_SPRING}
                  />
                </LiquidGlass>
              ) : null}
            </AnimatePresence>
            {children}
          </div>
        </motion.aside>
      </LiquidGlass>
    </SidebarContext.Provider>
  );
}

function GlassSidebarHeader({
  className,
  ...props
}: React.ComponentProps<"div">) {
  const { collapsed } = useGlassSidebar();
  return (
    <div
      data-slot="glass-sidebar-header"
      className={cn(
        "flex h-11 items-center gap-2",
        collapsed ? "justify-center" : "px-2",
        className,
      )}
      {...props}
    />
  );
}

function GlassSidebarGroup({
  className,
  label,
  children,
  ...props
}: React.ComponentProps<"div"> & { label?: string }) {
  const { collapsed } = useGlassSidebar();
  return (
    <div
      role="group"
      aria-label={label}
      data-slot="glass-sidebar-group"
      className={cn("flex flex-col gap-0.5 py-1", className)}
      {...props}
    >
      {label ? (
        <div
          className={cn(
            "h-6 truncate px-3 text-[11px] leading-6 font-semibold tracking-wide uppercase opacity-45 transition-opacity duration-200",
            collapsed && "opacity-0",
          )}
        >
          {label}
        </div>
      ) : null}
      {children}
    </div>
  );
}

function GlassSidebarItem({
  className,
  icon,
  active,
  badge,
  asChild,
  children,
  ...props
}: React.ComponentProps<"button"> & {
  icon?: React.ReactNode;
  active?: boolean;
  badge?: React.ReactNode;
  asChild?: boolean;
}) {
  const { collapsed } = useGlassSidebar();

  if (asChild) {
    return (
      <Slot.Root
        data-slot="glass-sidebar-item"
        aria-current={active ? "page" : undefined}
        title={collapsed && typeof children === "string" ? children : undefined}
        className={cn(
          "relative z-10 flex h-10 w-full cursor-pointer items-center gap-3 rounded-[14px] px-[11px] text-left text-[14px] font-medium tracking-[-0.01em] whitespace-nowrap opacity-75 transition-[opacity,background-color] duration-200 outline-none hover:opacity-100 focus-visible:ring-[3px] focus-visible:ring-ring/40 aria-[current=page]:opacity-100 [&_svg]:size-[18px] [&_svg]:shrink-0",
          !active && "hover:bg-(--glass-highlight)/50",
          collapsed && "justify-center px-0",
          className,
        )}
        {...props}
      >
        {icon}
        <Slot.Slottable>{children}</Slot.Slottable>
        {badge != null && !collapsed ? (
          <span className="rounded-full bg-(--glass-highlight) px-1.5 text-[11px] font-semibold tabular-nums">
            {badge}
          </span>
        ) : null}
      </Slot.Root>
    );
  }

  return (
    <motion.button
      data-slot="glass-sidebar-item"
      aria-current={active ? "page" : undefined}
      title={collapsed && typeof children === "string" ? children : undefined}
      whileTap={props.disabled ? undefined : { scale: 0.965 }}
      transition={IOS_SNAPPY_SPRING}
      className={cn(
        "relative z-10 flex h-10 w-full cursor-pointer items-center gap-3 rounded-[14px] px-[11px] text-left text-[14px] font-medium tracking-[-0.01em] whitespace-nowrap opacity-75 transition-[opacity,background-color] duration-200 outline-none hover:opacity-100 focus-visible:ring-[3px] focus-visible:ring-ring/40 aria-[current=page]:opacity-100 [&_svg]:size-[18px] [&_svg]:shrink-0",
        !active && "hover:bg-(--glass-highlight)/50",
        collapsed && "justify-center px-0",
        className,
      )}
      {...(props as Record<string, unknown>)}
    >
      {icon}
      <span
        className={cn(
          "flex-1 truncate transition-opacity duration-200",
          collapsed && "hidden",
        )}
      >
        {children}
      </span>
      <AnimatePresence>
        {badge != null && !collapsed ? (
          <motion.span
            key="badge"
            initial={{ scale: 0.7, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.7, opacity: 0 }}
            transition={IOS_SNAPPY_SPRING}
            className="rounded-full bg-(--glass-highlight) px-1.5 text-[11px] font-semibold tabular-nums"
          >
            {badge}
          </motion.span>
        ) : null}
      </AnimatePresence>
    </motion.button>
  );
}

function GlassSidebarFooter({
  className,
  ...props
}: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="glass-sidebar-footer"
      className={cn("mt-auto flex flex-col gap-1 pt-1", className)}
      {...props}
    />
  );
}

function GlassSidebarToggle({
  className,
  ...props
}: React.ComponentProps<"button">) {
  const { collapsed, setCollapsed } = useGlassSidebar();
  return (
    <motion.button
      type="button"
      data-slot="glass-sidebar-toggle"
      aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
      onClick={() => setCollapsed(!collapsed)}
      whileTap={{ scale: 0.9 }}
      transition={IOS_SNAPPY_SPRING}
      className={cn(
        "relative z-10 grid size-11 shrink-0 cursor-pointer place-items-center rounded-[14px] opacity-70 transition-[opacity,background-color] duration-200 outline-none hover:bg-(--glass-highlight)/50 hover:opacity-100 focus-visible:ring-[3px] focus-visible:ring-ring/40 [&_svg]:size-[18px]",
        !collapsed && "-ml-2.5",
        className,
      )}
      {...(props as Record<string, unknown>)}
    >
      <HugeiconsIcon icon={PanelLeftIcon} />
    </motion.button>
  );
}

export {
  GlassSidebar,
  GlassSidebarHeader,
  GlassSidebarGroup,
  GlassSidebarItem,
  GlassSidebarFooter,
  GlassSidebarToggle,
  useGlassSidebar,
};

export default GlassSidebar;
