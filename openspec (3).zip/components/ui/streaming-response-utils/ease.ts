export const EASE_OUT = [0.22, 1, 0.36, 1] as const;

export const SPRING_PRESS = {
  type: "spring",
  stiffness: 520,
  damping: 32,
  mass: 0.5,
} as const;

export const SPRING_SWAP = {
  type: "spring",
  stiffness: 420,
  damping: 30,
  mass: 0.7,
} as const;
