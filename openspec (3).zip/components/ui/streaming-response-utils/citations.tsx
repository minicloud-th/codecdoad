"use client";

import { ExternalLink, Globe } from "lucide-react";
import { cn } from "@/lib/utils";

export interface CitationItem {
  id: string;
  title: string;
  domain: string;
  url: string;
  snippet?: string;
}

function safeHref(rawUrl: string): string | null {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol === "https:" || parsed.protocol === "http:") {
      return parsed.toString();
    }
    return null;
  } catch {
    return null;
  }
}

export function CitationStack({
  citations,
  className,
}: {
  citations: CitationItem[];
  className?: string;
}) {
  const preview = citations.slice(0, 3);
  if (!preview.length) return null;

  return (
    <span className={cn("inline-flex items-center -space-x-1.5", className)} aria-hidden="true">
      {preview.map((citation) => {
        const badge = citation.domain.replace(/^www\./, "").slice(0, 1).toUpperCase();
        return (
          <span
            key={citation.id}
            className="grid size-4 place-items-center rounded-full border border-border bg-background text-[9px] font-semibold uppercase text-foreground shadow-xs"
          >
            {badge || <Globe className="size-2.5" />}
          </span>
        );
      })}
    </span>
  );
}

export function CitationList({
  citations,
  idPrefix = "citation",
  className,
}: {
  citations: CitationItem[];
  idPrefix?: string;
  className?: string;
}) {
  if (!citations.length) return null;

  return (
    <ul className={cn("grid gap-1.5", className)}>
      {citations.map((citation, index) => {
        const href = safeHref(citation.url);
        const itemId = `${idPrefix}-${citation.id}`;
        const content = (
          <>
            <span className="grid size-5 shrink-0 place-items-center rounded-md border border-border bg-background text-[11px] font-medium tabular-nums text-muted-foreground">
              {index + 1}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-xs font-medium text-foreground">
                {citation.title}
              </span>
              <span className="block truncate text-[11px] text-muted-foreground">
                {citation.domain}
              </span>
            </span>
            {href ? (
              <ExternalLink className="size-3 shrink-0 text-muted-foreground transition-colors group-hover/cite:text-foreground" />
            ) : null}
          </>
        );

        return (
          <li key={citation.id} id={itemId}>
            {href ? (
              <a
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="group/cite flex items-center gap-2.5 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-background/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                {content}
              </a>
            ) : (
              <div className="flex items-center gap-2.5 rounded-lg px-2 py-1.5 text-left">
                {content}
              </div>
            )}
          </li>
        );
      })}
    </ul>
  );
}
