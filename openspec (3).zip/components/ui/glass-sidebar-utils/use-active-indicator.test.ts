import assert from 'node:assert/strict';
import test from 'node:test';
import { computeIndicatorRect, rectsEqual } from './use-active-indicator.ts';

test('computeIndicatorRect calculates container-relative offset with scroll', () => {
  const rect = computeIndicatorRect(
    { left: 16, top: 20 },
    { left: 24, top: 96, width: 224, height: 40 },
    0,
    32,
  );

  assert.deepEqual(rect, {
    left: 8,
    top: 108,
    width: 224,
    height: 40,
  });
});

test('rectsEqual compares indicator rectangles within subpixel tolerance', () => {
  assert.equal(
    rectsEqual(
      { left: 8, top: 10, width: 44, height: 40 },
      { left: 8.2, top: 10.1, width: 44, height: 40 },
    ),
    true,
  );
  assert.equal(
    rectsEqual(
      { left: 8, top: 10, width: 44, height: 40 },
      { left: 8, top: 52, width: 44, height: 40 },
    ),
    false,
  );
  assert.equal(rectsEqual(null, null), true);
  assert.equal(rectsEqual(null, { left: 0, top: 0, width: 10, height: 10 }), false);
});
