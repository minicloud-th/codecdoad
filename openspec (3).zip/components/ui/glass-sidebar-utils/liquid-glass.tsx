import * as React from "react";
import { Slot } from "radix-ui";
import { cn } from "@/lib/utils";

export type LiquidGlassProps = React.ComponentProps<"div"> & {
  asChild?: boolean;
  variant?: "default" | "frosted";
  shadow?: boolean;
  bezel?: number;
  tint?: string;
};

export function LiquidGlass({
  asChild = false,
  variant = "default",
  shadow = true,
  bezel,
  tint,
  className,
  style,
  children,
  ...props
}: LiquidGlassProps) {
  const Comp = asChild ? Slot.Root : "div";
  const background =
    tint ??
    (variant === "frosted" ? "var(--glass-tint-frosted)" : "var(--glass-tint)");

  const mergedStyle: React.CSSProperties = {
    background,
    boxShadow: shadow
      ? "var(--glass-rim), var(--glass-shadow)"
      : "var(--glass-rim)",
    ...(bezel != null ? { borderRadius: style?.borderRadius ?? undefined } : {}),
    ...style,
  };

  return (
    <Comp
      data-slot="liquid-glass"
      data-variant={variant}
      className={cn(
        "backdrop-blur-2xl backdrop-saturate-150",
        className,
      )}
      style={mergedStyle}
      {...props}
    >
      {children}
    </Comp>
  );
}
