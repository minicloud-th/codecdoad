import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import express from 'express';
import type { Request, Response } from 'express';
import {
  DISCORD_TOKEN_URL,
  DISCORD_USER_ME_URL,
  DISCORD_SESSION_COOKIE,
  buildDiscordAuthorizeUrl,
  createStateStore,
  createTicketStore,
  getDiscordRedirectUri,
  isValidDiscordIssuer,
  parseCookieHeader,
  renderOAuthPopupHtml,
  signSessionToken,
  toDiscordSessionUser,
  verifySessionToken,
} from './src/server/discordOAuth.ts';
import type { DiscordApiUser, DiscordSessionUser } from './src/server/discordOAuth.ts';
import {
  APINEX_FREE_MODEL,
  classifyApinexError,
  createApinexClient,
  validateApinexPayload,
  verifyFirebaseIdToken,
} from './src/server/apinex.ts';
import {
  GEMINI_FREE_MODELS,
  classifyGeminiError,
  createGeminiClient,
  geminiDisplayName,
  validateGeminiPayload,
} from './src/server/gemini.ts';
import {
  NUMES_FREE_MODEL,
  classifyNumesError,
  createNumesClient,
  validateNumesPayload,
} from './src/server/numes.ts';
import type { AiUsageMetadata } from './src/server/types.ts';
import { extractGeminiUsage, extractOpenAiUsage } from './src/server/usageExtractors.ts';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET?.trim() || crypto.randomBytes(32).toString('hex');

const stateStore = createStateStore();
const ticketStore = createTicketStore<DiscordSessionUser>();

function getDiscordCredentials() {
  const clientId = process.env.DISCORD_CLIENT_ID?.trim() || '';
  const clientSecret = process.env.DISCORD_CLIENT_SECRET?.trim() || '';
  const redirectUri = getDiscordRedirectUri(
    process.env.APP_URL,
    process.env.DISCORD_REDIRECT_URI,
  );
  return { clientId, clientSecret, redirectUri };
}

function isHttpsRequest(req: Request): boolean {
  const forwardedProto = String(req.headers['x-forwarded-proto'] || '').toLowerCase();
  if (forwardedProto.includes('https')) return true;
  if (req.secure) return true;
  const appUrl = process.env.APP_URL || '';
  return appUrl.startsWith('https://');
}

function formatSessionCookie(req: Request, value: string, maxAgeSeconds: number): string {
  const encoded = encodeURIComponent(value);
  const parts = [
    `${DISCORD_SESSION_COOKIE}=${encoded}`,
    'Path=/',
    'HttpOnly',
    `Max-Age=${maxAgeSeconds}`,
  ];
  if (isHttpsRequest(req)) {
    parts.push('Secure', 'SameSite=None', 'Partitioned');
  } else {
    parts.push('SameSite=Lax');
  }
  return parts.join('; ');
}

function hasTrustedPostSource(req: Request): boolean {
  if (req.get('X-Requested-With') === 'OPENSPEC') {
    return true;
  }
  const origin = req.get('Origin');
  const host = req.get('X-Forwarded-Host') || req.get('Host');
  if (!origin || !host) return false;
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

function readTokenFromRequest(req: Request): string | undefined {
  const authHeader = req.get('Authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7).trim();
  }
  const cookies = parseCookieHeader(req.get('Cookie'));
  return cookies[DISCORD_SESSION_COOKIE];
}

async function hasAuthenticatedCaller(req: Request): Promise<boolean> {
  const token = readTokenFromRequest(req);
  if (verifySessionToken(token, SESSION_SECRET)) {
    return true;
  }
  const authHeader = req.get('Authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const bearer = authHeader.slice(7).trim();
    const firebaseUser = await verifyFirebaseIdToken(bearer);
    if (firebaseUser) return true;
  }
  return false;
}

async function startServer() {
  const app = express();
  app.set('trust proxy', 1);
  const json32kb = express.json({ limit: '32kb' });
  const json512kb = express.json({ limit: '512kb' });
  app.use((req, res, next) => {
    if (req.path === '/api/ai/gemini') {
      json512kb(req, res, next);
      return;
    }
    json32kb(req, res, next);
  });

  app.get('/api/auth/discord/status', (_req: Request, res: Response) => {
    const { clientId, clientSecret, redirectUri } = getDiscordCredentials();
    res.json({
      configured: Boolean(clientId && clientSecret),
      redirectUri,
    });
  });

  app.get('/api/auth/discord/url', (_req: Request, res: Response) => {
    const { clientId, clientSecret, redirectUri } = getDiscordCredentials();
    if (!clientId || !clientSecret) {
      res.status(503).json({
        error: 'ยังไม่ได้ตั้งค่า DISCORD_CLIENT_ID และ DISCORD_CLIENT_SECRET บนเซิร์ฟเวอร์',
        redirectUri,
      });
      return;
    }

    const state = stateStore.issue();
    const url = buildDiscordAuthorizeUrl({
      clientId,
      redirectUri,
      state,
    });
    res.json({ url, redirectUri });
  });

  const handleDiscordCallback = async (req: Request, res: Response) => {
    const query = req.query as Record<string, unknown>;
    const providerError = typeof query.error === 'string' ? query.error : '';
    const errorDesc = typeof query.error_description === 'string' ? query.error_description : '';
    if (providerError) {
      res
        .status(400)
        .type('html')
        .send(
          renderOAuthPopupHtml({
            type: 'DISCORD_OAUTH_ERROR',
            error: errorDesc || `Discord ปฏิเสธการเข้าสู่ระบบ (${providerError})`,
          }),
        );
      return;
    }

    const code = typeof query.code === 'string' ? query.code : '';
    const state = typeof query.state === 'string' ? query.state : '';
    const iss = typeof query.iss === 'string' ? query.iss : undefined;

    if (!isValidDiscordIssuer(iss)) {
      res
        .status(400)
        .type('html')
        .send(
          renderOAuthPopupHtml({
            type: 'DISCORD_OAUTH_ERROR',
            error: 'Issuer ของ OAuth ไม่ตรงกับ Discord',
          }),
        );
      return;
    }

    if (!stateStore.consume(state)) {
      res
        .status(400)
        .type('html')
        .send(
          renderOAuthPopupHtml({
            type: 'DISCORD_OAUTH_ERROR',
            error: 'รหัสยืนยันความปลอดภัย (state) ไม่ถูกต้องหรือหมดอายุ กรุณาลองใหม่',
          }),
        );
      return;
    }

    if (!code) {
      res
        .status(400)
        .type('html')
        .send(
          renderOAuthPopupHtml({
            type: 'DISCORD_OAUTH_ERROR',
            error: 'ไม่ได้รับ authorization code จาก Discord',
          }),
        );
      return;
    }

    const { clientId, clientSecret, redirectUri } = getDiscordCredentials();
    if (!clientId || !clientSecret) {
      res
        .status(503)
        .type('html')
        .send(
          renderOAuthPopupHtml({
            type: 'DISCORD_OAUTH_ERROR',
            error: 'ยังไม่ได้ตั้งค่า DISCORD_CLIENT_ID / DISCORD_CLIENT_SECRET',
          }),
        );
      return;
    }

    try {
      const tokenBody = new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: redirectUri,
      });
      const basicAuth = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
      const tokenResponse = await fetch(DISCORD_TOKEN_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: `Basic ${basicAuth}`,
        },
        body: tokenBody.toString(),
        signal: AbortSignal.timeout(10000),
      });

      if (!tokenResponse.ok) {
        res
          .status(502)
          .type('html')
          .send(
            renderOAuthPopupHtml({
              type: 'DISCORD_OAUTH_ERROR',
              error: 'แลกเปลี่ยน Token กับ Discord ไม่สำเร็จ ตรวจสอบ Client ID/Secret และ Redirect URI',
            }),
          );
        return;
      }

      const tokenJson = (await tokenResponse.json()) as { access_token?: string };
      if (!tokenJson.access_token) {
        throw new Error('Missing Discord access token');
      }

      const userResponse = await fetch(DISCORD_USER_ME_URL, {
        headers: {
          Authorization: `Bearer ${tokenJson.access_token}`,
        },
        signal: AbortSignal.timeout(10000),
      });

      if (!userResponse.ok) {
        res
          .status(502)
          .type('html')
          .send(
            renderOAuthPopupHtml({
              type: 'DISCORD_OAUTH_ERROR',
              error: 'ดึงข้อมูลโปรไฟล์จาก Discord ไม่สำเร็จ',
            }),
          );
        return;
      }

      const discordUser = (await userResponse.json()) as DiscordApiUser;
      const sessionUser = toDiscordSessionUser(discordUser);
      const ticket = ticketStore.issue(sessionUser);

      res
        .status(200)
        .type('html')
        .send(
          renderOAuthPopupHtml({
            type: 'DISCORD_OAUTH_SUCCESS',
            ticket,
            user: sessionUser,
          }),
        );
    } catch {
      res
        .status(502)
        .type('html')
        .send(
          renderOAuthPopupHtml({
            type: 'DISCORD_OAUTH_ERROR',
            error: 'เชื่อมต่อ Discord OAuth2 ไม่สำเร็จ กรุณาลองใหม่อีกครั้ง',
          }),
        );
    }
  };

  app.get(['/auth/discord/callback', '/auth/discord/callback/'], handleDiscordCallback);

  app.post('/api/auth/discord/claim', (req: Request, res: Response) => {
    if (!hasTrustedPostSource(req)) {
      res.status(403).json({ error: 'Invalid request origin' });
      return;
    }
    const ticket = typeof req.body?.ticket === 'string' ? req.body.ticket : '';
    const user = ticketStore.consume(ticket);
    if (!user) {
      res.status(401).json({ error: 'รหัสยืนยัน Discord หมดอายุหรือไม่ถูกต้อง กรุณาเข้าสู่ระบบใหม่' });
      return;
    }
    const token = signSessionToken(user, SESSION_SECRET);
    res.setHeader('Set-Cookie', formatSessionCookie(req, token, 7 * 24 * 60 * 60));
    res.json({ user, token });
  });

  app.get('/api/auth/discord/me', (req: Request, res: Response) => {
    const token = readTokenFromRequest(req);
    const user = verifySessionToken(token, SESSION_SECRET);
    if (!user) {
      res.status(200).json({ authenticated: false, user: null });
      return;
    }
    res.json({ authenticated: true, user });
  });

  app.post('/api/auth/discord/logout', (req: Request, res: Response) => {
    if (!hasTrustedPostSource(req)) {
      res.status(403).json({ error: 'Invalid request origin' });
      return;
    }
    res.setHeader('Set-Cookie', formatSessionCookie(req, '', 0));
    res.json({ ok: true });
  });

  app.get('/api/ai/apinex/status', (_req: Request, res: Response) => {
    res.json({
      configured: Boolean(process.env.APINEX_API_KEY?.trim()),
      model: APINEX_FREE_MODEL,
    });
  });

  app.post('/api/ai/apinex', async (req: Request, res: Response) => {
    if (!hasTrustedPostSource(req)) {
      res.status(403).json({ error: 'Invalid request origin' });
      return;
    }
    const authed = await hasAuthenticatedCaller(req);
    if (!authed) {
      res.status(401).json({ error: 'กรุณาเข้าสู่ระบบก่อนใช้งาน GLM-5.3 FlashX' });
      return;
    }
    const apiKey = process.env.APINEX_API_KEY?.trim() || '';
    if (!apiKey) {
      res.status(503).json({
        error: 'ยังไม่ได้ตั้งค่า APINEX_API_KEY บนเซิร์ฟเวอร์ (Settings → Secrets)',
      });
      return;
    }

    const validated = validateApinexPayload(req.body);
    if (validated.ok === false) {
      res.status(400).json({ error: validated.error });
      return;
    }

    res.status(200);
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    const writeEvent = (event: string, data: unknown) => {
      if (res.writableEnded) return;
      res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 90_000);
    const onClose = () => {
      if (!res.writableEnded) {
        controller.abort();
      }
    };
    res.on('close', onClose);

    try {
      writeEvent('progress', { message: 'กำลังเชื่อมต่อ GLM-5.3 FlashX...' });
      const client = createApinexClient(apiKey);
      let startedText = false;
      let latestUsage: AiUsageMetadata | null = null;

      try {
        const stream = await client.chat.completions.create(
          {
            model: APINEX_FREE_MODEL,
            messages: validated.data.messages,
            max_tokens: validated.data.maxTokens,
            stream: true,
          },
          { signal: controller.signal },
        );

        for await (const chunk of stream) {
          if (controller.signal.aborted) break;
          const chunkUsage = extractOpenAiUsage((chunk as { usage?: unknown }).usage);
          if (chunkUsage) latestUsage = chunkUsage;
          const delta = chunk.choices?.[0]?.delta?.content ?? '';
          if (!delta) continue;
          if (!startedText) {
            startedText = true;
            writeEvent('progress', { message: 'GLM-5.3 FlashX กำลังตอบ...' });
          }
          writeEvent('token', { delta });
        }
      } catch (streamErr) {
        const classifiedStreamErr = classifyApinexError(streamErr);
        if (controller.signal.aborted || classifiedStreamErr.status === 401 || classifiedStreamErr.status === 403 || classifiedStreamErr.status === 429 || startedText) {
          throw streamErr;
        }
        if (classifiedStreamErr.message.includes('Cloudflare')) {
          throw streamErr;
        }
        const completion = await client.chat.completions.create(
          {
            model: APINEX_FREE_MODEL,
            messages: validated.data.messages,
            max_tokens: validated.data.maxTokens,
          },
          { signal: controller.signal },
        );
        const completionUsage = extractOpenAiUsage((completion as { usage?: unknown }).usage);
        if (completionUsage) latestUsage = completionUsage;
        const content = completion.choices?.[0]?.message?.content ?? '';
        if (content) {
          writeEvent('progress', { message: 'GLM-5.3 FlashX กำลังตอบ...' });
          writeEvent('token', { delta: content });
        }
      }
      if (latestUsage) {
        writeEvent('usage', latestUsage);
      }
      writeEvent('done', { model: APINEX_FREE_MODEL, ...(latestUsage ? { usage: latestUsage } : {}) });
    } catch (err) {
      if (!controller.signal.aborted) {
        const { status, message } = classifyApinexError(err);
        writeEvent('error', { error: message, status });
      }
    } finally {
      clearTimeout(timeoutId);
      res.off('close', onClose);
      if (!res.writableEnded) {
        res.end();
      }
    }
  });

  app.get('/api/ai/numes/status', (_req: Request, res: Response) => {
    res.json({
      configured: Boolean(process.env.NUMES_API_KEY?.trim()),
      model: NUMES_FREE_MODEL,
    });
  });

  app.post('/api/ai/numes', async (req: Request, res: Response) => {
    if (!hasTrustedPostSource(req)) {
      res.status(403).json({ error: 'Invalid request origin' });
      return;
    }
    const authed = await hasAuthenticatedCaller(req);
    if (!authed) {
      res.status(401).json({ error: 'กรุณาเข้าสู่ระบบก่อนใช้งาน DeepSeek V4.1 Flash' });
      return;
    }
    const apiKey = process.env.NUMES_API_KEY?.trim() || '';
    if (!apiKey) {
      res.status(503).json({
        error: 'ยังไม่ได้ตั้งค่า NUMES_API_KEY บนเซิร์ฟเวอร์ (Settings → Secrets)',
      });
      return;
    }

    const validated = validateNumesPayload(req.body);
    if (validated.ok === false) {
      res.status(400).json({ error: validated.error });
      return;
    }

    res.status(200);
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    const writeEvent = (event: string, data: unknown) => {
      if (res.writableEnded) return;
      res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 90_000);
    const onClose = () => {
      if (!res.writableEnded) {
        controller.abort();
      }
    };
    res.on('close', onClose);

    try {
      writeEvent('progress', { message: 'กำลังเชื่อมต่อ DeepSeek V4.1 Flash...' });
      const client = createNumesClient(apiKey);
      let startedText = false;
      let latestUsage: AiUsageMetadata | null = null;

      try {
        const stream = await client.chat.completions.create(
          {
            model: NUMES_FREE_MODEL,
            messages: validated.data.messages,
            max_tokens: validated.data.maxTokens,
            stream: true,
          },
          { signal: controller.signal },
        );

        for await (const chunk of stream) {
          if (controller.signal.aborted) break;
          const chunkUsage = extractOpenAiUsage((chunk as { usage?: unknown }).usage);
          if (chunkUsage) latestUsage = chunkUsage;
          const delta = chunk.choices?.[0]?.delta?.content ?? '';
          if (!delta) continue;
          if (!startedText) {
            startedText = true;
            writeEvent('progress', { message: 'DeepSeek V4.1 Flash กำลังตอบ...' });
          }
          writeEvent('token', { delta });
        }
      } catch (streamErr) {
        const classifiedStreamErr = classifyNumesError(streamErr);
        if (
          controller.signal.aborted ||
          classifiedStreamErr.status === 401 ||
          classifiedStreamErr.status === 403 ||
          classifiedStreamErr.status === 404 ||
          classifiedStreamErr.status === 429 ||
          startedText
        ) {
          throw streamErr;
        }
        const completion = await client.chat.completions.create(
          {
            model: NUMES_FREE_MODEL,
            messages: validated.data.messages,
            max_tokens: validated.data.maxTokens,
          },
          { signal: controller.signal },
        );
        const completionUsage = extractOpenAiUsage((completion as { usage?: unknown }).usage);
        if (completionUsage) latestUsage = completionUsage;
        const content = completion.choices?.[0]?.message?.content ?? '';
        if (content) {
          writeEvent('progress', { message: 'DeepSeek V4.1 Flash กำลังตอบ...' });
          writeEvent('token', { delta: content });
        }
      }
      if (latestUsage) {
        writeEvent('usage', latestUsage);
      }
      writeEvent('done', { model: NUMES_FREE_MODEL, ...(latestUsage ? { usage: latestUsage } : {}) });
    } catch (err) {
      if (!controller.signal.aborted) {
        const { status, message } = classifyNumesError(err);
        writeEvent('error', { error: message, status });
      }
    } finally {
      clearTimeout(timeoutId);
      res.off('close', onClose);
      if (!res.writableEnded) {
        res.end();
      }
    }
  });

  app.get('/api/ai/gemini/status', (_req: Request, res: Response) => {
    res.json({
      configured: Boolean(process.env.GEMINI_API_KEY?.trim()),
      models: GEMINI_FREE_MODELS,
    });
  });

  app.post('/api/ai/gemini', async (req: Request, res: Response) => {
    if (!hasTrustedPostSource(req)) {
      res.status(403).json({ error: 'Invalid request origin' });
      return;
    }
    const authed = await hasAuthenticatedCaller(req);
    if (!authed) {
      res.status(401).json({ error: 'กรุณาเข้าสู่ระบบก่อนใช้งาน Gemini' });
      return;
    }
    const apiKey = process.env.GEMINI_API_KEY?.trim() || '';
    if (!apiKey) {
      res.status(503).json({
        error: 'ยังไม่ได้ตั้งค่า GEMINI_API_KEY บนเซิร์ฟเวอร์ (Settings > Secrets)',
      });
      return;
    }

    const validated = validateGeminiPayload(req.body);
    if (validated.ok === false) {
      res.status(400).json({ error: validated.error });
      return;
    }

    const modelLabel = geminiDisplayName(validated.data.model);

    res.status(200);
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    const writeEvent = (event: string, data: unknown) => {
      if (res.writableEnded) return;
      res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 90_000);
    const onClose = () => {
      if (!res.writableEnded) {
        controller.abort();
      }
    };
    res.on('close', onClose);

    try {
      writeEvent('progress', { message: `กำลังเชื่อมต่อ ${modelLabel}...` });
      const ai = createGeminiClient(apiKey);
      let startedText = false;
      let latestUsage: AiUsageMetadata | null = null;

      const config = {
        systemInstruction: validated.data.systemInstruction,
        thinkingConfig: { thinkingLevel: validated.data.thinkingLevel },
        abortSignal: controller.signal,
      };

      try {
        const stream = await ai.models.generateContentStream({
          model: validated.data.model,
          contents: validated.data.contents,
          config,
        });

        for await (const chunk of stream) {
          if (controller.signal.aborted) break;
          const chunkUsage = extractGeminiUsage((chunk as { usageMetadata?: unknown }).usageMetadata);
          if (chunkUsage) latestUsage = chunkUsage;
          const delta = chunk.text ?? '';
          if (!delta) continue;
          if (!startedText) {
            startedText = true;
            writeEvent('progress', { message: `${modelLabel} กำลังตอบ...` });
          }
          writeEvent('token', { delta });
        }
      } catch (streamErr) {
        const classifiedStreamErr = classifyGeminiError(streamErr, modelLabel);
        if (
          controller.signal.aborted ||
          classifiedStreamErr.status === 400 ||
          classifiedStreamErr.status === 403 ||
          classifiedStreamErr.status === 404 ||
          classifiedStreamErr.status === 429 ||
          startedText
        ) {
          throw streamErr;
        }
        const response = await ai.models.generateContent({
          model: validated.data.model,
          contents: validated.data.contents,
          config,
        });
        const responseUsage = extractGeminiUsage((response as { usageMetadata?: unknown }).usageMetadata);
        if (responseUsage) latestUsage = responseUsage;
        const content = response.text ?? '';
        if (content) {
          writeEvent('progress', { message: `${modelLabel} กำลังตอบ...` });
          writeEvent('token', { delta: content });
        }
      }
      if (latestUsage) {
        writeEvent('usage', latestUsage);
      }
      writeEvent('done', { model: validated.data.model, ...(latestUsage ? { usage: latestUsage } : {}) });
    } catch (err) {
      if (!controller.signal.aborted) {
        const { status, message } = classifyGeminiError(err, modelLabel);
        writeEvent('error', { error: message, status });
      }
    } finally {
      clearTimeout(timeoutId);
      res.off('close', onClose);
      if (!res.writableEnded) {
        res.end();
      }
    }
  });

  app.get(['/terms', '/terms/'], (_req: Request, res: Response) => {
    const file = path.resolve(__dirname, 'public/terms/index.html');
    if (fs.existsSync(file)) {
      res.sendFile(file);
      return;
    }
    res.status(404).end();
  });

  app.get(['/privacy', '/privacy/'], (_req: Request, res: Response) => {
    const file = path.resolve(__dirname, 'public/privacy/index.html');
    if (fs.existsSync(file)) {
      res.sendFile(file);
      return;
    }
    res.status(404).end();
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`OPENSPEC server running on http://0.0.0.0:${PORT}`);
  });
}

void startServer();
