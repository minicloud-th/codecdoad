import type { Model } from './api'

export const EFFORT_LEVELS = ['Low', 'Medium', 'High', 'Max'] as const
export type EffortLevel = (typeof EFFORT_LEVELS)[number]

export type SkillItem = {
  id: string
  label: string
  description: string
  instruction: string
}

export const DEFAULT_SKILLS: readonly SkillItem[] = [
  {
    id: 'openspec',
    label: 'เขียนสเปค OpenSpec',
    description: 'วางโครงสร้างสเปค เป้าหมาย และแผนงาน',
    instruction: 'จัดทำสเปคงานแบบ OpenSpec แยกหัวข้อเป้าหมาย ข้อกำหนด และแผนลงมือทำอย่างเป็นระบบ',
  },
  {
    id: 'deep-review',
    label: 'วิเคราะห์โค้ดเชิงลึก',
    description: 'ตรวจสถาปัตยกรรม ความปลอดภัย และจุดปรับปรุง',
    instruction: 'วิเคราะห์โค้ดและไฟล์แนบอย่างละเอียด ชี้จุดเสี่ยงด้านประสิทธิภาพ ความปลอดภัย และแนวทางปรับปรุง',
  },
  {
    id: 'bug-hunt',
    label: 'ตรวจหา Bug & TODO',
    description: 'ไล่หาข้อผิดพลาด edge case และจุดตกหล่น',
    instruction: 'ตรวจสอบหาข้อผิดพลาด edge case และรายการ TODO/FIXME พร้อมวิธีแก้ไขที่ชัดเจน',
  },
  {
    id: 'action-plan',
    label: 'สรุปและวางแผนงาน',
    description: 'ย่อยงานเป็นเช็กลิสต์ที่ทำตามได้ทันที',
    instruction: 'สรุปใจความสำคัญและจัดลำดับขั้นตอนการทำงานเป็นรายการเช็กลิสต์ที่ทำตามได้ทันที',
  },
]

export type LocalModelDtype = 'q4' | 'q8'

export type LocalModelSpec = {
  effort: EffortLevel
  id: string
  repoId: string
  revision: string
  displayName: string
  shortLabel: string
  parameterBillions: number
  approxBytesMB: number
  approxDownload: string
  dtype: LocalModelDtype
  hasExternalData: boolean
  supportsThinkingControl: boolean
  maxNewTokens: number
}

export const EFFORT_MODEL_SPECS: Record<EffortLevel, LocalModelSpec> = {
  Low: {
    effort: 'Low',
    id: 'qwen3-0.6b',
    repoId: 'onnx-community/Qwen3-0.6B-ONNX-OPT',
    revision: '4799e655597b49210adb5c1ebe5b9d3bd04005a0',
    displayName: 'Qwen3 0.6B',
    shortLabel: '0.6B',
    parameterBillions: 0.6,
    approxBytesMB: 403,
    approxDownload: '~403 MB',
    dtype: 'q4',
    hasExternalData: true,
    supportsThinkingControl: true,
    maxNewTokens: 128,
  },
  Medium: {
    effort: 'Medium',
    id: 'gemma-3-1b',
    repoId: 'onnx-community/gemma-3-1b-it-ONNX',
    revision: 'a58439f40017d3b99c7d378ff525e54e0ba08ebf',
    displayName: 'Gemma 3 1B',
    shortLabel: '1B',
    parameterBillions: 1.0,
    approxBytesMB: 859,
    approxDownload: '~859 MB',
    dtype: 'q4',
    hasExternalData: true,
    supportsThinkingControl: false,
    maxNewTokens: 196,
  },
  High: {
    effort: 'High',
    id: 'qwen2.5-1.5b',
    repoId: 'onnx-community/Qwen2.5-1.5B-Instruct',
    revision: 'd54957e3af1be04546436e874a60fe386041b244',
    displayName: 'Qwen2.5 1.5B',
    shortLabel: '1.5B',
    parameterBillions: 1.5,
    approxBytesMB: 1580,
    approxDownload: '~1.58 GB',
    dtype: 'q8',
    hasExternalData: false,
    supportsThinkingControl: false,
    maxNewTokens: 320,
  },
  Max: {
    effort: 'Max',
    id: 'qwen3-1.7b',
    repoId: 'onnx-community/Qwen3-1.7B-ONNX',
    revision: '3231b522c6e703b2f9b3cd8ea27426a1289a02f2',
    displayName: 'Qwen3 1.7B',
    shortLabel: '1.7B',
    parameterBillions: 1.7,
    approxBytesMB: 1740,
    approxDownload: '~1.74 GB',
    dtype: 'q8',
    hasExternalData: false,
    supportsThinkingControl: true,
    maxNewTokens: 480,
  },
}

export const GEMINI_HYDROGEN_MODEL_ID = 'gemini-4-hydrogen'
export const GEMINI_HYDROGEN_MODEL_NAME = 'Gemini 4 Flash'
export const GEMINI_FLASH_LITE_MODEL_ID = 'gemini-3.1-flash-lite'
export const GEMINI_FLASH_LITE_MODEL_NAME = 'Gemini 3.1 Flash Lite'
export const NUMES_MODEL_ID = 'deepseek/deepseek-v4.1-flash:free'
export const NUMES_MODEL_NAME = 'DeepSeek V4.1 Flash'
export const APINEX_MODEL_ID = 'free/glm-5.3-flashx'
export const APINEX_MODEL_NAME = 'GLM-5.3 FlashX'
export const LOCAL_PLAN_MODEL_NAME = 'Speconi'

const LOCAL_MODEL_NAMES = new Set<string>([
  'Plan Free',
  LOCAL_PLAN_MODEL_NAME,
  GEMINI_HYDROGEN_MODEL_NAME,
  GEMINI_FLASH_LITE_MODEL_NAME,
  NUMES_MODEL_NAME,
  APINEX_MODEL_NAME,
  'GLM-5.3 Flash',
  ...Object.values(EFFORT_MODEL_SPECS).map(spec => spec.displayName),
])

export function isGeminiModelId(modelId: string): boolean {
  return modelId === GEMINI_HYDROGEN_MODEL_ID || modelId === GEMINI_FLASH_LITE_MODEL_ID
}

export function isNumesModelId(modelId: string): boolean {
  return modelId === NUMES_MODEL_ID
}

export function isCloudModelId(modelId: string): boolean {
  return isGeminiModelId(modelId) || isNumesModelId(modelId) || modelId === APINEX_MODEL_ID
}

export function geminiThinkingLabel(modelId: string, effort: EffortLevel): string {
  if (modelId === GEMINI_FLASH_LITE_MODEL_ID) {
    switch (effort) {
      case 'Low':
        return 'Minimal'
      case 'Medium':
        return 'Low'
      case 'High':
        return 'Medium'
      case 'Max':
        return 'High'
    }
  }
  switch (effort) {
    case 'Low':
      return 'Low'
    case 'Medium':
      return 'Medium'
    case 'High':
      return 'High'
    case 'Max':
      return 'XHigh'
  }
}

export function modelForEffort(effort: EffortLevel = 'Low'): LocalModelSpec {
  return EFFORT_MODEL_SPECS[effort] ?? EFFORT_MODEL_SPECS.Low
}

export function isLocalModelName(name: string): boolean {
  return LOCAL_MODEL_NAMES.has(name)
}

export function apinexMaxTokens(effort: EffortLevel): number {
  switch (effort) {
    case 'Low':
      return 512
    case 'Medium':
      return 1024
    case 'High':
      return 2048
    case 'Max':
      return 4096
  }
}

export function numesMaxTokens(effort: EffortLevel): number {
  switch (effort) {
    case 'Low':
      return 512
    case 'Medium':
      return 1024
    case 'High':
      return 2048
    case 'Max':
      return 4096
  }
}

export function activeModelDisplayLabel(modelId: string, _effort?: EffortLevel): string {
  if (modelId === GEMINI_HYDROGEN_MODEL_ID) {
    return GEMINI_HYDROGEN_MODEL_NAME
  }
  if (modelId === GEMINI_FLASH_LITE_MODEL_ID) {
    return GEMINI_FLASH_LITE_MODEL_NAME
  }
  if (modelId === NUMES_MODEL_ID) {
    return NUMES_MODEL_NAME
  }
  if (modelId === APINEX_MODEL_ID) {
    return APINEX_MODEL_NAME
  }
  return LOCAL_PLAN_MODEL_NAME
}

export type ModelMessage = { role: 'system' | 'user' | 'assistant'; content: string }

export type ModelWorkerRequest = {
  modelKey: string
  modelId: string
  revision: string
  displayName: string
  dtype: LocalModelDtype
  hasExternalData: boolean
  supportsThinkingControl: boolean
  messages: ModelMessage[]
  maxNewTokens: number
}

export function modelKeyForSpec(spec: LocalModelSpec): string {
  return `${spec.repoId}@${spec.revision}:${spec.dtype}`
}

export function buildModelWorkerRequest(
  effort: EffortLevel,
  messages: ModelMessage[],
): ModelWorkerRequest {
  const spec = modelForEffort(effort)
  return {
    modelKey: modelKeyForSpec(spec),
    modelId: spec.repoId,
    revision: spec.revision,
    displayName: LOCAL_PLAN_MODEL_NAME,
    dtype: spec.dtype,
    hasExternalData: spec.hasExternalData,
    supportsThinkingControl: spec.supportsThinkingControl,
    messages,
    maxNewTokens: spec.maxNewTokens,
  }
}

export function formatModelDisplayName(model: Model): { title: string; badge?: string } {
  if (model.id === GEMINI_HYDROGEN_MODEL_ID) {
    return { title: GEMINI_HYDROGEN_MODEL_NAME, badge: 'Plan Free' }
  }
  if (model.id === GEMINI_FLASH_LITE_MODEL_ID) {
    return { title: GEMINI_FLASH_LITE_MODEL_NAME, badge: 'Plan Free' }
  }
  if (model.id === NUMES_MODEL_ID) {
    return { title: NUMES_MODEL_NAME, badge: 'Plan Free' }
  }
  if (model.id === APINEX_MODEL_ID) {
    return { title: APINEX_MODEL_NAME, badge: 'Plan Free' }
  }
  if (model.id === 'ai') {
    return { title: LOCAL_PLAN_MODEL_NAME, badge: 'Plan Free · AI จากเครื่อง' }
  }
  return { title: model.name }
}

export function effortIndex(effort: EffortLevel): number {
  const index = EFFORT_LEVELS.indexOf(effort)
  return index >= 0 ? index : EFFORT_LEVELS.length - 1
}

export function clampEffortRatio(ratio: number): number {
  if (!Number.isFinite(ratio)) return 1
  return Math.max(0, Math.min(1, ratio))
}

export function effortStopRatio(effort: EffortLevel): number {
  return effortIndex(effort) / (EFFORT_LEVELS.length - 1)
}

export function computeSliderRatio(
  clientX: number,
  rectLeft: number,
  rectWidth: number,
  pad = 16,
): number {
  const usable = Math.max(1, rectWidth - pad * 2)
  return clampEffortRatio((clientX - (rectLeft + pad)) / usable)
}

export function effortFromRatio(ratio: number): EffortLevel {
  const clamped = clampEffortRatio(ratio)
  const index = Math.round(clamped * (EFFORT_LEVELS.length - 1))
  return EFFORT_LEVELS[index] ?? 'Max'
}

export function effortMaxTokens(effort: EffortLevel): number {
  return modelForEffort(effort).maxNewTokens
}

export function buildPromptWithSkills(prompt: string, skills: readonly SkillItem[]): string {
  const trimmed = prompt.trim()
  if (!skills.length) return trimmed
  const skillBlock = skills
    .map(skill => `[Skill: ${skill.label}] ${skill.instruction}`)
    .join('\n')
  return trimmed ? `${skillBlock}\n\n${trimmed}` : skillBlock
}

export function formatAutoAnalysisReply(fileReport: string, aiReply?: string): string {
  const report = fileReport.trim()
  const reply = aiReply?.trim() ?? ''
  if (!report) return reply
  if (!reply) return report
  return `${report}\n\n---\n\n${reply}`
}

export type TurnToolSituation = {
  state: 'searching' | 'done'
  label: string
  headerLabel: string
  query: string
}

export function resolveTurnToolSituation({
  streaming,
  progressText,
  fileCount,
  prompt,
  modelName,
}: {
  streaming: boolean
  progressText?: string
  fileCount: number
  prompt: string
  modelName: string
}): TurnToolSituation | null {
  if (streaming) {
    const progress = progressText?.trim() ?? ''
    if (progress.includes('ดาวน์โหลด')) {
      return {
        state: 'searching',
        label: progress,
        headerLabel: 'กำลังเตรียมโมเดล',
        query: modelName,
      }
    }
    if (progress.includes('เชื่อมต่อ')) {
      return {
        state: 'searching',
        label: progress,
        headerLabel: 'กำลังเชื่อมต่อโมเดล',
        query: modelName,
      }
    }
    if (progress.includes('กำลังเริ่มตัวประมวลผล') || progress.includes('กำลังเปิด')) {
      return {
        state: 'searching',
        label: progress,
        headerLabel: 'กำลังเริ่มต้นเอนจิน',
        query: modelName,
      }
    }
    if (fileCount > 0 && !progress.includes('กำลังตอบ')) {
      return {
        state: 'searching',
        label: `กำลังสแกนและวิเคราะห์ ${fileCount} ไฟล์แนบ...`,
        headerLabel: 'กำลังวิเคราะห์ไฟล์',
        query: prompt || `${fileCount} ไฟล์`,
      }
    }
    return {
      state: 'searching',
      label: progress || `${modelName} กำลังคิดคำตอบ...`,
      headerLabel: progress.includes('กำลังตอบ') ? 'กำลังสร้างคำตอบ' : 'กำลังประมวลผล',
      query: prompt || modelName,
    }
  }

  if (fileCount > 0) {
    return {
      state: 'done',
      label: `วิเคราะห์ ${fileCount} ไฟล์แนบแล้ว`,
      headerLabel: 'ไฟล์ที่วิเคราะห์',
      query: prompt || `${fileCount} ไฟล์`,
    }
  }

  return null
}

export function neutralizeStreamingLabel(progressText?: string): string {
  const progress = progressText?.trim() ?? ''
  if (progress.includes('ดาวน์โหลด')) {
    const percentMatch = /\d+%/.exec(progress)
    return percentMatch ? `กำลังเตรียมข้อมูล · ${percentMatch[0]}` : 'กำลังเตรียมข้อมูล...'
  }
  if (progress.includes('เชื่อมต่อ')) {
    return 'กำลังเชื่อมต่อ...'
  }
  if (progress.includes('กำลังเริ่มตัวประมวลผล') || progress.includes('กำลังเปิด')) {
    return 'กำลังเตรียมการ...'
  }
  if (progress.includes('กำลังตอบ')) {
    return 'กำลังตอบ...'
  }
  return 'กำลังคิดคำตอบ...'
}

