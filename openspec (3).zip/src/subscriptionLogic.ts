import type { BillingCycle, PlanId } from './api'

export type SubscriptionTierId = 'go' | 'go_plus'
export type SubscriptionCycleId = 'daily' | 'weekly' | 'monthly' | 'annually'
export type SubscriptionBulletStyle = 'square' | 'plus'
export type SubscriptionButtonVariant = 'outline' | 'solid'

export type SubscriptionCycleMeta = {
  id: SubscriptionCycleId
  label: string
  cadence: string
}

export type SubscriptionTier = {
  id: SubscriptionTierId
  label: string
  prices: Record<SubscriptionCycleId, string>
  bulletStyle: SubscriptionBulletStyle
  features: readonly string[]
  ctaLabel: string
  activeLabel: string
  switchLabel: string
  variant: SubscriptionButtonVariant
}

export const SUBSCRIPTION_CYCLES: readonly SubscriptionCycleMeta[] = [
  { id: 'daily', label: 'รายวัน', cadence: 'per day' },
  { id: 'weekly', label: 'รายสัปดาห์', cadence: 'per week' },
  { id: 'monthly', label: 'รายเดือน', cadence: 'per month' },
  { id: 'annually', label: 'รายปี', cadence: 'per year' },
]

export const SUBSCRIPTION_TIERS: readonly SubscriptionTier[] = [
  {
    id: 'go',
    label: 'GO',
    prices: {
      daily: '฿19',
      weekly: '฿79',
      monthly: '฿199',
      annually: '฿1,990',
    },
    bulletStyle: 'square',
    features: [
      'Curated, affordable models',
      'Tested for agentic coding',
      'Generous limits and reliable access',
    ],
    ctaLabel: 'SUBSCRIBE TO GO',
    activeLabel: 'CURRENT PLAN · GO',
    switchLabel: 'SWITCH CYCLE · GO',
    variant: 'outline',
  },
  {
    id: 'go_plus',
    label: 'GO PLUS',
    prices: {
      daily: '฿49',
      weekly: '฿199',
      monthly: '฿599',
      annually: '฿5,990',
    },
    bulletStyle: 'plus',
    features: [
      'Everything included in Go',
      'Higher limits and fewer interruptions',
      'Built for larger, demanding projects',
    ],
    ctaLabel: 'SUBSCRIBE TO GO PLUS',
    activeLabel: 'CURRENT PLAN · GO PLUS',
    switchLabel: 'SWITCH CYCLE · GO PLUS',
    variant: 'solid',
  },
]

export function normalizeSubscriptionCycle(cycle?: BillingCycle | null): SubscriptionCycleId {
  if (cycle === 'daily' || cycle === 'weekly' || cycle === 'monthly' || cycle === 'annually') {
    return cycle
  }
  return 'monthly'
}

export function cycleMetaFor(cycle: SubscriptionCycleId): SubscriptionCycleMeta {
  return SUBSCRIPTION_CYCLES.find(item => item.id === cycle) ?? SUBSCRIPTION_CYCLES[2]
}

export function isTierCycleActive(
  currentPlan: PlanId,
  currentCycle: BillingCycle,
  tierId: SubscriptionTierId,
  selectedCycle: SubscriptionCycleId,
): boolean {
  return currentPlan === tierId && normalizeSubscriptionCycle(currentCycle) === selectedCycle
}

export function subscriptionButtonLabel(
  tier: SubscriptionTier,
  currentPlan: PlanId,
  currentCycle: BillingCycle,
  selectedCycle: SubscriptionCycleId,
  pendingPlan?: PlanId | null,
): string {
  if (pendingPlan === tier.id) return 'UPDATING...'
  if (isTierCycleActive(currentPlan, currentCycle, tier.id, selectedCycle)) {
    return tier.activeLabel
  }
  if (currentPlan === tier.id) {
    return tier.switchLabel
  }
  return tier.ctaLabel
}

export function formatCycleLabel(cycle: BillingCycle): string {
  switch (cycle) {
    case 'daily':
      return 'รายวัน'
    case 'weekly':
      return 'รายสัปดาห์'
    case 'annually':
      return 'รายปี'
    case 'quarterly':
      return 'รายไตรมาส'
    case 'monthly':
    default:
      return 'รายเดือน'
  }
}

export function formatActivePlanLabel(plan: PlanId, cycle?: BillingCycle): string {
  const base = (() => {
    switch (plan) {
      case 'go':
        return 'Plan Go'
      case 'go_plus':
        return 'Plan Go Plus'
      case 'lite':
        return 'Plan Lite'
      case 'pro':
        return 'Plan Pro'
      case 'max':
        return 'Plan Max'
      case 'free':
      default:
        return 'Plan Free'
    }
  })()
  if (plan === 'free' || !cycle) return base
  return `${base} (${formatCycleLabel(cycle)})`
}
