import { TextStreamer, env, pipeline } from '@huggingface/transformers'
import type { TextGenerationPipeline } from '@huggingface/transformers'
import wasmUrl from 'onnxruntime-web/ort-wasm-simd-threaded.wasm?url'
import wasmModuleUrl from 'onnxruntime-web/ort-wasm-simd-threaded.mjs?url'
import type { ModelEvent, ModelWorkerRequest } from './localModel'

env.allowLocalModels = false
// ONNX Runtime can import the same-origin module directly. The built-in WASM
// cache converts the module to a blob URL, which the site's script policy blocks.
env.useWasmCache = false
if (env.backends.onnx.wasm) {
  env.backends.onnx.wasm.numThreads = 1
  env.backends.onnx.wasm.wasmPaths = { wasm: wasmUrl, mjs: wasmModuleUrl }
}

let generator: TextGenerationPipeline | undefined
let loadedModelKey: string | undefined

self.addEventListener('message', async (event: MessageEvent<ModelWorkerRequest>) => {
  const port = event.ports[0]
  if (!port) return
  const {
    modelKey,
    modelId,
    revision,
    displayName,
    dtype,
    hasExternalData,
    supportsThinkingControl,
    messages,
    maxNewTokens,
  } = event.data
  const emit = (kind: ModelEvent['kind'], text: string, usage?: ModelEvent['usage']) =>
    port.postMessage(usage ? ({ kind, text, usage } satisfies ModelEvent) : ({ kind, text } satisfies ModelEvent))
  let stage: 'download' | 'initialize' | 'generate' = 'download'
  try {
    let lastProgress = -1
    if (generator && loadedModelKey !== modelKey) {
      await generator.dispose?.()
      generator = undefined
      loadedModelKey = undefined
    }
    if (!generator) {
      generator = await pipeline('text-generation', modelId, {
        revision,
        device: 'wasm',
        dtype,
        progress_callback: data => {
          if (data.status === 'progress') {
            const isPrimaryWeight = hasExternalData
              ? data.file.includes('.onnx_data')
              : data.file.endsWith('.onnx')
            if (isPrimaryWeight) {
              const percent = Math.max(0, Math.min(100, Math.floor(data.progress)))
              if (percent !== lastProgress) {
                lastProgress = percent
                emit('progress', `กำลังดาวน์โหลด ${displayName} · ${percent}%`)
              }
            }
          } else if (data.status === 'done') {
            const isPrimaryDone = hasExternalData
              ? data.file.endsWith('.onnx_data')
              : data.file.endsWith('.onnx')
            if (isPrimaryDone) {
              stage = 'initialize'
              emit('progress', `กำลังเริ่มตัวประมวลผล ${displayName}`)
            }
          }
        },
      })
      loadedModelKey = modelKey
    }
    stage = 'generate'
    const chatTemplateOptions = supportsThinkingControl
      ? ({ tokenize: false, add_generation_prompt: true, enable_thinking: false } as const)
      : ({ tokenize: false, add_generation_prompt: true } as const)
    const prompt = generator.tokenizer.apply_chat_template(messages, chatTemplateOptions)
    const promptTokens = generator.tokenizer(prompt, { add_special_tokens: false }).input_ids.dims.at(-1) ?? 0
    if (promptTokens > 2048) {
      emit('error', 'แชตยาวเกินที่โมเดลบนเครื่องรองรับ ลองย่อข้อความหรือเปิดแชตใหม่')
      return
    }
    emit('progress', `${displayName} กำลังตอบบนอุปกรณ์นี้`)
    let streamedRaw = ''
    const streamer = new TextStreamer(generator.tokenizer, {
      skip_prompt: true,
      skip_special_tokens: true,
      callback_function: chunk => {
        streamedRaw += chunk
        const cleaned = streamedRaw
          .replace(/^\s*<think>[\s\S]*?<\/think>\s*/, '')
          .replace(/^\s*<think>[\s\S]*$/, '')
          .trimStart()
        if (cleaned) emit('token', cleaned)
      },
    })
    const [output] = await generator(prompt, {
      add_special_tokens: false,
      max_new_tokens: maxNewTokens ?? 196,
      do_sample: true,
      temperature: 0.7,
      top_p: 0.8,
      top_k: 20,
      return_full_text: false,
      streamer,
    })
    const text = typeof output.generated_text === 'string'
      ? output.generated_text.replace(/^\s*<think>[\s\S]*?<\/think>/, '').trim()
      : ''
    if (!text) {
      emit('error', `${displayName} ตอบกลับเป็นข้อความว่าง ลองส่งคำถามอีกครั้ง`)
      return
    }
    const completionTokens = generator.tokenizer(text, { add_special_tokens: false }).input_ids.dims.at(-1) ?? 0
    emit('answer', text, {
      promptTokens,
      completionTokens,
      totalTokens: promptTokens + completionTokens,
      exactTokens: true,
    })
  } catch (error) {
    console.error(`Local ${displayName} (${modelId}) failed at ${stage}`, error)
    const errorMessages = {
      download: `ดาวน์โหลดไฟล์ ${displayName} ไม่สำเร็จ ตรวจสอบการเชื่อมต่อแล้วส่งอีกครั้ง`,
      initialize: `เปิดตัวประมวลผล ${displayName} ไม่สำเร็จ ลองปิดแท็บอื่นแล้วส่งอีกครั้ง`,
      generate: `${displayName} ประมวลผลข้อความไม่สำเร็จ ลองส่งคำถามที่สั้นลง`,
    }
    emit('failure', errorMessages[stage])
  } finally {
    port.close()
  }
})
