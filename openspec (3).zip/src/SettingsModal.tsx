import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import {
  Check,
  Copy,
  Database,
  Download,
  FileText,
  HelpCircle,
  LogOut,
  Monitor,
  Moon,
  Settings,
  Sun,
  User,
  X,
} from './icons'
import type {
  AccentColor,
  AuthUser,
  LanguagePreference,
  SettingsTab,
  ThemePreference,
  Workspace,
  WorkspaceSettings,
} from './api'
import { errorMessage } from './api'
import { commands } from './Composer'
import { ProfileAvatar } from './ProfileAvatar'
import { copyText } from './clipboard'
import { trapTab } from './focusTrap'
import { prepareProfileImage } from './profileImage'
import { IOS_EASE, IOS_SHEET_SPRING, IOS_SNAPPY_SPRING, IOS_SOFT_SPRING } from './motion'

export const ACCENT_SWATCHES: AccentColor[] = [
  '#4a8dff',
  '#2f6df0',
  '#1fa3e8',
  '#a855f7',
  '#ec4899',
  '#f59e0b',
  '#84cc16',
  '#8b8b92',
]

export type SettingsTabMeta = {
  id: SettingsTab
  label: string
  icon: typeof Settings
}

export const SETTINGS_TABS: SettingsTabMeta[] = [
  { id: 'general', label: 'ทั่วไป', icon: Settings },
  { id: 'account', label: 'โปรไฟล์', icon: User },
  { id: 'privacy', label: 'ข้อมูลและความเป็นส่วนตัว', icon: Database },
  { id: 'about', label: 'เกี่ยวกับ OPENSPEC', icon: FileText },
]

export function SettingsModal({
  tab,
  showAppearance,
  workspace,
  authUser,
  busy,
  error,
  onSelectTab,
  onSaveSettings,
  onBulkAction,
  onExportAll,
  onOpenShortcuts,
  onLogout,
  onClose,
}: {
  tab: SettingsTab
  showAppearance: boolean
  workspace: Workspace
  authUser: AuthUser | null
  busy: boolean
  error: string
  onSelectTab(next: SettingsTab): void
  onSaveSettings(patch: Partial<WorkspaceSettings> & { name?: string }): Promise<boolean>
  onBulkAction(action: 'archive-all' | 'restore-archived' | 'delete-all' | 'reset-account'): Promise<boolean>
  onExportAll(): void
  onOpenShortcuts(): void
  onLogout(): void
  onClose(): void
}) {
  const { settings, archivedChats } = workspace
  const [accountName, setAccountName] = useState(workspace.name)
  const [accountEmail, setAccountEmail] = useState(settings.email)
  const [avatarError, setAvatarError] = useState('')
  const [preparingAvatar, setPreparingAvatar] = useState(false)
  const avatarInput = useRef<HTMLInputElement>(null)
  const [copiedId, setCopiedId] = useState(false)
  const [feedback, setFeedback] = useState('')
  const [confirmDanger, setConfirmDanger] = useState<'delete-all' | 'reset-account' | null>(null)
  const dialogRef = useRef<HTMLDivElement>(null)
  const bodyRef = useRef<HTMLDivElement>(null)
  const appearanceRef = useRef<HTMLHeadingElement>(null)

  useEffect(() => {
    const previous = document.activeElement
    return () => {
      if (previous instanceof HTMLElement && previous.isConnected) previous.focus({ preventScroll: true })
    }
  }, [])

  useEffect(() => {
    setAccountName(workspace.name)
    setAccountEmail(workspace.settings.email)
  }, [workspace.name, workspace.settings.email])

  useEffect(() => {
    setFeedback('')
    setConfirmDanger(null)
    setAvatarError('')
    if (bodyRef.current) {
      bodyRef.current.scrollTop = 0
    }
    const frame = requestAnimationFrame(() => {
      if (tab === 'general' && showAppearance) {
        appearanceRef.current?.focus({ preventScroll: true })
        appearanceRef.current?.scrollIntoView({ block: 'start' })
      } else if (!dialogRef.current?.contains(document.activeElement)) {
        dialogRef.current?.focus({ preventScroll: true })
      }
    })
    return () => cancelAnimationFrame(frame)
  }, [tab, showAppearance])

  useEffect(() => {
    if (!feedback) return
    const timer = setTimeout(() => setFeedback(''), 2600)
    return () => clearTimeout(timer)
  }, [feedback])

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key === 'Escape' && !busy) {
        event.preventDefault()
        onClose()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [busy, onClose])

  const displayName = workspace.name || 'ผู้ใช้'
  const photoURL = settings.avatar || authUser?.photoURL
  const aiModelName = workspace.models.find(item => item.id === 'ai')?.name
  const currentTabMeta = SETTINGS_TABS.find(item => item.id === tab) ?? SETTINGS_TABS[0]

  async function savePatch(
    patch: Partial<WorkspaceSettings> & { name?: string },
    successText: string,
  ) {
    setFeedback('')
    const ok = await onSaveSettings(patch)
    if (ok) {
      setFeedback(successText)
    }
  }

  async function changeAvatar(file: File) {
    setAvatarError('')
    setPreparingAvatar(true)
    try {
      const avatar = await prepareProfileImage(file)
      await savePatch({ avatar }, 'เปลี่ยนรูปโปรไฟล์แล้ว')
    } catch (failure) {
      setAvatarError(errorMessage(failure))
    } finally {
      setPreparingAvatar(false)
    }
  }

  async function copyPublicId() {
    if (await copyText(workspace.publicId)) {
      setCopiedId(true)
      setTimeout(() => setCopiedId(false), 1800)
    } else {
      setFeedback('ไม่สามารถคัดลอกอัตโนมัติได้')
    }
  }

  return (
    <motion.div
      className="oc-overlay"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.18, ease: IOS_EASE }}
      onMouseDown={event => {
        if (event.target === event.currentTarget && !busy) {
          onClose()
        }
      }}
    >
      <motion.div
        ref={dialogRef}
        className="oc-modal oc-settings"
        role="dialog"
        tabIndex={-1}
        aria-modal="true"
        aria-labelledby="sTitle"
        onKeyDown={event => trapTab(event, dialogRef.current)}
        initial={{ opacity: 0, scale: 0.965, y: 8 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.97, y: 6 }}
        transition={IOS_SHEET_SPRING}
      >
        <aside className="oc-snav" aria-label="หมวดหมู่การตั้งค่า">
          <h2>การตั้งค่า</h2>
          <div id="snavList">
            {SETTINGS_TABS.map(item => {
              const TabIcon = item.icon
              const isActive = item.id === tab
              return (
                <motion.button
                  key={item.id}
                  type="button"
                  className={'oc-nb' + (isActive ? ' on' : '')}
                  aria-current={isActive ? 'page' : undefined}
                  disabled={busy}
                  whileTap={busy ? undefined : { scale: 0.98 }}
                  transition={IOS_SNAPPY_SPRING}
                  onClick={() => onSelectTab(item.id)}
                >
                  {isActive && (
                    <motion.span
                      layoutId="settings-tab-pill"
                      className="oc-nb-bg"
                      transition={IOS_SNAPPY_SPRING}
                      aria-hidden="true"
                    />
                  )}
                  <TabIcon size={17} className="relative z-1" />
                  <span className="relative z-1">{item.label}</span>
                </motion.button>
              )
            })}
          </div>
          <div className="oc-logout flex flex-col gap-0.5">
            <motion.button
              type="button"
              className="oc-nb"
              whileTap={{ scale: 0.98 }}
              transition={IOS_SNAPPY_SPRING}
              onClick={onOpenShortcuts}
            >
              <HelpCircle size={17} />
              <span>คีย์ลัดแป้นพิมพ์</span>
            </motion.button>
            <motion.button
              type="button"
              className="oc-nb oc-nb-danger"
              disabled={busy}
              whileTap={busy ? undefined : { scale: 0.98 }}
              transition={IOS_SNAPPY_SPRING}
              onClick={onLogout}
            >
              <LogOut size={17} />
              <span>ออกจากระบบ</span>
            </motion.button>
          </div>
        </aside>

        <section className="oc-spane">
          <header className="oc-ph oc-spane-head">
            <h2 id="sTitle">{currentTabMeta.label}</h2>
            <motion.button
              type="button"
              className="oc-x"
              aria-label="ปิดการตั้งค่า"
              disabled={busy}
              whileTap={busy ? undefined : { scale: 0.88 }}
              transition={IOS_SNAPPY_SPRING}
              onClick={onClose}
            >
              <X size={16} />
            </motion.button>
          </header>

          <div className="oc-spane-body" ref={bodyRef}>
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={tab}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -3 }}
                transition={{ duration: 0.16, ease: IOS_EASE }}
              >
            {tab === 'general' && (
              <>
                <button
                  type="button"
                  className="oc-card oc-row"
                  style={{ marginTop: 20 }}
                  onClick={() => onSelectTab('account')}
                >
                  <ProfileAvatar name={displayName} src={photoURL} size={34} />
                  <span>
                    <b>บัญชี OPENSPEC ({displayName})</b>
                    <small>{settings.email || 'จัดการชื่อ อีเมล และรหัส Workspace'}</small>
                  </span>
                </button>

                <div className="oc-card oc-row">
                  <label htmlFor="setting-language" style={{ flex: 1 }}>
                    <b>ภาษาเริ่มต้น</b>
                  </label>
                  <select
                    id="setting-language"
                    className="oc-select"
                    disabled={busy}
                    value={settings.language}
                    onChange={event => {
                      const language = event.target.value as LanguagePreference
                      void savePatch({ language }, 'บันทึกการตั้งค่าภาษาแล้ว')
                    }}
                  >
                    <option value="th">ไทย (TH)</option>
                    <option value="en">English (US)</option>
                    <option value="ja">日本語 (JA)</option>
                  </select>
                </div>

                <div className="oc-card oc-row">
                  <label htmlFor="setting-timezone" style={{ flex: 1 }}>
                    <b>เขตเวลา (Time zone)</b>
                  </label>
                  <select
                    id="setting-timezone"
                    className="oc-select"
                    disabled={busy}
                    value={settings.timezone}
                    onChange={event => {
                      void savePatch({ timezone: event.target.value }, 'บันทึกเขตเวลาแล้ว')
                    }}
                  >
                    <option value="Asia/Bangkok">อัตโนมัติ (Asia/Bangkok)</option>
                    <option value="UTC">UTC</option>
                    <option value="America/New_York">America/New_York</option>
                    <option value="Asia/Tokyo">Asia/Tokyo</option>
                  </select>
                </div>

                <h3 className="oc-lbl" ref={appearanceRef} tabIndex={-1}>รูปลักษณ์</h3>
                <div className="oc-card">
                  <div className="oc-row">
                    <b>โหมดหน้าจอ</b>
                    <div className="oc-seg" role="group" aria-label="โหมดการแสดงผล">
                      {(
                        [
                          ['light', 'โหมดสว่าง', Sun],
                          ['dark', 'โหมดมืด', Moon],
                          ['system', 'ตามระบบ', Monitor],
                        ] as const
                      ).map(([modeId, modeLabel, ModeIcon]) => {
                        const isSelected = settings.theme === modeId
                        return (
                          <button
                            key={modeId}
                            type="button"
                            aria-label={modeLabel}
                            title={modeLabel}
                            aria-pressed={isSelected}
                            className={isSelected ? 'on' : ''}
                            disabled={busy}
                            onClick={() => {
                              void savePatch({ theme: modeId as ThemePreference }, `เปลี่ยนเป็น${modeLabel}แล้ว`)
                            }}
                          >
                            {isSelected && (
                              <motion.span
                                layoutId="theme-seg-pill"
                                className="oc-seg-bg"
                                transition={IOS_SNAPPY_SPRING}
                                aria-hidden="true"
                              />
                            )}
                            <ModeIcon size={15} className="relative z-1" />
                          </button>
                        )
                      })}
                    </div>
                  </div>
                  <div className="oc-row" style={{ marginTop: 14 }}>
                    <b>สีเน้นธีม (Theme color)</b>
                  </div>
                  <div className="oc-sw" role="group" aria-label="สีธีม">
                    {ACCENT_SWATCHES.map((swatch, index) => {
                      const isSelected = settings.accentColor === swatch
                      return (
                        <motion.button
                          key={swatch}
                          type="button"
                          style={{ background: swatch }}
                          aria-label={`สีธีม ${index + 1}`}
                          aria-pressed={isSelected}
                          className={isSelected ? 'on' : ''}
                          disabled={busy}
                          whileTap={busy ? undefined : { scale: 0.85 }}
                          transition={IOS_SNAPPY_SPRING}
                          onClick={() => {
                            void savePatch({ accentColor: swatch }, 'บันทึกสีเน้นธีมแล้ว')
                          }}
                        >
                          {isSelected && (
                            <motion.span
                              layoutId="accent-swatch-ring"
                              className="oc-sw-ring"
                              transition={IOS_SNAPPY_SPRING}
                              aria-hidden="true"
                            />
                          )}
                        </motion.button>
                      )
                    })}
                  </div>
                </div>
              </>
            )}

            {tab === 'account' && (
              <>
                <form
                  onSubmit={event => {
                    event.preventDefault()
                    void savePatch(
                      { name: accountName.trim(), email: accountEmail.trim() },
                      'บันทึกข้อมูลบัญชี OPENSPEC แล้ว',
                    )
                  }}
                >
                  <div className="oc-card" style={{ marginTop: 20 }}>
                    <div className="oc-profile-photo">
                      <ProfileAvatar name={displayName} src={photoURL} size={64} />
                      <div className="oc-profile-photo-info">
                        <b>{displayName}</b>
                        <small>
                          {authUser && `เข้าสู่ระบบด้วย ${
                            authUser.provider === 'discord'
                              ? 'Discord (OAuth2)'
                              : authUser.provider === 'github'
                                ? 'GitHub (Firebase)'
                                : authUser.provider === 'google'
                                  ? 'Google (Firebase)'
                                  : 'Email (Firebase)'
                          }`}
                        </small>
                        <div className="oc-profile-photo-actions">
                          <button type="button" className="oc-sm" disabled={busy || preparingAvatar} onClick={() => avatarInput.current?.click()}>
                            {preparingAvatar ? 'กำลังเตรียมรูป...' : 'เปลี่ยนรูป'}
                          </button>
                          {settings.avatar && (
                            <button type="button" className="oc-link" disabled={busy || preparingAvatar}
                              onClick={() => {
                                setAvatarError('')
                                void savePatch({ avatar: '' }, 'ใช้รูปเริ่มต้นแล้ว')
                              }}>
                              ใช้รูปเริ่มต้น
                            </button>
                          )}
                        </div>
                      </div>
                      <input
                        ref={avatarInput}
                        type="file"
                        accept="image/jpeg,image/png,image/webp"
                        hidden
                        onChange={event => {
                          const file = event.currentTarget.files?.[0]
                          event.currentTarget.value = ''
                          if (file) void changeAvatar(file)
                        }}
                      />
                    </div>
                    {avatarError && <p className="error" role="alert">{avatarError}</p>}

                    <label htmlFor="account-name" className="oc-lbl" style={{ display: 'block', marginTop: 6 }}>ชื่อที่แสดง</label>
                    <input
                      id="account-name"
                      className="oc-field"
                      maxLength={40}
                      placeholder="ผู้ใช้"
                      disabled={busy}
                      value={accountName}
                      onChange={event => setAccountName(event.target.value)}
                    />

                    <label htmlFor="account-email" className="oc-lbl" style={{ display: 'block', marginTop: 14 }}>อีเมลติดต่อ</label>
                    <input
                      id="account-email"
                      type="email"
                      className="oc-field"
                      maxLength={120}
                      placeholder="you@example.com"
                      disabled={busy}
                      value={accountEmail}
                      onChange={event => setAccountEmail(event.target.value)}
                    />

                    <div className="oc-lbl" style={{ marginTop: 14 }}>รหัส Workspace สาธารณะ</div>
                    <div className="oc-readonly">
                      <code className="text-xs">{workspace.publicId}</code>
                      <button
                        type="button"
                        className="oc-copy-btn"
                        aria-label={copiedId ? 'คัดลอกรหัส Workspace แล้ว' : 'คัดลอกรหัส Workspace'}
                        onClick={() => void copyPublicId()}
                      >
                        {copiedId ? <Check size={14} /> : <Copy size={14} />}
                        <span>{copiedId ? 'คัดลอกแล้ว' : 'คัดลอก'}</span>
                      </button>
                    </div>

                    <button
                      type="submit"
                      className="oc-primary"
                      style={{ marginTop: 18 }}
                      disabled={busy}
                    >
                      บันทึกข้อมูลบัญชี
                    </button>
                  </div>
                </form>

                <div className="oc-card oc-danger-card" style={{ marginTop: 14 }}>
                  <div className="oc-row">
                    <span>
                      <b>รีเซ็ตบัญชีและพื้นที่ทำงาน</b>
                      <small>ลบแชต โปรเจกต์ และอาร์ติแฟกต์ แล้วคืนการตั้งค่าเริ่มต้น</small>
                    </span>
                    {confirmDanger === 'reset-account' ? (
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          className="oc-sm danger"
                          disabled={busy}
                          onClick={() => {
                            void onBulkAction('reset-account').then(ok => {
                              if (ok) {
                                setConfirmDanger(null)
                                setFeedback('รีเซ็ตพื้นที่ทำงานเรียบร้อยแล้ว')
                              }
                            })
                          }}
                        >
                          ยืนยันรีเซ็ต
                        </button>
                        <button
                          type="button"
                          className="oc-sm"
                          disabled={busy}
                          onClick={() => setConfirmDanger(null)}
                        >
                          ยกเลิก
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        className="oc-sm danger"
                        disabled={busy}
                        onClick={() => setConfirmDanger('reset-account')}
                      >
                        รีเซ็ตบัญชี
                      </button>
                    )}
                  </div>
                </div>
              </>
            )}

            {tab === 'privacy' && (
              <>
                <div className="oc-lbl">ความเป็นส่วนตัวและการควบคุมข้อมูล</div>
                <div className="oc-card oc-row">
                  <span>
                    <b>ส่งออกข้อมูลแชตทั้งหมด</b>
                    <small>ดาวน์โหลดประวัติแชตและไฟล์สรุปเป็น JSON</small>
                  </span>
                  <button
                    type="button"
                    className="oc-sm"
                    disabled={busy}
                    onClick={onExportAll}
                  >
                    <Download size={13} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 5 }} />
                    ส่งออก JSON
                  </button>
                </div>

                <div className="oc-card oc-row">
                  <span>
                    <b>เก็บถาวรแชตทั้งหมด</b>
                    <small>
                      ใช้งานอยู่ {workspace.chats.length} · เก็บถาวร {archivedChats.length} แชต
                    </small>
                  </span>
                  <div className="flex flex-wrap items-center gap-2">
                    {archivedChats.length > 0 && (
                      <button
                        type="button"
                        className="oc-sm"
                        disabled={busy}
                        onClick={() => {
                          void onBulkAction('restore-archived').then(ok => {
                            if (ok) setFeedback('กู้คืนแชตจากคลังเก็บถาวรแล้ว')
                          })
                        }}
                      >
                        กู้คืน ({archivedChats.length})
                      </button>
                    )}
                    <button
                      type="button"
                      className="oc-sm"
                      disabled={busy || workspace.chats.length === 0}
                      onClick={() => {
                        void onBulkAction('archive-all').then(ok => {
                          if (ok) setFeedback('เก็บถาวรแชตทั้งหมดแล้ว')
                        })
                      }}
                    >
                      เก็บถาวรทั้งหมด
                    </button>
                  </div>
                </div>

                <div className="oc-card oc-row oc-danger-card">
                  <span>
                    <b>ลบแชตทั้งหมด</b>
                    <small>ลบประวัติแชตที่ใช้งานและเก็บถาวรจากเบราว์เซอร์นี้</small>
                  </span>
                  {confirmDanger === 'delete-all' ? (
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        className="oc-sm danger"
                        disabled={busy}
                        onClick={() => {
                          void onBulkAction('delete-all').then(ok => {
                            if (ok) {
                              setConfirmDanger(null)
                              setFeedback('ลบประวัติแชตทั้งหมดแล้ว')
                            }
                          })
                        }}
                      >
                        ยืนยันลบทั้งหมด
                      </button>
                      <button
                        type="button"
                        className="oc-sm"
                        disabled={busy}
                        onClick={() => setConfirmDanger(null)}
                      >
                        ยกเลิก
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      className="oc-sm danger"
                      disabled={busy || (workspace.chats.length === 0 && archivedChats.length === 0)}
                      onClick={() => setConfirmDanger('delete-all')}
                    >
                      ลบทั้งหมด
                    </button>
                  )}
                </div>
              </>
            )}

            {tab === 'about' && (
              <>
                <div className="oc-card" style={{ marginTop: 20 }}>
                  <div className="oc-row">
                    <b>แพลตฟอร์ม</b>
                    <span className="oc-sp">OPENSPEC Full-Stack Workspace</span>
                  </div>
                </div>
                <div className="oc-card">
                  <div className="oc-row">
                    <b>ระบบประมวลผล</b>
                    <span className="oc-sp">
                      {aiModelName ? `${aiModelName} + Local UTF-8` : 'Local UTF-8 Engine'}
                    </span>
                  </div>
                </div>
                <div className="oc-card">
                  <div className="oc-row">
                    <b>คำสั่ง Slash ในหน้าแชต</b>
                    <span className="oc-sp">{commands.length} คำสั่ง</span>
                  </div>
                </div>
                <div className="oc-card oc-row">
                  <b>ข้อกำหนดการใช้งาน</b>
                  <a className="oc-sm" href="/terms" target="_blank" rel="noopener noreferrer" aria-label="อ่านข้อกำหนดการใช้งาน">อ่าน</a>
                </div>
                <div className="oc-card oc-row">
                  <b>นโยบายความเป็นส่วนตัว</b>
                  <a className="oc-sm" href="/privacy" target="_blank" rel="noopener noreferrer" aria-label="อ่านนโยบายความเป็นส่วนตัว">อ่าน</a>
                </div>
              </>
            )}

            {error && (
              <p className="error" role="alert">
                {error}
              </p>
            )}
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="oc-toast-wrap" aria-live="polite">
            <AnimatePresence>
              {feedback && (
                <motion.div
                  key={feedback}
                  className="oc-toast"
                  role="status"
                  initial={{ opacity: 0, y: 10, scale: 0.94 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.95 }}
                  transition={IOS_SNAPPY_SPRING}
                >
                  <Check size={14} />
                  <span>{feedback}</span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </section>
      </motion.div>
    </motion.div>
  )
}
