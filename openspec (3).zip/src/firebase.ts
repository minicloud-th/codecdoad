import { getApp, getApps, initializeApp } from 'firebase/app'
import type { FirebaseApp } from 'firebase/app'
import { getAnalytics, isSupported as isAnalyticsSupported } from 'firebase/analytics'
import type { Analytics } from 'firebase/analytics'
import { GithubAuthProvider, GoogleAuthProvider, getAuth } from 'firebase/auth'
import type { Auth, User } from 'firebase/auth'
import type { AuthUser } from './api'

// Public Firebase web app identifiers used for existing account sign-ins.
const firebaseConfig = {
  apiKey: 'AIzaSyDlFf4H-P0TDgZN5gUoZS8-FN13KrPD514',
  authDomain: 'openspec-oauth.firebaseapp.com',
  projectId: 'openspec-oauth',
  storageBucket: 'openspec-oauth.firebasestorage.app',
  messagingSenderId: '531184852262',
  appId: '1:531184852262:web:a381e0cbc9c75e9416b5e7',
  measurementId: 'G-26NQ7XZTYN',
}

let app: FirebaseApp | null = null
let authInstance: Auth | null = null
let analyticsInstance: Analytics | null = null

try {
  app = getApps().length ? getApp() : initializeApp(firebaseConfig)
  authInstance = getAuth(app)
  authInstance.useDeviceLanguage()
  if (typeof window !== 'undefined') {
    void isAnalyticsSupported()
      .then((supported) => {
        if (supported && app) {
          analyticsInstance = getAnalytics(app)
        }
      })
      .catch(() => {})
  }
} catch {
  // Leave the sign-in screen available to explain Firebase initialization errors.
}

export const firebaseAuth = authInstance
export const getFirebaseAnalytics = () => analyticsInstance

function providerPhotoURL(photoURL: string | null | undefined): string | undefined {
  if (!photoURL) return
  try {
    const url = new URL(photoURL)
    const allowedHost =
      /^lh[3-6]\.googleusercontent\.com$/.test(url.hostname) ||
      url.hostname === 'avatars.githubusercontent.com'
    if (url.protocol === 'https:' && allowedHost &&
      !url.port && !url.username && !url.password) return url.href
  } catch {
    return undefined
  }
}

export function accountFromFirebase(user: User, provider?: AuthUser['provider']): AuthUser {
  const googleProfile = user.providerData.find(item => item.providerId === 'google.com')
  const githubProfile = user.providerData.find(item => item.providerId === 'github.com')
  const resolvedProvider: AuthUser['provider'] =
    provider ??
    (user.providerData[0]?.providerId === 'github.com'
      ? 'github'
      : user.providerData[0]?.providerId === 'google.com'
        ? 'google'
        : 'email')
  const rawPhoto =
    resolvedProvider === 'github'
      ? (githubProfile?.photoURL ?? user.photoURL)
      : (googleProfile?.photoURL ?? (googleProfile || resolvedProvider === 'google' ? user.photoURL : undefined))
  const photoURL = providerPhotoURL(rawPhoto)
  return {
    id: user.uid,
    email: user.email ?? '',
    name: user.displayName ?? '',
    provider: resolvedProvider,
    photoURL,
  }
}

export const googleProvider = new GoogleAuthProvider()
googleProvider.setCustomParameters({ prompt: 'select_account' })

export const githubProvider = new GithubAuthProvider()

export function firebaseErrorMessage(error: unknown): string {
  const code =
    typeof error === 'object' && error !== null && 'code' in error
      ? String((error as { code?: unknown }).code)
      : ''

  switch (code) {
    case 'auth/popup-closed-by-user':
    case 'auth/cancelled-popup-request':
      return 'ปิดหน้าต่างเข้าสู่ระบบก่อนดำเนินการเสร็จสิ้น'
    case 'auth/account-exists-with-different-credential':
      return 'อีเมลนี้ผูกกับผู้ให้บริการเข้าสู่ระบบอื่นไว้แล้ว กรุณาใช้วิธีที่เคยลงทะเบียน'
    case 'auth/popup-blocked':
      return 'เบราว์เซอร์บล็อกหน้าต่างป๊อปอัป กรุณาอนุญาตป๊อปอัปแล้วลองอีกครั้ง'
    case 'auth/unauthorized-domain':
      return `โดเมน ${typeof window !== 'undefined' ? window.location.hostname : ''} ยังไม่ได้รับอนุญาตใน Firebase Authentication → Settings → Authorized domains`
    case 'auth/operation-not-allowed':
      return 'ผู้ให้บริการนี้ยังไม่ถูกเปิดใช้งานใน Firebase Console → Authentication → Sign-in method'
    case 'auth/invalid-email':
      return 'รูปแบบอีเมลไม่ถูกต้อง'
    case 'auth/invalid-credential':
    case 'auth/user-not-found':
    case 'auth/wrong-password':
      return 'อีเมลหรือรหัสผ่านไม่ถูกต้อง'
    case 'auth/email-already-in-use':
      return 'อีเมลนี้ลงทะเบียนไว้แล้ว ลองเข้าสู่ระบบแทน'
    case 'auth/weak-password':
      return 'รหัสผ่านต้องมีความยาวอย่างน้อย 8 ตัวอักษรและคาดเดายาก'
    case 'auth/too-many-requests':
      return 'มีคำขอมากเกินไป กรุณารอสักครู่แล้วลองใหม่อีกครั้ง'
    case 'auth/network-request-failed':
      return 'เชื่อมต่อเครือข่าย Firebase ไม่ได้ ลองตรวจสอบการเชื่อมต่อแล้วลองใหม่'
    default:
      return error instanceof Error ? error.message : 'เข้าสู่ระบบด้วย Firebase ไม่สำเร็จ ลองอีกครั้ง'
  }
}
