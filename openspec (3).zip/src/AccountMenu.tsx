import { motion } from 'motion/react'
import {
  ChevronRight,
  CreditCard,
  Gauge,
  HelpCircle,
  Download,
  Keyboard,
  Lightbulb,
  LogOut,
  Palette,
  Plug,
  Settings,
  UserRound,
  Wifi,
} from './icons'
import { DropdownMenu } from 'radix-ui'
import type { DashboardStats, SettingsTab } from './api'
import { IOS_SNAPPY_SPRING } from './motion'
import type { RailSection } from './navigation'
import { ProfileAvatar } from './ProfileAvatar'
import { useMobileNav } from './useMobileNav'

type AccountMenuProps = {
  name: string
  photoURL?: string
  disabled: boolean
  open: boolean
  section?: RailSection
  stats?: DashboardStats
  onOpenChange(open: boolean): void
  onSelectSection?(section: RailSection): void
  onSettings(tab: SettingsTab, showAppearance?: boolean): void
  onHelp(): void
  onShortcuts(): void
  onStatus(): void
  onExport(): void
  onAccount(): void
}

function remainingLabel(used = 0, limit = 0) {
  const remaining = limit > 0 ? Math.min(100, Math.max(0, 100 * (limit - used) / limit)) : 0
  return remaining > 0 && remaining < 1 ? '<1%' : Math.floor(remaining) + '%'
}

export function AccountMenu({
  name, photoURL, disabled, open, section, stats, onOpenChange, onSelectSection,
  onSettings, onHelp, onShortcuts, onStatus, onExport, onAccount,
}: AccountMenuProps) {
  const isMobile = useMobileNav()
  const mobileSecondaryActive =
    isMobile &&
    (section === 'subscription' || section === 'plugins' || section === 'ideas' || section === 'dashboard')
  const fiveHourRemaining = stats ? remainingLabel(stats.fiveHourUsed, stats.fiveHourLimit) : null
  const workspaceRemaining = stats
    ? remainingLabel(
        Math.max(stats.totalChats / Math.max(1, stats.chatLimit), stats.storageBytes / Math.max(1, stats.maxStorageBytes)),
        1,
      )
    : null

  return (
    <DropdownMenu.Root open={open} onOpenChange={onOpenChange} modal={false}>
      <DropdownMenu.Trigger
        id="rail-account-trigger"
        className={'oc-rb oc-account-trigger' + (mobileSecondaryActive ? ' on' : '')}
        aria-label="โปรไฟล์และการตั้งค่า"
        title="โปรไฟล์และการตั้งค่า"
        disabled={disabled}
      >
        {mobileSecondaryActive && (
          <motion.span
            layoutId="rail-active-pill"
            className="oc-rb-bg"
            transition={IOS_SNAPPY_SPRING}
            aria-hidden="true"
          />
        )}
        <span className="oc-rb-icon">
          <ProfileAvatar name={name} src={photoURL} size={isMobile ? 24 : 31} />
        </span>
        <span className="oc-rb-label">บัญชี</span>
      </DropdownMenu.Trigger>
      <DropdownMenu.Portal>
        <DropdownMenu.Content
          className="oc-account-menu"
          aria-label="โปรไฟล์และการตั้งค่า"
          side={isMobile ? 'top' : 'right'}
          sideOffset={isMobile ? 12 : 10}
          align="end"
          collisionPadding={10}
          onCloseAutoFocus={event => {
            if (isMobile) event.preventDefault()
          }}
          loop
        >
          <DropdownMenu.Label className="oc-account-heading">
            <ProfileAvatar name={name} src={photoURL} size={36} />
            <span className="oc-account-identity">
              <strong>{name.trim() || 'ผู้ใช้ OPENSPEC'}</strong>
            </span>
          </DropdownMenu.Label>
          {isMobile && onSelectSection && (
            <>
              <DropdownMenu.Separator className="oc-account-divider" />
              <DropdownMenu.Item className="oc-account-item" onSelect={() => onSelectSection('subscription')}>
                <CreditCard size={17} /> Subscription
              </DropdownMenu.Item>
              <DropdownMenu.Item className="oc-account-item" onSelect={() => onSelectSection('plugins')}>
                <Plug size={17} /> ปลั๊กอิน
              </DropdownMenu.Item>
              <DropdownMenu.Item className="oc-account-item" onSelect={() => onSelectSection('ideas')}>
                <Lightbulb size={17} /> เทมเพลตคำสั่ง
              </DropdownMenu.Item>
              <DropdownMenu.Item className="oc-account-item" onSelect={() => onSelectSection('dashboard')}>
                <Gauge size={17} /> การใช้งาน
                {fiveHourRemaining && workspaceRemaining && (
                  <span className="oc-account-item-trailing">AI {fiveHourRemaining} · WS {workspaceRemaining}</span>
                )}
              </DropdownMenu.Item>
            </>
          )}
          <DropdownMenu.Separator className="oc-account-divider" />
          <DropdownMenu.Item className="oc-account-item" onSelect={() => onSettings('general', true)}>
            <Palette size={17} /> ปรับแต่งธีม
          </DropdownMenu.Item>
          <DropdownMenu.Item className="oc-account-item" onSelect={() => onSettings('account')}>
            <UserRound size={17} /> โปรไฟล์
          </DropdownMenu.Item>
          <DropdownMenu.Item className="oc-account-item" onSelect={() => onSettings('general')}>
            <Settings size={17} /> การตั้งค่า
          </DropdownMenu.Item>
          <DropdownMenu.Separator className="oc-account-divider" />
          <DropdownMenu.Sub>
            <DropdownMenu.SubTrigger className="oc-account-item">
              <HelpCircle size={17} /> วิธีใช้
              <ChevronRight size={15} className="oc-account-item-trailing" />
            </DropdownMenu.SubTrigger>
            <DropdownMenu.Portal>
              <DropdownMenu.SubContent className="oc-account-menu oc-account-submenu" sideOffset={8} collisionPadding={10} loop>
                <DropdownMenu.Item className="oc-account-item" onSelect={onHelp}>
                  <HelpCircle size={17} /> คำสั่งและคู่มือ
                </DropdownMenu.Item>
                <DropdownMenu.Item className="oc-account-item" onSelect={onShortcuts}>
                  <Keyboard size={17} /> คีย์ลัดแป้นพิมพ์
                  <kbd className="oc-account-item-trailing">Ctrl+/</kbd>
                </DropdownMenu.Item>
                <DropdownMenu.Item className="oc-account-item" onSelect={onStatus}>
                  <Wifi size={17} /> สถานะการเชื่อมต่อ
                </DropdownMenu.Item>
                <DropdownMenu.Item className="oc-account-item" onSelect={onExport}>
                  <Download size={17} /> ส่งออกแชตเป็น JSON
                </DropdownMenu.Item>
              </DropdownMenu.SubContent>
            </DropdownMenu.Portal>
          </DropdownMenu.Sub>
          <DropdownMenu.Item
            className="oc-account-item oc-account-signout"
            onSelect={onAccount}
          >
            <LogOut size={17} /> ออกจากระบบ
          </DropdownMenu.Item>
        </DropdownMenu.Content>
      </DropdownMenu.Portal>
    </DropdownMenu.Root>
  )
}
