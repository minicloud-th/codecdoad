import { useEffect, useRef, useState } from 'react'
import Markdown from 'react-markdown'
import type { Components } from 'react-markdown'
import { SearchTool } from '@/components/ui/search-tool'
import type { SearchResult } from '@/components/ui/search-tool'
import { StreamingResponse } from '@/components/ui/streaming-response'
import type { StreamingResponseStatus } from '@/components/ui/streaming-response'
import type { Turn } from './api'
import { copyText } from './clipboard'
import { neutralizeStreamingLabel, resolveTurnToolSituation } from './composerLogic'
import { Check, Copy } from './icons'

function CodeCopyButton({ label, getText }: { label: string; getText(): string }) {
  const [status, setStatus] = useState<'idle' | 'copied' | 'failed'>('idle')

  useEffect(() => {
    if (status === 'idle') return
    const timeout = window.setTimeout(() => setStatus('idle'), 2400)
    return () => window.clearTimeout(timeout)
  }, [status])

  return (
    <span className="reply-copy">
      <button type="button" className="oc-copy-btn" aria-label={label}
        onClick={async () => setStatus(await copyText(getText()) ? 'copied' : 'failed')}>
        {status === 'copied' ? <Check size={14} /> : <Copy size={14} />}
        {status === 'copied' ? 'คัดลอกแล้ว' : label}
      </button>
      <span className="sr-only" role="status">{status === 'copied' && 'คัดลอกแล้ว'}</span>
      {status === 'failed' && <span role="status">คัดลอกอัตโนมัติไม่สำเร็จ</span>}
    </span>
  )
}

const markdownComponents: Components = {
  pre: function CodeBlock({ children }) {
    const code = useRef<HTMLPreElement>(null)
    return (
      <div className="reply-code">
        <CodeCopyButton label="คัดลอกโค้ด" getText={() => code.current?.textContent ?? ''} />
        <pre ref={code}>{children}</pre>
      </div>
    )
  },
}

export function ReplyContent({
  turn,
  status = 'complete',
  progressText,
  onRetry,
}: {
  turn: Turn
  status?: StreamingResponseStatus
  progressText?: string
  onRetry?: () => void
}) {
  const streaming = status === 'streaming'
  const hasFiles = turn.files.length > 0
  const situation = hasFiles || (streaming && !turn.reply)
    ? resolveTurnToolSituation({
        streaming,
        progressText: neutralizeStreamingLabel(progressText),
        fileCount: turn.files.length,
        prompt: turn.prompt,
        modelName: '',
      })
    : null
  const displaySituationLabel = situation
    ? (hasFiles && streaming && !progressText?.includes('ดาวน์โหลด')
        ? situation.label
        : streaming
          ? neutralizeStreamingLabel(progressText)
          : situation.label)
    : ''
  const fileResults: SearchResult[] = turn.files.map(file => ({
    title: file.name,
    source: file.preview?.kind === 'image'
      ? `${file.preview.width}×${file.preview.height}`
      : 'UTF-8',
  }))

  const body = turn.reply
    ? (turn.model === 'Workspace'
        ? <div className="plain-reply">{turn.reply}</div>
        : <Markdown components={markdownComponents} skipHtml disallowedElements={['img', 'a']} unwrapDisallowed>{turn.reply}</Markdown>)
    : null

  return (
    <>
      {situation && (
        <SearchTool
          className="mb-2"
          state={situation.state}
          query={hasFiles ? situation.query : ''}
          searchingLabel={displaySituationLabel}
          doneLabel={displaySituationLabel}
          headerLabel={situation.headerLabel}
          results={fileResults}
        />
      )}
      {(body || !streaming) && (
        <StreamingResponse
          status={status}
          copyText={turn.reply}
          onCopy={turn.reply ? async () => { await copyText(turn.reply) } : undefined}
          onRetry={onRetry}
          announce={false}
          contentClassName="text-[0.96rem] leading-[1.62] text-[var(--text)]"
          actionsClassName="mt-1"
        >
          {body}
        </StreamingResponse>
      )}
    </>
  )
}

