import { ApiError, byteLength } from './api'

export const PROJECT_DESCRIPTION_LIMIT = 600

export type Project = {
  id: string
  title: string
  chatIds: string[]
  description?: string
  pinned?: boolean
}
export type ArtifactFormat = 'md' | 'txt' | 'json'
export type Artifact = { id: string; title: string; format: ArtifactFormat; text: string }
export type WorkspaceContent = { projects: Project[]; artifacts: Artifact[] }

export type ContentAction =
  | { action: 'save-project'; id?: string; title: string; description?: string }
  | { action: 'pin-project'; id: string; pinned: boolean }
  | { action: 'add-project-chats'; id: string; chatIds: string[] }
  | { action: 'delete-project'; id: string }
  | { action: 'project-chat'; id: string; chatId: string; include: boolean }
  | { action: 'save-artifact'; id?: string; title: string; format: ArtifactFormat; text: string }
  | { action: 'delete-artifact'; id: string }

function requireTitle(title: unknown) {
  const clean = typeof title === 'string' ? title.trim() : ''
  if (!clean || clean.length > 100 || /[\x00-\x1f\x7f]/.test(clean)) {
    throw new ApiError('ใส่ชื่อไม่เกิน 100 ตัวอักษร', 400)
  }
  return clean
}

function findItem<T extends { id: string }>(items: T[], id: string) {
  const found = items.find(item => item.id === id)
  if (!found) throw new ApiError('ไม่พบรายการนี้', 404)
  return found
}

function requireProjectDescription(value: unknown) {
  if (typeof value !== 'string' || value.trim().length > PROJECT_DESCRIPTION_LIMIT) {
    throw new ApiError('ใส่รายละเอียดโปรเจกต์ไม่เกิน ' + PROJECT_DESCRIPTION_LIMIT + ' ตัวอักษร', 400)
  }
  return value.trim()
}

export function applyContentAction(content: WorkspaceContent, change: ContentAction, chats: { id: string }[]): string | undefined {
  switch (change.action) {
    case 'save-project': {
      const title = requireTitle(change.title)
      const description = change.description === undefined ? undefined : requireProjectDescription(change.description)
      const project = change.id === undefined
        ? { id: crypto.randomUUID(), title, chatIds: [] }
        : findItem(content.projects, change.id)
      project.title = title
      if (description !== undefined) project.description = description
      if (change.id === undefined) content.projects.unshift(project)
      return project.id
    }
    case 'pin-project': {
      if (typeof change.pinned !== 'boolean') throw new ApiError('สถานะปักหมุดไม่ถูกต้อง', 400)
      findItem(content.projects, change.id).pinned = change.pinned
      break
    }
    case 'add-project-chats': {
      const project = findItem(content.projects, change.id)
      if (!Array.isArray(change.chatIds) || !change.chatIds.length) throw new ApiError('เลือกแชตที่จะเพิ่ม', 400)
      for (const chatId of change.chatIds) findItem(chats, chatId)
      project.chatIds = [...new Set([...project.chatIds, ...change.chatIds])]
      break
    }
    case 'delete-project': {
      const project = findItem(content.projects, change.id)
      content.projects = content.projects.filter(item => item !== project)
      break
    }
    case 'project-chat': {
      const project = findItem(content.projects, change.id)
      if (change.include) {
        findItem(chats, change.chatId)
        if (!project.chatIds.includes(change.chatId)) project.chatIds.push(change.chatId)
      } else {
        project.chatIds = project.chatIds.filter(id => id !== change.chatId)
      }
      break
    }
    case 'save-artifact': {
      const title = requireTitle(change.title)
      const { format, text } = change
      if (format !== 'txt' && format !== 'md' && format !== 'json') throw new ApiError('เลือกประเภทไฟล์', 400)
      if (typeof text !== 'string' || !text.trim() || byteLength(text) > 64 * 1024) {
        throw new ApiError('ใส่เนื้อหาที่มีขนาดไม่เกิน 64 KiB', 400)
      }
      if (change.id === undefined) {
        content.artifacts.unshift({ id: crypto.randomUUID(), title, format, text })
      } else {
        Object.assign(findItem(content.artifacts, change.id), { title, format, text })
      }
      break
    }
    case 'delete-artifact': {
      const artifact = findItem(content.artifacts, change.id)
      content.artifacts = content.artifacts.filter(item => item !== artifact)
      break
    }
    default:
      throw new ApiError('ไม่พบคำสั่งจัดการพื้นที่ทำงานนี้', 400)
  }
}
