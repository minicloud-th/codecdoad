import type { CSSProperties, ReactNode } from 'react'

export function ProgressRing({ value, children }: { value?: number; children?: ReactNode }) {
  const fill = typeof value === 'number' ? Math.min(100, Math.max(0, value)) : undefined
  return (
    <span className={'progress-ring' + (fill === undefined ? ' progress-ring-loading' : '')}
      style={{ '--ring-progress': `${fill ?? 28}%` } as CSSProperties} aria-hidden="true">
      <span className="progress-ring-track" />
      {children}
    </span>
  )
}
