import { ApiError, byteLength, getWorkspaceAuthToken } from './api'
import { isLocalModelName } from './composerLogic'
import type { ModelMessage } from './composerLogic'
import type { AiReplyResult } from './localModel'
import { analyzeFilesReply, excerpt } from './server/chatLogic'
import type { AiUsageMetadata, Chat, SendRequest } from './server/types'
import { extractClientUsage } from './server/usageExtractors'

export async function generateApinexReply(
  input: SendRequest,
  chat: Chat,
  onProgress?: (message: string) => void,
  onStream?: (text: string) => void,
): Promise<AiReplyResult> {
  const prompt = input.prompt || 'อธิบายไฟล์ที่แนบ'
  let currentText = input.files.length
    ? `${prompt}\n\nAttached files (JSON):\n${JSON.stringify(input.files.map(({ name, content }) => ({ name, content })))}`
    : prompt

  if (byteLength(currentText) > 12000 && input.files.length > 0) {
    const autoReport = analyzeFilesReply(input.files)
    const condensed = `${prompt}\n\nAutomatic file analysis:\n${autoReport}`
    currentText = byteLength(condensed) <= 12000 ? condensed : excerpt(condensed, 4000)
  }
  if (byteLength(currentText) > 12000) {
    throw new ApiError('ข้อความยาวเกินขีดจำกัด AI ลองย่อข้อความให้สั้นลง', 400)
  }

  const messages: ModelMessage[] = []
  for (const turn of chat.turns.filter(turn => isLocalModelName(turn.model)).slice(-4)) {
    messages.push({ role: 'user', content: excerpt(turn.prompt || turn.files.map(file => file.name).join(', '), 600) })
    messages.push({ role: 'assistant', content: excerpt(turn.reply, 800) })
  }
  messages.push({ role: 'user', content: currentText })

  const token = await getWorkspaceAuthToken()
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'X-Requested-With': 'OPENSPEC',
  }
  if (token) {
    headers.Authorization = `Bearer ${token}`
  }

  onProgress?.('กำลังเชื่อมต่อ GLM-5.3 FlashX...')
  const response = await fetch('/api/ai/apinex', {
    method: 'POST',
    credentials: 'include',
    headers,
    body: JSON.stringify({
      effort: input.effort ?? 'Low',
      messages,
    }),
    signal: AbortSignal.timeout(95_000),
  })

  if (!response.ok) {
    let message = 'เชื่อมต่อ GLM-5.3 FlashX ไม่สำเร็จ กรุณาลองอีกครั้ง'
    try {
      const json = (await response.json()) as { error?: unknown }
      if (typeof json.error === 'string' && json.error.trim()) {
        message = json.error
      }
    } catch {
      // Preserve fallback error message.
    }
    throw new ApiError(message, response.status)
  }

  const contentType = response.headers.get('content-type') ?? ''
  if (contentType.includes('application/json')) {
    const json = (await response.json()) as { text?: unknown; error?: unknown; usage?: unknown }
    if (typeof json.error === 'string' && json.error.trim()) {
      throw new ApiError(json.error, response.status)
    }
    const text = typeof json.text === 'string' ? json.text : ''
    if (text) onStream?.(text)
    const usage = extractClientUsage(json.usage) ?? undefined
    return { text, ...(usage ? { usage } : {}) }
  }

  if (!response.body) {
    throw new ApiError('ไม่ได้รับสตรีมคำตอบจากเซิร์ฟเวอร์', 502)
  }

  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''
  let fullText = ''
  let usage: AiUsageMetadata | undefined
  let currentEvent = ''
  let currentDataLines: string[] = []

  const flushEvent = () => {
    if (!currentDataLines.length) {
      currentEvent = ''
      return
    }
    const rawData = currentDataLines.join('\n')
    currentDataLines = []
    const eventName = currentEvent || 'message'
    currentEvent = ''

    let parsed: Record<string, unknown>
    try {
      parsed = JSON.parse(rawData) as Record<string, unknown>
    } catch {
      return
    }

    if (eventName === 'progress' && typeof parsed.message === 'string') {
      onProgress?.(parsed.message)
    } else if (eventName === 'token' && typeof parsed.delta === 'string') {
      fullText += parsed.delta
      onStream?.(fullText)
    } else if (eventName === 'usage') {
      const parsedUsage = extractClientUsage(parsed)
      if (parsedUsage) usage = parsedUsage
    } else if (eventName === 'done') {
      const doneUsage = extractClientUsage(parsed.usage)
      if (doneUsage) usage = doneUsage
    } else if (eventName === 'error') {
      const errorMsg = typeof parsed.error === 'string' && parsed.error.trim()
        ? parsed.error
        : 'เชื่อมต่อ GLM-5.3 FlashX ไม่สำเร็จ'
      const status = typeof parsed.status === 'number' ? parsed.status : 502
      throw new ApiError(errorMsg, status)
    }
  }

  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })
    const lines = buffer.split(/\r?\n/)
    buffer = lines.pop() ?? ''

    for (const line of lines) {
      if (line === '') {
        flushEvent()
      } else if (line.startsWith('event:')) {
        currentEvent = line.slice(6).trim()
      } else if (line.startsWith('data:')) {
        currentDataLines.push(line.slice(5).trimStart())
      }
    }
  }

  if (buffer.startsWith('data:')) {
    currentDataLines.push(buffer.slice(5).trimStart())
  }
  flushEvent()

  return { text: fullText, ...(usage ? { usage } : {}) }
}
