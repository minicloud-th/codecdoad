import { useEffect, useState } from 'react'
import { motion } from 'motion/react'
import { SearchTool } from '@/components/ui/search-tool'
import { ChevronRight, MessageSquare, Plus, RefreshCw, Search, X } from './icons'
import type { ChatSummary, Workspace } from './api'
import { IOS_SNAPPY_SPRING, IOS_SOFT_SPRING } from './motion'
import { formatResetCountdown } from './server/settingsLogic'
import { useChatSearch } from './useChatSearch'

const STARTER_IDEAS: { title: string; subtitle: string; prompt: string }[] = [
  {
    title: 'สรุปไฟล์และจัดลำดับสิ่งที่ต้องแก้',
    subtitle: 'แนบไฟล์โค้ดเพื่อให้คำอธิบายอิงจากไฟล์นั้น',
    prompt: 'ช่วยสรุปหน้าที่ของไฟล์ที่แนบและจัดลำดับสิ่งที่ควรปรับปรุงจากสำคัญมากไปน้อย',
  },
  {
    title: 'รีวิวความปลอดภัยและการตรวจสอบอินพุต',
    subtitle: 'เช็กการป้องกัน XSS, Path Traversal และสิทธิ์เข้าถึง API',
    prompt: 'ช่วยตรวจสอบความเสี่ยงด้านความปลอดภัยของโค้ดชุดนี้ทีละจุด',
  },
  {
    title: 'ปรับปรุงประสิทธิภาพและโครงสร้างคอมโพเนนต์',
    subtitle: 'แนะนำวิธีลด Re-render และแยกโมดูลให้ดูแลง่าย',
    prompt: 'ช่วยแนะนำวิธี Refactor โค้ดให้กระชับและทำงานเร็วขึ้น',
  },
  {
    title: 'สร้างเคสทดสอบด้วย node:test',
    subtitle: 'เขียน Unit Test ครอบคลุม Boundary และ Error cases',
    prompt: 'ช่วยออกแบบและเขียน Unit Test สำหรับฟังก์ชันหลักในไฟล์นี้',
  },
]

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  const mb = bytes / (1024 * 1024)
  return Number.isInteger(mb) ? `${mb} MB` : `${mb.toFixed(2)} MB`
}

function formatDate(date: string, language = 'th', timeZone?: string) {
  const locale = language === 'en' ? 'en-US' : language === 'ja' ? 'ja-JP' : 'th-TH'
  try {
    return new Intl.DateTimeFormat(locale, {
      day: 'numeric',
      month: 'short',
      hour: 'numeric',
      minute: '2-digit',
      timeZone,
    }).format(new Date(date))
  } catch {
    return new Intl.DateTimeFormat(locale, {
      day: 'numeric',
      month: 'short',
      hour: 'numeric',
      minute: '2-digit',
    }).format(new Date(date))
  }
}

function planDisplayName(plan: Workspace['settings']['plan']) {
  switch (plan) {
    case 'go':
      return 'Go'
    case 'go_plus':
      return 'Go+'
    case 'lite':
      return 'Lite'
    case 'pro':
      return 'Pro'
    case 'max':
      return 'Max'
    default:
      return 'Free'
  }
}

export function RailPages({
  section,
  workspace,
  activeChatId,
  busy,
  onNewChat,
  onOpenChat,
  onStartPrompt,
  onRefresh,
  onOpenHelpModal,
}: {
  section: 'chats' | 'ideas' | 'dashboard'
  workspace: Workspace
  activeChatId: string | null
  busy: boolean
  onNewChat(): void
  onOpenChat(item: ChatSummary): void
  onStartPrompt(prompt: string): void
  onRefresh(): Promise<void>
  onOpenHelpModal(): void
}) {
  const [searchQuery, setSearchQuery] = useState('')
  const [refreshing, setRefreshing] = useState(false)
  const [now, setNow] = useState(() => new Date())

  useEffect(() => {
    if (section !== 'dashboard') return
    setNow(new Date())
    const timer = window.setInterval(() => setNow(new Date()), 60_000)
    return () => window.clearInterval(timer)
  }, [section])

  const { stats, settings, chats } = workspace

  const query = searchQuery.trim()
  const { results: filteredChats, pending, error: searchError } = useChatSearch(query, chats, section === 'chats')

  const fiveHourUsedPct = stats.fiveHourLimit > 0
    ? Math.min(100, Math.round((stats.fiveHourUsed / stats.fiveHourLimit) * 100))
    : 0
  const fiveHourRemainingPct = Math.max(0, 100 - fiveHourUsedPct)
  const weeklyUsedPct = stats.weeklyLimit > 0
    ? Math.min(100, Math.round((stats.weeklyUsed / stats.weeklyLimit) * 100))
    : 0
  const weeklyRemainingPct = Math.max(0, 100 - weeklyUsedPct)

  const chatUsagePct = Math.min(100, Math.round((stats.totalChats / stats.chatLimit) * 100))
  const storagePct = Math.min(
    100,
    Math.max(stats.storageBytes > 0 ? 1 : 0, Math.round((stats.storageBytes / stats.maxStorageBytes) * 100)),
  )

  async function handleRefresh() {
    setRefreshing(true)
    try {
      await onRefresh()
    } finally {
      setRefreshing(false)
    }
  }

  return (
    <div className="oc-page">
      <motion.div
        key={section}
        className="oc-pcol"
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={IOS_SOFT_SPRING}
      >
        {section === 'chats' && (
          <section className="chat-library" aria-labelledby="chat-library-title">
            <header className="chat-library-header">
              <div>
                <h2 id="chat-library-title">แชตทั้งหมด</h2>
                <p>{chats.length} แชตใน Workspace</p>
              </div>
              <button type="button" className="tool-action tool-action-primary"
                disabled={busy} onClick={onNewChat}><Plus size={17} /> แชตใหม่</button>
            </header>
            <div className="library-search">
              <Search size={19} />
              <input type="search" id="chat-search" placeholder="ค้นหาชื่อแชต ข้อความ หรือชื่อไฟล์"
                aria-label="ค้นหาแชต" aria-keyshortcuts="Control+K Meta+K" maxLength={160} value={searchQuery}
                onChange={event => setSearchQuery(event.target.value)} />
              {searchQuery ? <button type="button" className="tool-icon" aria-label="ล้างคำค้นหา"
                onClick={() => {
                  setSearchQuery('')
                  document.getElementById('chat-search')?.focus()
                }}><X size={16} /></button> : null}
            </div>
            <div className="library-list" aria-busy={pending}>
              {query && !searchError && (
                <SearchTool
                  className="mb-3"
                  state={pending ? 'searching' : 'done'}
                  query={query}
                  searchingLabel="กำลังค้นหาในประวัติแชต..."
                  doneLabel={filteredChats.length ? `พบ ${filteredChats.length} แชตที่ตรงกัน` : 'ไม่พบแชตที่ตรงกัน'}
                  headerLabel="ค้นหาคำว่า"
                  results={filteredChats.map(item => ({
                    title: item.title,
                    source: 'แชต',
                    date: formatDate(item.updated, settings.language, settings.timezone),
                  }))}
                />
              )}
              {searchError ? (
                <p className="library-empty" role="alert">{searchError}</p>
              ) : pending ? (
                <p className="library-empty" role="status">กำลังค้นหาแชต…</p>
              ) : filteredChats.length === 0 ? (
                <div className="library-empty" role="status">
                  <MessageSquare size={24} />
                  <b>{query ? 'ไม่พบแชตที่ตรงกับคำค้นหา' : 'ยังไม่มีแชต'}</b>
                  <span>{query ? 'ลองค้นด้วยคำอื่น' : 'กดแชตใหม่เพื่อเริ่มสนทนา'}</span>
                </div>
              ) : (
                <>
                  {!query && <h3>ล่าสุด</h3>}
                  {filteredChats.map(item => (
                    <button key={item.id} type="button" className="library-chat"
                      disabled={busy} aria-current={activeChatId === item.id ? 'page' : undefined}
                      onClick={() => onOpenChat(item)}>
                      <span className="library-chat-icon"><MessageSquare size={17} /></span>
                      <span className="library-chat-title"><b>{item.title}</b>
                        {item.snippet && <small>{item.snippet}</small>}
                      </span>
                      <time dateTime={item.updated}>{formatDate(item.updated, settings.language, settings.timezone)}</time>
                    </button>
                  ))}
                </>
              )}
            </div>
          </section>
        )}

        {section === 'ideas' && (
          <>
            <h2>เทมเพลตคำสั่ง</h2>
            <p className="oc-none" style={{ marginTop: 0, marginBottom: 14 }}>
              เลือกเทมเพลตเพื่อใส่ในช่องพิมพ์ แล้วแนบไฟล์หรือแก้ข้อความก่อนส่ง
            </p>
            {STARTER_IDEAS.map(idea => (
              <motion.button
                key={idea.title}
                type="button"
                className="oc-card oc-row"
                disabled={busy}
                whileTap={busy ? undefined : { scale: 0.985 }}
                transition={IOS_SNAPPY_SPRING}
                onClick={() => onStartPrompt(idea.prompt)}
              >
                <span>
                  <b>{idea.title}</b>
                  <small>{idea.subtitle}</small>
                </span>
                <ChevronRight size={16} className="oc-go" />
              </motion.button>
            ))}
            <motion.button
              type="button"
              className="oc-card oc-row"
              whileTap={{ scale: 0.985 }}
              transition={IOS_SNAPPY_SPRING}
              onClick={onOpenHelpModal}
            >
              <span>
                <b>ดูคำสั่ง Slash ทั้งหมด</b>
                <small>/new, /models, /undo, /redo, /share, /compact, /help</small>
              </span>
              <ChevronRight size={16} className="oc-go" />
            </motion.button>
          </>
        )}

        {section === 'dashboard' && (
          <>
            <div className="oc-ph" style={{ marginBottom: 16 }}>
              <h2>การใช้งาน</h2>
              <button
                type="button"
                className="oc-rb"
                aria-label="รีเฟรชข้อมูลสถิติ"
                disabled={busy || refreshing}
                onClick={() => void handleRefresh()}
              >
                <RefreshCw size={18} className={refreshing ? 'animate-spin' : ''} />
              </button>
            </div>

            <p className="oc-lbl" style={{ marginTop: 0 }}>การใช้งาน AI จริง</p>
            <div className="oc-card" aria-label="ขีดจำกัดการใช้งาน AI จริง">
              <div className="oc-row">
                <span>
                  <b>ขีดจำกัด 5 ชม.</b>
                  <small>แพ็กเกจ {planDisplayName(settings.plan)} · {formatResetCountdown(stats.fiveHourResetAt, now)}</small>
                </span>
                <span className="oc-sp tabular-nums">
                  {stats.fiveHourUsed.toLocaleString()} / {stats.fiveHourLimit.toLocaleString()} ครั้ง · เหลือ {fiveHourRemainingPct}%
                </span>
              </div>
              <div className={'oc-bar' + (fiveHourUsedPct >= 100 ? ' full' : fiveHourUsedPct >= 80 ? ' warn' : '')}>
                <i style={{ width: `${fiveHourUsedPct}%` }} />
              </div>
              <div className="oc-row">
                <span>
                  <b>ขีดจำกัดสัปดาห์</b>
                  <small>{formatResetCountdown(stats.weeklyResetAt, now)}</small>
                </span>
                <span className="oc-sp tabular-nums">
                  {stats.weeklyUsed.toLocaleString()} / {stats.weeklyLimit.toLocaleString()} ครั้ง · เหลือ {weeklyRemainingPct}%
                </span>
              </div>
              <div className={'oc-bar' + (weeklyUsedPct >= 100 ? ' full' : weeklyUsedPct >= 80 ? ' warn' : '')} style={{ marginBottom: 2 }}>
                <i style={{ width: `${weeklyUsedPct}%` }} />
              </div>
            </div>

            <div className="oc-stats" style={{ marginTop: 10, borderRadius: 18, border: '1px solid var(--line)', background: 'var(--card)' }}>
              <div>
                <b className="tabular-nums">{stats.todayAiCalls.toLocaleString()}</b>
                <span>เรียก AI วันนี้</span>
              </div>
              <div>
                <b className="tabular-nums">{stats.weeklyUsed.toLocaleString()}</b>
                <span>เรียก AI (7 วัน)</span>
              </div>
              <div>
                <b className="tabular-nums">{stats.aiTotalTokens.toLocaleString()}</b>
                <span>{stats.exactAiCalls > 0 ? 'โทเคน AI จริง' : 'โทเคน AI โดยประมาณ'}</span>
              </div>
            </div>

            <div className="oc-card" aria-label="การใช้งานแยกตามโมเดล AI">
              {stats.modelBreakdown.length > 0 ? (
                <div className="flex flex-col gap-3">
                  {stats.modelBreakdown.map(item => (
                    <div key={`${item.engine}:${item.modelId}:${item.modelName}`} className="oc-row">
                      <span>
                        <b>{item.modelName}</b>
                        <small>
                          {item.engine === 'local' ? 'AI บนเครื่อง' : 'Cloud AI'} ·{' '}
                          {item.exactCalls > 0 ? 'นับโทเคนจริง' : 'ประมาณการจากข้อความ'}
                        </small>
                      </span>
                      <span className="oc-sp tabular-nums">
                        {item.calls.toLocaleString()} ครั้ง · {item.totalTokens.toLocaleString()} โทเคน
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="oc-row">
                  <span>
                    <b>ยังไม่มีประวัติการเรียก AI ในรอบ 7 วัน</b>
                    <small>การวิเคราะห์ไฟล์แนบอย่างเดียวไม่ถูกนับรวมในโควตา AI</small>
                  </span>
                </div>
              )}
            </div>

            <p className="oc-lbl">การใช้งาน Workspace</p>
            <div className="oc-card" aria-label="พื้นที่และข้อมูล Workspace">
              <div className="oc-row">
                <span>
                  <b>แชตที่ใช้งานอยู่</b>
                  <small>จำกัดสูงสุด {stats.chatLimit} แชต · เก็บถาวร {stats.archivedChats.toLocaleString()} แชต</small>
                </span>
                <span className="oc-sp tabular-nums shrink-0 whitespace-nowrap">
                  {stats.totalChats} / {stats.chatLimit} ({chatUsagePct}%)
                </span>
              </div>
              <div className="oc-bar">
                <i style={{ width: `${chatUsagePct}%` }} />
              </div>
              <div className="oc-row">
                <span>
                  <b>พื้นที่จัดเก็บ JSON Workspace</b>
                  <small>ขนาดรวมแชต โปรเจกต์ อาร์ติแฟกต์ และไฟล์แนบ</small>
                </span>
                <span className="oc-sp tabular-nums shrink-0 whitespace-nowrap">
                  {formatBytes(stats.storageBytes)} / {formatBytes(stats.maxStorageBytes)} ({storagePct}%)
                </span>
              </div>
              <div className="oc-bar" style={{ marginBottom: 2 }}>
                <i style={{ width: `${storagePct}%` }} />
              </div>
            </div>

            <div className="oc-stats" style={{ marginTop: 10, borderRadius: 18, border: '1px solid var(--line)', background: 'var(--card)' }}>
              <div>
                <b className="tabular-nums">{stats.todayTurns.toLocaleString()}</b>
                <span>ข้อความวันนี้</span>
              </div>
              <div>
                <b className="tabular-nums">{stats.totalFiles.toLocaleString()}</b>
                <span>ไฟล์ที่วิเคราะห์</span>
              </div>
              <div>
                <b className="tabular-nums">{(stats.totalProjects + stats.totalArtifacts).toLocaleString()}</b>
                <span>โปรเจกต์ / ชิ้นงาน</span>
              </div>
            </div>
          </>
        )}

      </motion.div>
    </div>
  )
}
