import { useEffect, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { AnimatePresence, MotionConfig, motion } from 'motion/react'
import { ReplyContent } from './ReplyContent'
import { trapTab } from './focusTrap'
import { AttachmentCard } from './AttachmentCard'
import { onAuthStateChanged, signOut } from 'firebase/auth'
import {
  Download,
  Icon,
  Menu,
  X,
} from './icons'
import { ApiError, api, byteLength, errorMessage, setWorkspaceAccount, setWorkspaceAuthTokenProvider } from './api'
import type {
  AccentColor,
  Attachment,
  AuthUser,
  Chat,
  ChatChange,
  ChatSummary,
  ChatsActionResult,
  ContentChange,
  SettingsSaveResult,
  SettingsSnapshot,
  SettingsTab,
  Workspace,
  WorkspaceSettings,
} from './api'
import { AccountMenu } from './AccountMenu'
import { Composer, commands } from './Composer'
import type { Command } from './Composer'
import {
  APINEX_MODEL_NAME,
  GEMINI_FLASH_LITE_MODEL_NAME,
  GEMINI_HYDROGEN_MODEL_ID,
  GEMINI_HYDROGEN_MODEL_NAME,
  LOCAL_PLAN_MODEL_NAME,
  NUMES_MODEL_NAME,
  activeModelDisplayLabel,
  buildPromptWithSkills,
  isCloudModelId,
  modelForEffort,
} from './composerLogic'
import type { EffortLevel, SkillItem } from './composerLogic'
import { accountFromFirebase, firebaseAuth } from './firebase'
import { LoginScreen } from './LoginScreen'
import {
  IOS_EASE,
  IOS_LIQUID_SPRING,
  IOS_SHEET_SPRING,
  IOS_SNAPPY_SPRING,
  IOS_SOFT_SPRING,
  IOS_SPRING,
} from './motion'
import { Rail } from './Rail'
import { routeFromHash, routeHash } from './navigation'
import type { Navigate } from './navigation'
import { WorkspacePages } from './WorkspacePages'
import type { ContentAction } from './workspaceContent'
import { RailPages } from './RailPages'
import { SETTINGS_TABS, SettingsModal } from './SettingsModal'
import { formatActivePlanLabel } from './subscriptionLogic'

type Panel = 'cloud' | 'help' | 'summary' | 'delete' | 'shortcuts'

const SETTINGS_TAB_SET = new Set<string>(SETTINGS_TABS.map(item => item.id))

function tabFromHash(hash: string): SettingsTab | null {
  if (!hash.startsWith('#set:')) return null
  const candidate = hash.slice(5)
  return SETTINGS_TAB_SET.has(candidate) ? (candidate as SettingsTab) : 'general'
}

function contrastOnAccent(color: AccentColor): string {
  if (color === '#2f6df0' || color === '#a855f7' || color === '#ec4899') {
    return '#ffffff'
  }
  return '#0b1b3b'
}

function Logo() {
  return (
    <h1 className="wordmark">
      <picture>
        <source media="(prefers-reduced-motion: reduce)" srcSet="/openspec-wordmark.png" />
        <img src="/openspec-wordmark.webp" alt="OPENSPEC" width={690} height={180} />
      </picture>
    </h1>
  )
}

function Modal({ title, busy, onClose, children }: {
  title: string; busy: boolean; onClose(): void; children: ReactNode
}) {
  const dialog = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const previous = document.activeElement
    dialog.current?.focus({ preventScroll: true })
    return () => {
      if (previous instanceof HTMLElement && previous.isConnected) previous.focus({ preventScroll: true })
    }
  }, [])

  useEffect(() => {
    function handleKey(event: KeyboardEvent) {
      if (event.key === 'Escape' && !busy) {
        event.preventDefault()
        onClose()
      }
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [busy, onClose])

  return <motion.div
    className="oc-overlay"
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    transition={{ duration: 0.18, ease: IOS_EASE }}
    onMouseDown={event => {
      if (event.target === event.currentTarget && !busy) onClose()
    }}
  >
    <motion.div
      ref={dialog}
      tabIndex={-1}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
      className="oc-modal oc-small oc-sheet"
      onKeyDown={event => trapTab(event, dialog.current)}
      initial={{ opacity: 0, scale: 0.94, y: 14, filter: 'blur(6px)' }}
      animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
      exit={{ opacity: 0, scale: 0.96, y: 10, filter: 'blur(4px)' }}
      transition={IOS_SHEET_SPRING}
    >
      <header className="oc-sheet-head">
        <h3 id="modal-title">{title}</h3>
        <motion.button
          type="button"
          className="oc-x"
          aria-label="ปิด"
          disabled={busy}
          whileTap={busy ? undefined : { scale: 0.88 }}
          transition={IOS_SNAPPY_SPRING}
          onClick={onClose}
        >
          <X size={16} />
        </motion.button>
      </header>
      <div className="oc-sheet-body">
        {children}
      </div>
    </motion.div>
  </motion.div>
}

function exportChat(chat: Chat) {
  const text = '# ' + chat.title + '\n\n' + chat.turns.map(turn => {
    const files = turn.files.length ? '\n\nไฟล์แนบ ' + turn.files.map(file => file.name).join(', ') : ''
    return '## คุณ\n\n' + turn.prompt + files + '\n\n## ' + turn.model + '\n\n' + turn.reply
  }).join('\n\n---\n\n')
  const link = document.createElement('a')
  const objectURL = URL.createObjectURL(new Blob([text], { type: 'text/markdown;charset=utf-8' }))
  link.href = objectURL
  link.download = 'openspec-' + chat.id.slice(0, 8) + '.md'
  document.body.appendChild(link)
  link.click()
  link.remove()
  setTimeout(() => URL.revokeObjectURL(objectURL), 1000)
}

export function App() {
  const [authChecking, setAuthChecking] = useState(true)
  const [authUser, setAuthUser] = useState<AuthUser | null>(null)
  const [workspace, setWorkspace] = useState<Workspace | null>(null)
  const [chat, setChat] = useState<Chat | null>(null)
  const [route, setRoute] = useState(() => routeFromHash(window.location.hash))
  const { section } = route
  const [draft, setDraft] = useState('')
  const [files, setFiles] = useState<Attachment[]>([])
  const [model, setModel] = useState(GEMINI_HYDROGEN_MODEL_ID)
  const [effort, setEffort] = useState<EffortLevel>('Low')
  const [skills, setSkills] = useState<SkillItem[]>([])
  const [modelProgress, setModelProgress] = useState('')
  const [pendingTurn, setPendingTurn] = useState<{
    prompt: string
    files: Pick<Attachment, 'name' | 'preview'>[]
    model: string
    reply: string
  } | null>(null)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [busy, setBusy] = useState(false)
  const [initializing, setInitializing] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [panel, setPanel] = useState<Panel | null>(null)
  const [settingsTab, setSettingsTab] = useState<SettingsTab | null>(() =>
    typeof window !== 'undefined' ? tabFromHash(window.location.hash) : null,
  )
  const [summary, setSummary] = useState('')
  const [showAppearance, setShowAppearance] = useState(false)
  const log = useRef<HTMLElement>(null)
  const focusChatSearch = useRef(false)
  const busyRef = useRef(false)
  const activeAccount = useRef<AuthUser | null>(null)
  const discordTokenRef = useRef<string | null>(null)
  const prevChatIdRef = useRef<string | null>(null)

  const navigate: Navigate = (section, item) => {
    const next = { section, item }
    const hash = routeHash(next)
    setRoute(next)
    if (window.location.hash !== hash) window.location.hash = hash
  }

  function openSettings(tab: SettingsTab, appearance = false) {
    setMenuOpen(false)
    setPanel(null)
    setError('')
    setNotice('')
    setSettingsTab(tab)
    setShowAppearance(appearance)
    if (typeof window !== 'undefined') {
      window.location.hash = `set:${tab}`
    }
  }

  function closeSettings() {
    setError('')
    setSettingsTab(null)
    setShowAppearance(false)
    if (typeof window !== 'undefined' && window.location.hash.startsWith('#set:')) {
      window.history.replaceState(null, '', routeHash(route))
    }
  }

  function clearSessionState() {
    activeAccount.current = null
    discordTokenRef.current = null
    setWorkspaceAuthTokenProvider(null)
    setWorkspaceAccount(null)
    setAuthUser(null)
    setWorkspace(null)
    setInitializing(false)
    setChat(null)
    setDraft('')
    setFiles([])
    navigate('home')
    setMenuOpen(false)
    setPanel(null)
    closeSettings()
    setError('')
    setNotice('')
  }

  async function loadWorkspaceData(account: AuthUser) {
    setInitializing(true)
    setError('')
    try {
      const ws = await api<Workspace>('/workspace')
      if (activeAccount.current === account) setWorkspace(ws)
    } catch (failure) {
      if (activeAccount.current !== account) return
      if (failure instanceof ApiError && failure.status === 401) {
        clearSessionState()
      } else {
        setError(errorMessage(failure))
      }
    } finally {
      if (activeAccount.current === account) setInitializing(false)
    }
  }

  async function boot() {
    setAuthChecking(true)
    try {
      await firebaseAuth?.authStateReady()
      const user = firebaseAuth?.currentUser
      if (user) {
        await handleAuthenticated(accountFromFirebase(user))
      } else {
        const headers: HeadersInit = discordTokenRef.current
          ? { Authorization: `Bearer ${discordTokenRef.current}` }
          : {}
        const discordRes = await fetch('/api/auth/discord/me', {
          credentials: 'include',
          headers,
        })
        if (discordRes.ok) {
          const data = (await discordRes.json()) as { authenticated?: boolean; user?: AuthUser | null }
          if (data.authenticated && data.user && data.user.provider === 'discord') {
            await handleAuthenticated(data.user)
            return
          }
        }
        clearSessionState()
      }
    } catch {
      clearSessionState()
    } finally {
      setAuthChecking(false)
    }
  }

  async function handleAuthenticated(account: AuthUser, token?: string) {
    if (account.provider === 'discord') {
      if (!account.id.startsWith('discord:')) return
      if (token) discordTokenRef.current = token
    } else if (!firebaseAuth || firebaseAuth.currentUser?.uid !== account.id) {
      return
    }
    if (activeAccount.current && activeAccount.current.id !== account.id) clearSessionState()
    activeAccount.current = account
    setWorkspaceAccount(account)
    setWorkspaceAuthTokenProvider(async () => {
      if (account.provider === 'discord') {
        return discordTokenRef.current
      }
      return (await firebaseAuth?.currentUser?.getIdToken()) ?? null
    })
    setAuthUser(account)
    await loadWorkspaceData(account)
  }

  async function signOutAccount() {
    if (busyRef.current) return
    busyRef.current = true
    setBusy(true)
    try {
      if (activeAccount.current?.provider === 'discord') {
        await fetch('/api/auth/discord/logout', {
          method: 'POST',
          credentials: 'include',
          headers: { 'X-Requested-With': 'OPENSPEC' },
        })
        discordTokenRef.current = null
      } else if (firebaseAuth) {
        await signOut(firebaseAuth)
      }
      clearSessionState()
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      busyRef.current = false
      setBusy(false)
    }
  }

  useEffect(() => {
    void boot()
    if (!firebaseAuth) return
    return onAuthStateChanged(firebaseAuth, user => {
      const current = activeAccount.current
      if (current && current.provider !== 'discord' && user?.uid !== current.id) {
        if (user) void handleAuthenticated(accountFromFirebase(user))
        else clearSessionState()
      }
    })
  }, [])

  useEffect(() => {
    function handleHash() {
      const hash = window.location.hash
      const tab = tabFromHash(hash)
      setSettingsTab(tab)
      if (!tab) setRoute(routeFromHash(hash))
    }
    window.addEventListener('hashchange', handleHash)
    return () => window.removeEventListener('hashchange', handleHash)
  }, [])

  useEffect(() => {
    const mode = workspace?.settings?.theme ?? 'dark'
    const accent = workspace?.settings?.accentColor ?? '#4a8dff'
    const media = typeof window !== 'undefined' ? window.matchMedia('(prefers-color-scheme: light)') : null

    const applyTheme = () => {
      const effectiveDark = mode === 'dark' || (mode === 'system' && !(media?.matches ?? false))
      const root = document.documentElement
      root.classList.toggle('dark', effectiveDark)
      root.dataset.theme = effectiveDark ? 'dark' : 'light'
      root.style.setProperty('--accent', accent)
      root.style.setProperty('--on', contrastOnAccent(accent))
      const metaTheme = document.querySelector('meta[name="theme-color"]')
      if (metaTheme) {
        metaTheme.setAttribute('content', effectiveDark ? '#131314' : '#ffffff')
      }
    }

    applyTheme()
    if (mode === 'system' && media) {
      media.addEventListener('change', applyTheme)
      return () => media.removeEventListener('change', applyTheme)
    }
  }, [workspace?.settings?.theme, workspace?.settings?.accentColor])

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k' && activeAccount.current && !busyRef.current) {
        event.preventDefault()
        setMenuOpen(false)
        closeSettings()
        setPanel(null)
        const search = document.getElementById('chat-search')
        focusChatSearch.current = !search
        navigate('chats')
        search?.focus()
        return
      }
      if ((event.ctrlKey || event.metaKey) && event.key === '/' && activeAccount.current) {
        event.preventDefault()
        setMenuOpen(false)
        setSettingsTab(null)
        setPanel('shortcuts')
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  useEffect(() => {
    if (!focusChatSearch.current || section !== 'chats' || !workspace) return
    focusChatSearch.current = false
    document.getElementById('chat-search')?.focus()
  }, [section, workspace])

  useEffect(() => {
    const id = chat?.id ?? null
    const isNewChatSwitch = id !== prevChatIdRef.current
    prevChatIdRef.current = id

    if (log.current && id) {
      requestAnimationFrame(() => {
        if (!log.current) return
        log.current.scrollTo({
          top: log.current.scrollHeight,
          behavior: isNewChatSwitch ? 'auto' : 'smooth',
        })
      })
    }
  }, [chat?.id, chat?.turns.length, busy, chat?.canRedo, pendingTurn?.reply])

  async function run(task: () => Promise<void>, restoreFocus = false) {
    if (busyRef.current || !workspace) return false
    busyRef.current = true
    setBusy(true)
    setError('')
    setNotice('')
    try {
      await task()
      return true
    } catch (failure) {
      if (failure instanceof ApiError && failure.status === 401) {
        clearSessionState()
      } else {
        setError(errorMessage(failure))
      }
      return false
    } finally {
      busyRef.current = false
      setBusy(false)
      if (restoreFocus) requestAnimationFrame(() => document.getElementById('prompt')?.focus())
    }
  }

  function change({ chat: nextChat, chats, stats, content }: ChatChange) {
    setWorkspace(current => current && { ...current, chats, ...(stats ? { stats } : {}), ...(content ? { content } : {}) })
    setChat(nextChat)
  }

  async function saveSettingsPatch(
    patch: Partial<WorkspaceSettings> & { name?: string },
  ): Promise<boolean> {
    if (busyRef.current || !workspace || !authUser || activeAccount.current !== authUser) return false
    busyRef.current = true
    setBusy(true)
    setError('')
    try {
      const result = await api<SettingsSaveResult>('/settings', patch)
      if (activeAccount.current !== authUser) return false
      setWorkspace(current =>
        current && {
          ...current,
          name: result.name,
          settings: result.settings,
          stats: result.stats,
        },
      )
      return true
    } catch (failure) {
      if (activeAccount.current !== authUser) return false
      if (failure instanceof ApiError && failure.status === 401) {
        clearSessionState()
      } else {
        setError(errorMessage(failure))
      }
      return false
    } finally {
      busyRef.current = false
      setBusy(false)
    }
  }

  async function refreshSettingsState(): Promise<void> {
    if (busyRef.current || !workspace) return
    busyRef.current = true
    setBusy(true)
    setError('')
    try {
      const snapshot = await api<SettingsSnapshot>('/settings')
      setWorkspace(current =>
        current && {
          ...current,
          publicId: snapshot.publicId,
          name: snapshot.name,
          archivedChats: snapshot.archivedChats,
          settings: snapshot.settings,
          stats: snapshot.stats,
        },
      )
    } catch (failure) {
      if (failure instanceof ApiError && failure.status === 401) {
        clearSessionState()
      } else {
        setError(errorMessage(failure))
      }
    } finally {
      busyRef.current = false
      setBusy(false)
    }
  }

  async function runChatsBulkAction(
    bulkAction: 'archive-all' | 'restore-archived' | 'delete-all' | 'reset-account',
  ): Promise<boolean> {
    if (busyRef.current || !workspace) return false
    busyRef.current = true
    setBusy(true)
    setError('')
    try {
      const result = await api<ChatsActionResult>('/workspace/chats-action', { action: bulkAction })
      setWorkspace(current =>
        current && {
          ...current,
          name: result.name,
          chats: result.chats,
          content: result.content,
          archivedChats: result.archivedChats,
          settings: result.settings,
          stats: result.stats,
        },
      )
      if (bulkAction === 'archive-all' || bulkAction === 'delete-all' || bulkAction === 'reset-account') {
        setChat(null)
      }
      return true
    } catch (failure) {
      if (failure instanceof ApiError && failure.status === 401) {
        clearSessionState()
      } else {
        setError(errorMessage(failure))
      }
      return false
    } finally {
      busyRef.current = false
      setBusy(false)
    }
  }

  function exportAllWorkspaceChats() {
    if (busyRef.current) return
    void run(async () => {
      const payload = await api<unknown>('/workspace/export')
      const link = document.createElement('a')
      const objectURL = URL.createObjectURL(
        new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' }),
      )
      link.href = objectURL
      link.download = 'openspec-workspace-export.json'
      document.body.appendChild(link)
      link.click()
      link.remove()
      setTimeout(() => URL.revokeObjectURL(objectURL), 1000)
      setNotice('ดาวน์โหลดไฟล์สำรอง Workspace แล้ว')
    })
  }

  function newChat() {
    if (busyRef.current) return
    setModel(current => current || GEMINI_HYDROGEN_MODEL_ID)
    setMenuOpen(false)
    setPanel(null)
    closeSettings()
    navigate('home')
    setChat(null)
    setDraft('')
    setFiles([])
    setError('')
    setNotice('')
    requestAnimationFrame(() => document.getElementById('prompt')?.focus())
  }

  async function updateContent(action: ContentAction) {
    const account = activeAccount.current
    let change: ContentChange | undefined
    await run(async () => {
      const result = await api<ContentChange>('/workspace/content', action)
      if (activeAccount.current !== account) return
      const { content, stats } = result
      setWorkspace(current => current && { ...current, content, stats })
      change = result
    })
    return change
  }

  function openChat(item: ChatSummary) {
    void run(async () => {
      setChat(await api<Chat>('/chats/' + item.id))
      navigate('home')
      setPanel(null)
      setMenuOpen(false)
    })
  }

  function send(retryPrompt?: string) {
    const isRetry = typeof retryPrompt === 'string'
    const promptText = isRetry ? retryPrompt.trim() : buildPromptWithSkills(draft, skills)
    const sendFiles = isRetry ? [] : files
    if (byteLength(promptText.trim()) > 12000) {
      setError('ข้อความยาวเกิน 12 KB ลองย่อให้สั้นลง')
      return
    }
    void run(async () => {
      const targetChatId = chat?.id ?? ''
      setPendingTurn({
        prompt: promptText,
        files: sendFiles.map(({ name, preview }) => ({ name, preview })),
        model: activeModelDisplayLabel(model, effort),
        reply: '',
      })
      try {
        change(await api<ChatChange>('/turns', {
          chatId: targetChatId,
          prompt: promptText,
          model,
          effort,
          files: sendFiles,
        }, {
          onProgress: setModelProgress,
          onStream: partial => {
            setPendingTurn(current => (current ? { ...current, reply: partial } : current))
          },
        }))
        if (!isRetry) {
          setDraft('')
          setFiles([])
        }
      } finally {
        setModelProgress('')
        setPendingTurn(null)
      }
      navigate('home')
    }, true)
  }

  function action(name: 'undo' | 'redo' | 'delete') {
    if (!chat) return
    void run(async () => {
      change(await api<ChatChange>('/chats/' + chat.id + '/' + name, {}))
      if (name === 'delete') {
        setPanel(null)
        setNotice('ลบแชตแล้ว')
      }
    })
  }

  function command(name: Command) {
    setDraft('')
    setError('')
    setNotice('')
    if (name === '/new') {
      newChat()
      return
    }
    if (name === '/help') {
      setMenuOpen(false)
      setPanel('help')
      return
    }
    if (!chat) {
      setNotice('ส่งข้อความเพื่อเริ่มแชตก่อน')
      return
    }
    switch (name) {
      case '/undo':
        if (chat.turns.length) action('undo')
        else setNotice('ไม่มีข้อความให้ย้อน')
        break
      case '/redo':
        if (chat.canRedo) action('redo')
        else setNotice('ไม่มีข้อความให้คืน')
        break
      case '/share':
        if (chat.turns.length) {
          exportChat(chat)
          setNotice('ดาวน์โหลดไฟล์แชตแล้ว')
        } else setNotice('ไม่มีข้อความให้ดาวน์โหลด')
        break
      case '/compact':
        void run(async () => {
          const result = await api<{ summary: string }>('/chats/' + chat.id + '/summary', {})
          setSummary(result.summary)
          setMenuOpen(false)
          setPanel('summary')
        })
        break
    }
  }

  const titles: Record<Panel, string> = {
    cloud: 'การเชื่อมต่อ',
    help: 'คำสั่ง',
    summary: 'สรุปแชต',
    delete: 'ลบแชตนี้?',
    shortcuts: 'คีย์ลัดแป้นพิมพ์',
  }
  const aiModelName = workspace?.models.find(item => item.id === 'ai')?.name ?? LOCAL_PLAN_MODEL_NAME
  const contextModelLabel = isCloudModelId(model)
    ? `${activeModelDisplayLabel(model, effort)} (${effort})`
    : `${activeModelDisplayLabel(model, effort)} (${effort} · ${modelForEffort(effort).approxDownload})`

  return (
    <MotionConfig reducedMotion="user">
      <AnimatePresence mode="wait" initial={false}>
        {authChecking ? (
          <motion.div
            key="auth-checking"
            className="oc-login-shell"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.16, ease: IOS_EASE }}
          >
            <div className="oc-login-center">
              <div className="flex flex-col items-center gap-3 text-sm text-[var(--muted)]" role="status">
                <span>กำลังเปิด OPENSPEC...</span>
              </div>
            </div>
          </motion.div>
        ) : !authUser ? (
          <LoginScreen
            key="login-screen"
            onAuthenticated={(result, token) => void handleAuthenticated(result, token)}
          />
        ) : (
      <motion.div
        key="workspace-shell"
        className="app-shell"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2, ease: IOS_EASE }}
      >
        <Rail
          section={section}
          chatCount={workspace?.chats.length ?? 0}
          stats={workspace?.stats}
          busy={busy}
          onSelectSection={next => {
            setMenuOpen(false)
            setError('')
            navigate(next)
          }}
          accountMenu={
            <AccountMenu
              name={workspace?.name || authUser.name}
              photoURL={workspace?.settings.avatar || authUser.photoURL}
              disabled={!workspace || busy}
              open={menuOpen}
              section={section}
              stats={workspace?.stats}
              onOpenChange={setMenuOpen}
              onSelectSection={next => {
                setMenuOpen(false)
                setError('')
                navigate(next)
              }}
              onSettings={openSettings}
              onHelp={() => setPanel('help')}
              onShortcuts={() => setPanel('shortcuts')}
              onStatus={() => setPanel('cloud')}
              onExport={exportAllWorkspaceChats}
              onAccount={() => void signOutAccount()}
            />
          }
        />

        <main className={'stage' + (section === 'home' && (chat || pendingTurn) ? ' conversation' : '')}>
          <AnimatePresence mode="wait" initial={false}>
          {section !== 'home' ? (
            <motion.div
              key={'section-' + section}
              className="contents"
              initial={{ opacity: 0, y: 8, scale: 0.99 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -6, scale: 0.99 }}
              transition={IOS_LIQUID_SPRING}
            >
              {workspace ? (
                section === 'chats' || section === 'ideas' || section === 'dashboard' ? (
                  <RailPages
                    section={section}
                    workspace={workspace}
                    activeChatId={chat?.id ?? null}
                    busy={busy}
                    onNewChat={newChat}
                    onOpenChat={openChat}
                    onStartPrompt={promptText => {
                      setDraft(current => current.trim() ? current + '\n\n' + promptText : promptText)
                      navigate('home')
                      requestAnimationFrame(() => document.getElementById('prompt')?.focus())
                    }}
                    onRefresh={refreshSettingsState}
                    onOpenHelpModal={() => setPanel('help')}
                  />
                ) : (
                  <WorkspacePages key={section} route={route} workspace={workspace} busy={busy} error={error}
                    navigate={navigate} onOpenChat={openChat} onNewChat={newChat} onUpdate={updateContent}
                    onSelectPlan={(plan, billingCycle) => saveSettingsPatch({ plan, billingCycle })} />
                )
              ) : (
                <div className="grid h-full w-full place-items-center text-sm text-[var(--muted)]"
                  role={error ? 'alert' : 'status'}>
                  <div className="flex flex-col items-center gap-3 px-6 text-center">
                    <span>{error || 'กำลังโหลดข้อมูล OPENSPEC...'}</span>
                    {error && !initializing && (
                      <button type="button" className="text-button" onClick={() => void boot()}>ลองเชื่อมต่อใหม่</button>
                    )}
                  </div>
                </div>
              )}
            </motion.div>
          ) : !chat && !pendingTurn ? (
            <motion.div
              key="home-empty"
              className="contents"
              initial={{ opacity: 0, y: 10, scale: 0.985 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.985 }}
              transition={IOS_LIQUID_SPRING}
            >
              <div className="home-canvas">
                <motion.div
                  key="welcome"
                  className="welcome"
                  initial={{ opacity: 0, y: 12, scale: 0.96, filter: 'blur(4px)' }}
                  animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
                  transition={IOS_SOFT_SPRING}
                >
                  <Logo />
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.98 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  transition={IOS_LIQUID_SPRING}
                  className="compose-area"
                >
                  <Composer busy={busy} ready={workspace !== null} draft={draft} files={files} model={model}
                    effort={effort} skills={skills}
                    models={workspace?.models ?? []} onDraft={setDraft} onFiles={setFiles} onModel={setModel}
                    onEffort={setEffort} onSkills={setSkills}
                    onSend={() => send()} onCommand={command} onError={setError} />
                  <div className="context">
                    <span className="context-brand">OPENSPEC</span>
                    <span aria-hidden="true">/</span>
                    <span><Icon name="monitor" size={15} />{formatActivePlanLabel(workspace?.settings.plan ?? 'free', workspace?.settings.billingCycle)} · {contextModelLabel}</span>
                    <AnimatePresence initial={false}>
                      {(initializing || busy || notice) && <motion.span
                        key={initializing ? 'init' : busy ? 'busy' : notice}
                        className="operation-status"
                        role="status"
                        initial={{ opacity: 0, y: 3 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -3 }}
                        transition={{ duration: 0.14, ease: IOS_EASE }}
                      >
                        {initializing ? 'กำลังเปิด Workspace' : busy ? modelProgress || 'กำลังดำเนินการ' : notice}
                      </motion.span>}
                    </AnimatePresence>
                  </div>
                  <AnimatePresence>
                    {error && !panel && !settingsTab && <motion.div
                      className="error"
                      role="alert"
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -4 }}
                      transition={IOS_SNAPPY_SPRING}
                    >
                      {error}
                      {!workspace && <button className="text-button" onClick={() => void boot()}>ลองเชื่อมต่อใหม่</button>}
                    </motion.div>}
                  </AnimatePresence>
                </motion.div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key={'chat-' + (chat?.id ?? 'pending')}
              className="contents"
              initial={{ opacity: 0, y: 10, scale: 0.988 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -6, scale: 0.99 }}
              transition={IOS_LIQUID_SPRING}
            >
              <motion.header
                key={'header-' + (chat?.id ?? 'pending')}
                className="chat-header"
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={IOS_SPRING}
              >
                <div className="flex min-w-0 items-center gap-3">
                  <motion.button
                    type="button"
                    className="oc-pill shrink-0"
                    whileTap={{ scale: 0.95 }}
                    transition={IOS_SNAPPY_SPRING}
                    onClick={() => navigate('chats')}
                  >
                    <Menu size={16} />
                    <span>แชต</span>
                  </motion.button>
                  <div className="min-w-0">
                    <span>OPENSPEC</span>
                    <h1 title={chat?.title ?? (pendingTurn?.prompt || 'กำลังสร้างแชตใหม่')}>
                      {chat?.title ?? (pendingTurn?.prompt || 'กำลังสร้างแชตใหม่')}
                    </h1>
                  </div>
                </div>
                <div className="chat-header-actions">
                  <button type="button" className="icon-button" title="ดาวน์โหลดแชตเป็น Markdown"
                    aria-label="ดาวน์โหลดแชตเป็น Markdown"
                    disabled={!chat?.turns.length}
                    onClick={() => chat && exportChat(chat)}>
                    <Download size={17} />
                  </button>
                  <motion.button
                    type="button"
                    className="icon-button"
                    aria-label="ลบแชต"
                    title="ลบแชต"
                    disabled={busy || !chat}
                    whileTap={busy || !chat ? undefined : { scale: 0.88 }}
                    transition={IOS_SNAPPY_SPRING}
                    onClick={() => { setError(''); setPanel('delete') }}
                  >
                    <Icon name="trash" />
                  </motion.button>
                </div>
              </motion.header>
              <section className="chat-scroll" aria-label="บทสนทนา" ref={log}>
                <div className="chat-log" role="log">
                  <AnimatePresence key={'log-' + (chat?.id ?? 'pending')} initial={false}>
                    {(chat?.turns ?? []).map((turn, index) => <motion.article
                      className="turn"
                      key={(chat?.id ?? 'pending') + '-' + index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={IOS_SOFT_SPRING}
                    >
                      <motion.div
                        className="message-user"
                        initial={{ opacity: 0, scale: 0.96, y: 6 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        transition={IOS_SNAPPY_SPRING}
                        style={{ transformOrigin: 'bottom right' }}
                      >
                        {turn.prompt && <div>{turn.prompt}</div>}
                        {turn.files.length > 0 && <ul className="message-files">
                          {turn.files.map((file, number) => <li key={number}><AttachmentCard name={file.name} preview={file.preview} /></li>)}
                        </ul>}
                      </motion.div>
                      <motion.div
                        className="message-assistant"
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ ...IOS_SOFT_SPRING, delay: 0.03 }}
                      >
                        <ReplyContent
                          turn={turn}
                          status="complete"
                          onRetry={turn.prompt.trim() && !busy ? () => send(turn.prompt) : undefined}
                        />
                      </motion.div>
                    </motion.article>)}
                    {pendingTurn && <motion.article
                      className="turn"
                      key="pending-turn"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={IOS_SOFT_SPRING}
                    >
                      <motion.div
                        className="message-user"
                        initial={{ opacity: 0, scale: 0.96, y: 6 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        transition={IOS_SNAPPY_SPRING}
                        style={{ transformOrigin: 'bottom right' }}
                      >
                        {pendingTurn.prompt && <div>{pendingTurn.prompt}</div>}
                        {pendingTurn.files.length > 0 && <ul className="message-files">
                          {pendingTurn.files.map((file, number) => <li key={number}><AttachmentCard name={file.name} preview={file.preview} /></li>)}
                        </ul>}
                      </motion.div>
                      <motion.div
                        className="message-assistant"
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ ...IOS_SOFT_SPRING, delay: 0.03 }}
                      >
                        <ReplyContent
                          turn={pendingTurn}
                          status="streaming"
                          progressText={modelProgress}
                        />
                      </motion.div>
                    </motion.article>}
                  </AnimatePresence>
                  {!chat?.turns.length && !pendingTurn && <p className="empty-chat">ใช้ /redo เพื่อคืนข้อความ หรือส่งข้อความใหม่เพื่อคุยต่อ</p>}
                </div>
              </section>

              <div className="compose-area">
                <Composer key={chat?.id ?? 'pending'} busy={busy} ready={workspace !== null} draft={draft} files={files} model={model}
                  effort={effort} skills={skills}
                  models={workspace?.models ?? []} onDraft={setDraft} onFiles={setFiles} onModel={setModel}
                  onEffort={setEffort} onSkills={setSkills}
                  onSend={() => send()} onCommand={command} onError={setError} />
                <div className="context">
                  <span className="context-brand">OPENSPEC</span>
                  <span aria-hidden="true">/</span>
                  <span><Icon name="monitor" size={15} />{formatActivePlanLabel(workspace?.settings.plan ?? 'free', workspace?.settings.billingCycle)} · {contextModelLabel}</span>
                  <AnimatePresence initial={false}>
                    {(initializing || busy || notice) && <motion.span
                      key={initializing ? 'init' : busy ? 'busy' : notice}
                      className="operation-status"
                      role="status"
                      initial={{ opacity: 0, y: 3 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -3 }}
                      transition={{ duration: 0.14, ease: IOS_EASE }}
                    >
                      {initializing ? 'กำลังเปิด Workspace' : busy ? modelProgress || 'กำลังดำเนินการ' : notice}
                    </motion.span>}
                  </AnimatePresence>
                </div>
                <AnimatePresence>
                  {error && !panel && !settingsTab && <motion.div
                    className="error"
                    role="alert"
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={IOS_SNAPPY_SPRING}
                  >
                    {error}
                    {!workspace && <button className="text-button" onClick={() => void boot()}>ลองเชื่อมต่อใหม่</button>}
                  </motion.div>}
                </AnimatePresence>
              </div>
            </motion.div>
          )}
          </AnimatePresence>
        </main>

        <AnimatePresence>
          {settingsTab && workspace && (
            <SettingsModal
              tab={settingsTab}
              showAppearance={showAppearance}
              workspace={workspace}
              authUser={authUser}
              busy={busy}
              error={error}
              onSelectTab={openSettings}
              onSaveSettings={saveSettingsPatch}
              onBulkAction={runChatsBulkAction}
              onExportAll={exportAllWorkspaceChats}
              onOpenShortcuts={() => {
                closeSettings()
                setPanel('shortcuts')
              }}
              onLogout={() => void signOutAccount()}
              onClose={closeSettings}
            />
          )}
        </AnimatePresence>

        <AnimatePresence>
          {panel && (
            <Modal key={panel} title={titles[panel]} busy={busy} onClose={() => { setError(''); setPanel(null) }}>
              {panel === 'shortcuts' && (
                <div>
                  <div className="oc-card oc-row"><b>เปิดหน้าต่างคีย์ลัด</b><span className="oc-sp">Ctrl+/</span></div>
                  <div className="oc-card oc-row"><b>ค้นหาแชต</b><span className="oc-sp">Ctrl / ⌘ + K</span></div>
                  <div className="oc-card oc-row"><b>ส่งข้อความในแชต</b><span className="oc-sp">Enter</span></div>
                  <div className="oc-card oc-row"><b>ขึ้นบรรทัดใหม่</b><span className="oc-sp">Shift+Enter</span></div>
                  <div className="oc-card oc-row"><b>ปิดหน้าต่างที่เปิดอยู่</b><span className="oc-sp">Esc</span></div>
                </div>
              )}

              {panel === 'cloud' && (
                <div>
                  <div className="oc-card oc-row"><b>พื้นที่จัดเก็บในเบราว์เซอร์</b><span className="oc-sp">{workspace ? 'พร้อมใช้งาน' : 'ยังไม่พร้อม'}</span></div>
                  <div className="oc-card oc-row"><b>เอนจิน Local UTF-8</b><span className="oc-sp">{workspace?.engineAvailable ? 'พร้อมวิเคราะห์ไฟล์' : 'ยังไม่พร้อม'}</span></div>
                  <div className="oc-card oc-row"><b>Gemini ฟรี (Cloud)</b><span className="oc-sp">{GEMINI_HYDROGEN_MODEL_NAME} · {GEMINI_FLASH_LITE_MODEL_NAME}</span></div>
                  <div className="oc-card oc-row"><b>DeepSeek ฟรี (Numes)</b><span className="oc-sp">{NUMES_MODEL_NAME}</span></div>
                  <div className="oc-card oc-row"><b>โมเดล Plan Free (APINEX)</b><span className="oc-sp">{APINEX_MODEL_NAME}</span></div>
                  <div className="oc-card oc-row"><b>โมเดลบนเครื่อง</b><span className="oc-sp">{aiModelName ?? 'Local Workspace'}</span></div>
                </div>
              )}

              {panel === 'help' && (
                <div>
                  {commands.map(item => (
                    <div key={item.name} className="oc-card oc-row">
                      <span>
                        <b style={{ fontFamily: 'ui-monospace, monospace', color: 'var(--accent)' }}>{item.name}</b>
                        <small>{item.description}</small>
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {panel === 'summary' && <p className="plain-reply">{summary}</p>}

              {panel === 'delete' && (
                <div className="delete-form">
                  <p>ข้อความและไฟล์ของแชตนี้จะถูกลบจากประวัติ</p>
                  <button className="oc-primary" style={{ background: '#dc2626', color: '#fff' }} onClick={() => action('delete')} disabled={busy}>
                    ลบแชต
                  </button>
                </div>
              )}

              {error && <p role="alert" className="error">{error}</p>}
            </Modal>
          )}
        </AnimatePresence>
      </motion.div>
        )}
      </AnimatePresence>
    </MotionConfig>
  )
}
