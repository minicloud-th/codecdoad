import assert from 'node:assert/strict'
import test from 'node:test'
import { applyContentAction, PROJECT_DESCRIPTION_LIMIT } from '../workspaceContent'
import type { WorkspaceContent } from '../workspaceContent'

test('project creation returns the ID and editing a legacy project preserves membership and optional metadata', () => {
  const old = { id: 'old', title: 'เดิม', chatIds: ['a'] }
  const content: WorkspaceContent = { projects: [old], artifacts: [] }
  const id = applyContentAction(content, { action: 'save-project', title: '  ใหม่  ', description: '  รายละเอียด  ' }, [])
  assert.ok(id)
  assert.deepEqual(content.projects[0], { id, title: 'ใหม่', chatIds: [], description: 'รายละเอียด' })
  applyContentAction(content, { action: 'pin-project', id: 'old', pinned: true }, [])
  applyContentAction(content, { action: 'save-project', id: 'old', title: 'ปรับชื่อ' }, [])
  assert.deepEqual(old, { id: 'old', title: 'ปรับชื่อ', chatIds: ['a'], pinned: true })

  assert.throws(() => applyContentAction(content, {
    action: 'save-project', id, title: 'ชื่อที่ต้องไม่ถูกบันทึก', description: 'x'.repeat(PROJECT_DESCRIPTION_LIMIT + 1),
  }, []))
  assert.equal(content.projects[0].title, 'ใหม่')
})

test('batching project chats is all-or-nothing and retries do not duplicate membership', () => {
  const project = { id: 'p', title: 'โปรเจกต์', chatIds: ['a'] }
  const content: WorkspaceContent = { projects: [project], artifacts: [] }
  const chats = [{ id: 'a' }, { id: 'b' }, { id: 'c' }]
  assert.throws(() => applyContentAction(content, { action: 'add-project-chats', id: project.id, chatIds: ['b', 'missing'] }, chats))
  assert.deepEqual(project.chatIds, ['a'])
  const action = { action: 'add-project-chats' as const, id: project.id, chatIds: ['a', 'b', 'c', 'c'] }
  applyContentAction(content, action, chats)
  applyContentAction(content, action, chats)
  assert.deepEqual(project.chatIds, ['a', 'b', 'c'])
  applyContentAction(content, { action: 'delete-project', id: project.id }, chats)
  assert.deepEqual(content.projects, [])
  assert.deepEqual(chats.map(chat => chat.id), ['a', 'b', 'c'])
})
