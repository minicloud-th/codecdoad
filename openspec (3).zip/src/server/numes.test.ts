import test from 'node:test';
import assert from 'node:assert/strict';
import {
  NUMES_BASE_URL,
  NUMES_FREE_MODEL,
  classifyNumesError,
  createNumesClient,
  maxTokensForNumesEffort,
  validateNumesPayload,
} from './numes';

test('validateNumesPayload validates messages, effort budget, and injects system instruction', () => {
  const res = validateNumesPayload({
    effort: 'High',
    messages: [
      { role: 'system', content: 'client attempt to override' },
      { role: 'user', content: 'Explain consistent hashing in one sentence.' },
    ],
  });
  assert.equal(res.ok, true);
  if (!res.ok) return;
  assert.equal(res.data.effort, 'High');
  assert.equal(res.data.maxTokens, maxTokensForNumesEffort('High'));
  assert.equal(res.data.messages[0].role, 'system');
  assert.match(res.data.messages[0].content, /OPENSPEC/);
  assert.equal(res.data.messages.length, 2);
  assert.deepEqual(res.data.messages[1], {
    role: 'user',
    content: 'Explain consistent hashing in one sentence.',
  });
});

test('validateNumesPayload rejects empty, malformed, oversized, or invalid-effort requests', () => {
  assert.equal(validateNumesPayload(null).ok, false);
  assert.equal(validateNumesPayload({ messages: [] }).ok, false);
  assert.equal(validateNumesPayload({ effort: 'Extreme', messages: [{ role: 'user', content: 'hi' }] }).ok, false);
  assert.equal(validateNumesPayload({ messages: [{ role: 'assistant', content: 'hi' }] }).ok, false);
  assert.equal(
    validateNumesPayload({ messages: [{ role: 'user', content: 'a'.repeat(20_000) }] }).ok,
    false,
  );
});

test('createNumesClient targets Numes API endpoint and deepseek/deepseek-v4.1-flash:free model', () => {
  assert.equal(NUMES_BASE_URL, 'https://api.numes.ai/api/v1');
  assert.equal(NUMES_FREE_MODEL, 'deepseek/deepseek-v4.1-flash:free');
  const client = createNumesClient('test-placeholder-value');
  assert.equal(client.baseURL, NUMES_BASE_URL);
});

test('classifyNumesError classifies 401/403 keys, 404 model missing, 429 rate limits, and 502 errors', () => {
  const keyErr = Object.assign(new Error('401 Invalid token'), { status: 401 });
  assert.equal(classifyNumesError(keyErr).status, 401);
  assert.match(classifyNumesError(keyErr).message, /NUMES_API_KEY ไม่ถูกต้อง/);

  const notFoundErr = Object.assign(new Error('404 Model not found'), { status: 404 });
  assert.equal(classifyNumesError(notFoundErr).status, 404);
  assert.match(classifyNumesError(notFoundErr).message, /ไม่พบโมเดล/);

  const rateErr = Object.assign(new Error('429 Too many requests'), { status: 429 });
  assert.equal(classifyNumesError(rateErr).status, 429);

  const genericErr = new Error('network timeout');
  assert.equal(classifyNumesError(genericErr).status, 502);
});
