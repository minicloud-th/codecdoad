import test from 'node:test';
import assert from 'node:assert/strict';
import {
  FIVE_HOUR_WINDOW_MS,
  WEEKLY_WINDOW_MS,
  computeDashboardStats,
  defaultSettings,
  formatResetCountdown,
  normalizeSettings,
  pruneUsageEvents,
  publicWorkspaceId,
  usageLimitsForPlan,
  validateAndMergeSettings,
} from './settingsLogic';
import type { Workspace } from './types';

test('defaultSettings returns clean OPENSPEC defaults', () => {
  const settings = defaultSettings();
  assert.equal(settings.theme, 'dark');
  assert.equal(settings.accentColor, '#4a8dff');
  assert.equal(settings.language, 'th');
  assert.equal(settings.timezone, 'Asia/Bangkok');
  assert.equal(settings.plan, 'free');
  assert.equal(settings.billingCycle, 'monthly');
  assert.equal(settings.improveModel, false);
  assert.deepEqual(settings.connectors, {
    telegram: false,
    discord: false,
    line: false,
    github: false,
  });
});

test('normalizeSettings falls back cleanly for invalid values', () => {
  const normalized = normalizeSettings({
    theme: 'neon' as 'dark',
    accentColor: '#deadbe' as '#4a8dff',
    language: 'fr' as 'th',
    timezone: 'Mars/Phobos',
    email: 'invalid-email',
    plan: 'enterprise' as 'pro',
    connectors: { telegram: true, discord: 'yes' as unknown as boolean } as never,
  });
  assert.equal(normalized.theme, 'dark');
  assert.equal(normalized.accentColor, '#4a8dff');
  assert.equal(normalized.language, 'th');
  assert.equal(normalized.timezone, 'Asia/Bangkok');
  assert.equal(normalized.email, '');
  assert.equal(normalized.plan, 'free');
  assert.equal(normalized.connectors.telegram, true);
  assert.equal(normalized.connectors.discord, false);
});

test('validateAndMergeSettings updates valid fields and rejects bad email or connector', () => {
  const base = defaultSettings();
  const ok = validateAndMergeSettings(base, {
    theme: 'system',
    accentColor: '#a855f7',
    plan: 'pro',
    billingCycle: 'annually',
    email: 'dev@bluezycode.th',
    connectors: { telegram: true, github: true },
  });
  assert.equal(ok.ok, true);
  if (ok.ok) {
    assert.equal(ok.next.theme, 'system');
    assert.equal(ok.next.accentColor, '#a855f7');
    assert.equal(ok.next.plan, 'pro');
    assert.equal(ok.next.billingCycle, 'annually');
    assert.equal(ok.next.email, 'dev@bluezycode.th');
    assert.equal(ok.next.connectors.telegram, true);
    assert.equal(ok.next.connectors.github, true);
    assert.equal(ok.next.connectors.discord, false);
  }

  const goPlan = validateAndMergeSettings(base, { plan: 'go' });
  assert.equal(goPlan.ok, true);
  if (goPlan.ok) assert.equal(goPlan.next.plan, 'go');

  const goPlusPlan = validateAndMergeSettings(base, { plan: 'go_plus', billingCycle: 'daily' });
  assert.equal(goPlusPlan.ok, true);
  if (goPlusPlan.ok) {
    assert.equal(goPlusPlan.next.plan, 'go_plus');
    assert.equal(goPlusPlan.next.billingCycle, 'daily');
  }

  const weeklyCycle = validateAndMergeSettings(base, { plan: 'go', billingCycle: 'weekly' });
  assert.equal(weeklyCycle.ok, true);
  if (weeklyCycle.ok) assert.equal(weeklyCycle.next.billingCycle, 'weekly');

  const badAccent = validateAndMergeSettings(base, { accentColor: '#000000' });
  assert.equal(badAccent.ok, false);

  const badEmail = validateAndMergeSettings(base, { email: 'not-an-email' });
  assert.equal(badEmail.ok, false);

  const badConnector = validateAndMergeSettings(base, {
    connectors: { slack: true },
  });
  assert.equal(badConnector.ok, false);
});

test('publicWorkspaceId hashes the local ID deterministically', async () => {
  const secret = 'a'.repeat(48);
  const pub1 = await publicWorkspaceId(secret);
  const pub2 = await publicWorkspaceId(secret);
  assert.equal(pub1, pub2);
  assert.ok(pub1.startsWith('bz_'));
  assert.ok(!pub1.includes('aaaaaaa'));
});

test('computeDashboardStats computes exact real metrics from workspace chats', () => {
  const now = new Date('2026-11-22T08:00:00.000Z');
  const ws: Workspace = {
    name: 'Dev',
    settings: defaultSettings(),
    chats: [
      {
        id: '1',
        title: 'Today chat',
        updated: '2026-11-22T07:30:00.000Z',
        turns: [
          {
            prompt: 'Hello world',
            reply: 'Reply content here',
            model: 'Workspace',
            files: [{ name: 'index.ts', content: 'console.log(1);' }],
          },
        ],
      },
    ],
    archivedChats: [
      {
        id: '2',
        title: 'Old archived chat',
        updated: '2026-11-20T07:30:00.000Z',
        turns: [
          {
            prompt: 'Old prompt',
            reply: 'Old reply',
            model: 'Workspace',
            files: [],
          },
        ],
      },
    ],
  };

  const stats = computeDashboardStats(ws, 8 * 1024 * 1024, now);
  assert.equal(stats.totalChats, 1);
  assert.equal(stats.archivedChats, 1);
  assert.equal(stats.totalTurns, 2);
  assert.equal(stats.todayTurns, 1);
  assert.equal(stats.totalFiles, 1);
  assert.ok(stats.estimatedTokens > 0);
  assert.ok(stats.storageBytes > 100);
  assert.equal(stats.fiveHourUsed, 1);
  assert.equal(stats.fiveHourLimit, 20);
  assert.equal(stats.weeklyUsed, 2);
  assert.equal(stats.weeklyLimit, 100);
  assert.equal(
    stats.fiveHourResetAt,
    new Date(Date.parse('2026-11-22T07:30:00.000Z') + FIVE_HOUR_WINDOW_MS).toISOString(),
  );
  assert.equal(
    stats.weeklyResetAt,
    new Date(Date.parse('2026-11-20T07:30:00.000Z') + WEEKLY_WINDOW_MS).toISOString(),
  );
});

test('5-hour and weekly rolling windows expire accurately and respect plan tiers', () => {
  const now = new Date('2026-11-24T12:00:00.000Z');
  const nowMs = now.getTime();
  const within5h = new Date(nowMs - 2 * 60 * 60 * 1000).toISOString();
  const expired5hWithinWeek = new Date(nowMs - 6 * 60 * 60 * 1000).toISOString();
  const expiredWeek = new Date(nowMs - WEEKLY_WINDOW_MS - 60_000).toISOString();

  const ws: Workspace = {
    name: 'Pro User',
    settings: { ...defaultSettings(), plan: 'pro' },
    chats: [],
    usageEvents: [expiredWeek, expired5hWithinWeek, within5h],
  };

  const stats = computeDashboardStats(ws, 8 * 1024 * 1024, now);
  assert.equal(stats.fiveHourUsed, 1);
  assert.equal(stats.fiveHourLimit, 200);
  assert.equal(stats.weeklyUsed, 2);
  assert.equal(stats.weeklyLimit, 1000);
  assert.equal(stats.fiveHourResetAt, new Date(Date.parse(within5h) + FIVE_HOUR_WINDOW_MS).toISOString());
  assert.equal(
    stats.weeklyResetAt,
    new Date(Date.parse(expired5hWithinWeek) + WEEKLY_WINDOW_MS).toISOString(),
  );

  const pruned = pruneUsageEvents(ws.usageEvents, nowMs);
  assert.equal(pruned.length, 2);
  assert.deepEqual(usageLimitsForPlan('max'), { fiveHourLimit: 500, weeklyLimit: 2500 });
});

test('formatResetCountdown renders readable Thai reset durations', () => {
  const now = new Date('2026-11-24T12:00:00.000Z');
  assert.equal(formatResetCountdown(null, now), 'พร้อมใช้งานเต็มโควตา');
  assert.equal(formatResetCountdown('2026-11-24T12:00:30.000Z', now), 'รีเซ็ตใน < 1 นาที');
  assert.equal(formatResetCountdown('2026-11-24T12:45:00.000Z', now), 'รีเซ็ตใน 45 นาที');
  assert.equal(formatResetCountdown('2026-11-24T16:30:00.000Z', now), 'รีเซ็ตใน 4 ชม. 30 นาที');
  assert.equal(formatResetCountdown('2026-11-27T14:00:00.000Z', now), 'รีเซ็ตใน 3 วัน 2 ชม.');
});

test('computeDashboardStats separates real AI usage + exact tokens from file-only turns and tracks Workspace assets', () => {
  const now = new Date('2026-11-24T12:00:00.000Z');
  const nowMs = now.getTime();
  const oneHourAgo = new Date(nowMs - 60 * 60 * 1000).toISOString();
  const twoDaysAgo = new Date(nowMs - 2 * 24 * 60 * 60 * 1000).toISOString();

  const ws: Workspace = {
    name: 'Real AI + Workspace',
    settings: { ...defaultSettings(), timezone: 'UTC' },
    content: {
      projects: [{ id: 'p1', title: 'Spec' }],
      artifacts: [{ id: 'a1' }, { id: 'a2' }],
    },
    chats: [
      {
        id: 'c1',
        title: 'Mixed chat',
        updated: oneHourAgo,
        turns: [
          {
            prompt: 'Old message',
            reply: 'Old answer',
            model: 'Gemini 4 Flash',
            files: [],
            createdAt: twoDaysAgo,
            usedAi: true,
          },
          {
            prompt: '',
            reply: 'Local file scan only',
            model: 'Gemini 4 Flash',
            files: [{ name: 'big.ts', content: 'x'.repeat(3000) }],
            createdAt: oneHourAgo,
            usedAi: false,
          },
          {
            prompt: 'Explain code',
            reply: 'Clear explanation',
            model: 'Gemini 4 Flash',
            files: [],
            createdAt: oneHourAgo,
            usedAi: true,
            usage: { promptTokens: 40, completionTokens: 20, totalTokens: 60, exactTokens: true },
          },
        ],
      },
    ],
    usageEvents: [
      {
        at: twoDaysAgo,
        modelId: 'ai',
        modelName: 'Speconi',
        engine: 'local',
        promptTokens: 30,
        completionTokens: 15,
        totalTokens: 45,
        exactTokens: true,
      },
      {
        at: oneHourAgo,
        modelId: 'gemini-4-hydrogen',
        modelName: 'Gemini 4 Flash',
        engine: 'cloud',
        promptTokens: 40,
        completionTokens: 20,
        totalTokens: 60,
        exactTokens: true,
      },
    ],
  };

  const stats = computeDashboardStats(ws, 8 * 1024 * 1024, now);
  // Real AI metrics: 2 real AI calls in 7d (1 within 5h, 1 today), exact token sum = 105
  assert.equal(stats.fiveHourUsed, 1);
  assert.equal(stats.weeklyUsed, 2);
  assert.equal(stats.todayAiCalls, 1);
  assert.equal(stats.fiveHourAiTokens, 60);
  assert.equal(stats.weeklyAiTokens, 105);
  assert.equal(stats.aiTotalTokens, 105);
  assert.equal(stats.aiPromptTokens, 70);
  assert.equal(stats.aiCompletionTokens, 35);
  assert.equal(stats.exactAiCalls, 2);
  assert.equal(stats.modelBreakdown.length, 2);

  // Workspace metrics: only 2 turns occurred today (not all 3 in c1), 1 file, 1 project, 2 artifacts
  assert.equal(stats.totalChats, 1);
  assert.equal(stats.totalTurns, 3);
  assert.equal(stats.todayTurns, 2);
  assert.equal(stats.totalFiles, 1);
  assert.equal(stats.totalProjects, 1);
  assert.equal(stats.totalArtifacts, 2);

  // Verify fallback calculation when usageEvents is absent excludes usedAi: false file-only turns
  const fallbackWs: Workspace = { ...ws, usageEvents: undefined };
  const fallbackStats = computeDashboardStats(fallbackWs, 8 * 1024 * 1024, now);
  assert.equal(fallbackStats.weeklyUsed, 2);
  assert.equal(fallbackStats.fiveHourUsed, 1);

  const pruned = pruneUsageEvents(ws.usageEvents, nowMs);
  assert.equal(pruned.length, 2);
  assert.equal(typeof pruned[0], 'object');
});
