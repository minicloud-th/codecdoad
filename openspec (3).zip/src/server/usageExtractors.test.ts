import test from 'node:test';
import assert from 'node:assert/strict';
import {
  estimateAiUsage,
  extractClientUsage,
  extractGeminiUsage,
  extractOpenAiUsage,
} from './usageExtractors';

test('extractGeminiUsage extracts prompt, candidates + thoughts, and total tokens', () => {
  const usage = extractGeminiUsage({
    promptTokenCount: 120,
    candidatesTokenCount: 45,
    thoughtsTokenCount: 15,
    totalTokenCount: 180,
  });
  assert.deepEqual(usage, {
    promptTokens: 120,
    completionTokens: 60,
    totalTokens: 180,
    exactTokens: true,
  });
  assert.equal(extractGeminiUsage(null), null);
  assert.equal(extractGeminiUsage({ promptTokenCount: 0, candidatesTokenCount: 0 }), null);
});

test('extractOpenAiUsage extracts prompt_tokens, completion_tokens, and total_tokens', () => {
  const usage = extractOpenAiUsage({
    prompt_tokens: 80,
    completion_tokens: 32,
    total_tokens: 112,
  });
  assert.deepEqual(usage, {
    promptTokens: 80,
    completionTokens: 32,
    totalTokens: 112,
    exactTokens: true,
  });
  assert.equal(extractOpenAiUsage({}), null);
});

test('extractClientUsage normalizes camelCase, OpenAI, and Gemini payloads', () => {
  assert.deepEqual(
    extractClientUsage({ promptTokens: 42, completionTokens: 18, totalTokens: 60, exactTokens: true }),
    { promptTokens: 42, completionTokens: 18, totalTokens: 60, exactTokens: true },
  );
  assert.deepEqual(
    extractClientUsage({ prompt_tokens: 10, completion_tokens: 5 }),
    { promptTokens: 10, completionTokens: 5, totalTokens: 15, exactTokens: true },
  );
});

test('estimateAiUsage calculates honest non-exact estimates from AI prompt and reply only', () => {
  const estimated = estimateAiUsage('Hello world', 'Reply text here');
  assert.equal(estimated.exactTokens, false);
  assert.ok(estimated.promptTokens > 0);
  assert.ok(estimated.completionTokens > 0);
  assert.equal(estimated.totalTokens, estimated.promptTokens + estimated.completionTokens);
});
