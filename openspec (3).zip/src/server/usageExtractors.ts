import type { AiUsageMetadata } from './types.ts';

function toNonNegativeInt(value: unknown): number {
  return typeof value === 'number' && Number.isFinite(value) && value > 0
    ? Math.round(value)
    : 0;
}

export function extractGeminiUsage(raw: unknown): AiUsageMetadata | null {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const record = raw as Record<string, unknown>;
  const promptTokens = toNonNegativeInt(record.promptTokenCount);
  const candidates = toNonNegativeInt(record.candidatesTokenCount);
  const thoughts = toNonNegativeInt(record.thoughtsTokenCount);
  const completionTokens = candidates + thoughts;
  const totalTokens = Math.max(
    promptTokens + completionTokens,
    toNonNegativeInt(record.totalTokenCount),
  );
  if (totalTokens === 0 && promptTokens === 0 && completionTokens === 0) {
    return null;
  }
  return {
    promptTokens,
    completionTokens,
    totalTokens,
    exactTokens: true,
  };
}

export function extractOpenAiUsage(raw: unknown): AiUsageMetadata | null {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const record = raw as Record<string, unknown>;
  const promptTokens = toNonNegativeInt(record.prompt_tokens);
  const completionTokens = toNonNegativeInt(record.completion_tokens);
  const totalTokens = Math.max(
    promptTokens + completionTokens,
    toNonNegativeInt(record.total_tokens),
  );
  if (totalTokens === 0 && promptTokens === 0 && completionTokens === 0) {
    return null;
  }
  return {
    promptTokens,
    completionTokens,
    totalTokens,
    exactTokens: true,
  };
}

export function extractClientUsage(raw: unknown): AiUsageMetadata | null {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const record = raw as Record<string, unknown>;
  if (
    typeof record.promptTokens === 'number' ||
    typeof record.completionTokens === 'number' ||
    typeof record.totalTokens === 'number'
  ) {
    const promptTokens = toNonNegativeInt(record.promptTokens);
    const completionTokens = toNonNegativeInt(record.completionTokens);
    const totalTokens = Math.max(
      promptTokens + completionTokens,
      toNonNegativeInt(record.totalTokens),
    );
    if (totalTokens === 0 && promptTokens === 0 && completionTokens === 0) {
      return null;
    }
    return {
      promptTokens,
      completionTokens,
      totalTokens,
      exactTokens: typeof record.exactTokens === 'boolean' ? record.exactTokens : true,
    };
  }
  return extractOpenAiUsage(raw) ?? extractGeminiUsage(raw);
}

export function estimateAiUsage(promptText: string, replyText: string): AiUsageMetadata {
  const promptTrimmed = promptText.trim();
  const replyTrimmed = replyText.trim();
  const promptTokens = promptTrimmed ? Math.ceil(promptTrimmed.length / 3.5) : 0;
  const completionTokens = replyTrimmed ? Math.ceil(replyTrimmed.length / 3.5) : 0;
  return {
    promptTokens,
    completionTokens,
    totalTokens: promptTokens + completionTokens,
    exactTokens: false,
  };
}
