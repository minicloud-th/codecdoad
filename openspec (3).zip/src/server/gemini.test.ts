import test from 'node:test';
import assert from 'node:assert/strict';
import { ThinkingLevel } from '@google/genai';
import {
  GEMINI_FLASH_LITE_MODEL,
  GEMINI_HYDROGEN_MODEL,
  classifyGeminiError,
  createGeminiClient,
  isGeminiFreeModel,
  thinkingLevelForGemini,
  toGeminiContents,
  validateGeminiPayload,
} from './gemini.ts';

test('isGeminiFreeModel recognizes only supported free Gemini models', () => {
  assert.equal(isGeminiFreeModel(GEMINI_HYDROGEN_MODEL), true);
  assert.equal(isGeminiFreeModel(GEMINI_FLASH_LITE_MODEL), true);
  assert.equal(isGeminiFreeModel('gemini-4-carbon'), false);
  assert.equal(isGeminiFreeModel('gemini-1.5-flash'), false);
});

test('thinkingLevelForGemini maps Effort levels cleanly per free Gemini model', () => {
  assert.equal(thinkingLevelForGemini(GEMINI_HYDROGEN_MODEL, 'Low'), ThinkingLevel.LOW);
  assert.equal(thinkingLevelForGemini(GEMINI_HYDROGEN_MODEL, 'Medium'), ThinkingLevel.MEDIUM);
  assert.equal(thinkingLevelForGemini(GEMINI_HYDROGEN_MODEL, 'High'), ThinkingLevel.HIGH);
  assert.equal(thinkingLevelForGemini(GEMINI_HYDROGEN_MODEL, 'Max'), ThinkingLevel.XHIGH);

  assert.equal(thinkingLevelForGemini(GEMINI_FLASH_LITE_MODEL, 'Low'), ThinkingLevel.MINIMAL);
  assert.equal(thinkingLevelForGemini(GEMINI_FLASH_LITE_MODEL, 'Medium'), ThinkingLevel.LOW);
  assert.equal(thinkingLevelForGemini(GEMINI_FLASH_LITE_MODEL, 'High'), ThinkingLevel.MEDIUM);
  assert.equal(thinkingLevelForGemini(GEMINI_FLASH_LITE_MODEL, 'Max'), ThinkingLevel.HIGH);
});

test('validateGeminiPayload builds Gemini contents, systemInstruction, and validates inline images', () => {
  const ok = validateGeminiPayload({
    model: GEMINI_HYDROGEN_MODEL,
    effort: 'Max',
    messages: [
      { role: 'user', content: 'สวัสดี' },
      { role: 'assistant', content: 'สวัสดีครับ' },
      { role: 'user', content: 'ดูรูปนี้ให้หน่อย' },
    ],
    images: [{ mimeType: 'image/webp', data: 'UklGRh4AAABXRUJQ' }],
  });

  assert.equal(ok.ok, true);
  if (!ok.ok) return;
  assert.equal(ok.data.model, 'gemini-4-hydrogen');
  assert.equal(ok.data.thinkingLevel, ThinkingLevel.XHIGH);
  assert.match(ok.data.systemInstruction, /OPENSPEC/);
  assert.equal(ok.data.contents.length, 3);
  assert.equal(ok.data.contents[1].role, 'model');
  assert.equal(ok.data.contents[2].parts?.length, 2);
  assert.deepEqual(ok.data.contents[2].parts?.[0], {
    inlineData: { mimeType: 'image/webp', data: 'UklGRh4AAABXRUJQ' },
  });
});

test('validateGeminiPayload rejects unsupported models, empty prompts, and invalid images', () => {
  assert.equal(
    validateGeminiPayload({
      model: 'gemini-4-carbon',
      messages: [{ role: 'user', content: 'hi' }],
    }).ok,
    false,
  );
  assert.equal(validateGeminiPayload({ model: GEMINI_HYDROGEN_MODEL, messages: [] }).ok, false);
  assert.equal(
    validateGeminiPayload({
      model: GEMINI_HYDROGEN_MODEL,
      messages: [{ role: 'user', content: 'hi' }],
      images: [{ mimeType: 'image/svg+xml', data: 'abc' }],
    }).ok,
    false,
  );
  const contents = toGeminiContents([{ role: 'user', content: 'hello' }]);
  assert.equal(contents.length, 1);
  assert.equal(contents[0].role, 'user');
});

test('createGeminiClient constructs GoogleGenAI instance and classifyGeminiError classifies status codes', () => {
  const client = createGeminiClient('test-key');
  assert.ok(client);
  assert.equal(classifyGeminiError({ status: 403, message: 'PERMISSION_DENIED' }, 'Gemini 4 Flash').status, 403);
  assert.equal(classifyGeminiError({ status: 429, message: 'RESOURCE_EXHAUSTED' }, 'Gemini 4 Flash').status, 429);
  assert.equal(classifyGeminiError({ status: 404, message: 'NOT_FOUND' }, 'Gemini 4 Flash').status, 404);
  assert.equal(classifyGeminiError(new Error('network down'), 'Gemini 4 Flash').status, 502);
});
