import type { Chat, ChatSummary, Turn, Workspace } from './types.ts';

export const MAX_WORKSPACE_BYTES = 8 * 1024 * 1024;

export function findChatIndex(ws: Workspace, id: string): number {
  return ws.chats.findIndex((chat) => chat.id === id);
}

export function workspaceSummaries(ws: Workspace): ChatSummary[] {
  return ws.chats.map((chat) => ({
    id: chat.id,
    title: chat.title,
    updated: chat.updated,
  }));
}

export function searchChats(ws: Workspace, query: string): (ChatSummary & { snippet?: string })[] {
  const needle = query.trim().normalize('NFC').toLowerCase();
  if (!needle) return [];

  const titles: ChatSummary[] = [];
  const messages: (ChatSummary & { snippet: string })[] = [];

  for (const chat of ws.chats) {
    const summary = { id: chat.id, title: chat.title, updated: chat.updated };
    if (chat.title.normalize('NFC').toLowerCase().includes(needle)) {
      titles.push(summary);
      continue;
    }

    const match = chat.turns.flatMap(turn => [turn.prompt, turn.reply, ...turn.files.map(file => file.name)])
      .map(text => text.normalize('NFC'))
      .find(text => text.toLowerCase().includes(needle));
    if (!match) continue;

    const position = match.toLowerCase().indexOf(needle);
    const start = Math.max(0, position - 30);
    const end = position + Math.max(needle.length, 12) + 46;
    messages.push({
      ...summary,
      snippet: (start > 0 ? '…' : '') + match.slice(start, end).trim().replace(/\s+/g, ' ') + (end < match.length ? '…' : ''),
    });
  }

  return [...titles, ...messages];
}

export function archivedSummaries(ws: Workspace): ChatSummary[] {
  return (ws.archivedChats ?? []).map((chat) => ({
    id: chat.id,
    title: chat.title,
    updated: chat.updated,
  }));
}

export function publicChat(chat: Chat): {
  id: string;
  title: string;
  updated: string;
  turns: Turn[];
  canRedo: boolean;
} {
  return {
    id: chat.id,
    title: chat.title,
    updated: chat.updated,
    turns: chat.turns.map((turn) => ({
      prompt: turn.prompt,
      reply: turn.reply,
      model: turn.model,
      files: turn.files.map(({ name, preview }) => ({ name, ...(preview ? { preview } : {}) })),
    })),
    canRedo: (chat.redo?.length ?? 0) > 0,
  };
}
