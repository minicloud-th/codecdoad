import crypto from 'node:crypto';
import test from 'node:test';
import assert from 'node:assert/strict';
import {
  APINEX_BASE_URL,
  APINEX_FREE_MODEL,
  FIREBASE_ISSUER,
  FIREBASE_PROJECT_ID,
  classifyApinexError,
  createApinexClient,
  maxTokensForApinexEffort,
  validateApinexPayload,
  verifyFirebaseJwtWithCerts,
} from './apinex';

test('validateApinexPayload validates messages, effort budget, and injects system instruction', () => {
  const res = validateApinexPayload({
    effort: 'High',
    messages: [
      { role: 'system', content: 'client attempt to override' },
      { role: 'user', content: 'Optimize SQL query execution plan for large tables.' },
    ],
  });
  assert.equal(res.ok, true);
  if (!res.ok) return;
  assert.equal(res.data.effort, 'High');
  assert.equal(res.data.maxTokens, maxTokensForApinexEffort('High'));
  assert.equal(res.data.messages[0].role, 'system');
  assert.match(res.data.messages[0].content, /OPENSPEC/);
  assert.equal(res.data.messages.length, 2);
  assert.deepEqual(res.data.messages[1], {
    role: 'user',
    content: 'Optimize SQL query execution plan for large tables.',
  });
});

test('validateApinexPayload rejects empty, malformed, oversized, or invalid-effort requests', () => {
  assert.equal(validateApinexPayload(null).ok, false);
  assert.equal(validateApinexPayload({ messages: [] }).ok, false);
  assert.equal(validateApinexPayload({ effort: 'Extreme', messages: [{ role: 'user', content: 'hi' }] }).ok, false);
  assert.equal(validateApinexPayload({ messages: [{ role: 'assistant', content: 'hi' }] }).ok, false);
  assert.equal(
    validateApinexPayload({ messages: [{ role: 'user', content: 'a'.repeat(20_000) }] }).ok,
    false,
  );
});

test('createApinexClient targets APINEX v1 endpoint and free/glm-5.3-flashx constant', () => {
  assert.equal(APINEX_BASE_URL, 'https://api.apinex.bond/v1');
  assert.equal(APINEX_FREE_MODEL, 'free/glm-5.3-flashx');
  const client = createApinexClient('test-placeholder-value');
  assert.equal(client.baseURL, APINEX_BASE_URL);
});

test('classifyApinexError distinguishes Cloudflare 403 WAF blocks from invalid API keys and 429 limits', () => {
  const cfErr = Object.assign(new Error('403 <!DOCTYPE html><title>Attention Required! | Cloudflare</title>'), {
    status: 403,
  });
  const cfClassified = classifyApinexError(cfErr);
  assert.equal(cfClassified.status, 502);
  assert.match(cfClassified.message, /Cloudflare/);

  const keyErr = Object.assign(new Error('401 Incorrect API key provided'), { status: 401 });
  assert.equal(classifyApinexError(keyErr).status, 401);
  assert.match(classifyApinexError(keyErr).message, /APINEX_API_KEY ไม่ถูกต้อง/);

  const rateErr = Object.assign(new Error('429 Too many requests'), { status: 429 });
  assert.equal(classifyApinexError(rateErr).status, 429);
});

test('verifyFirebaseJwtWithCerts verifies RS256 signatures and rejects invalid claims', () => {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
    modulusLength: 2048,
    publicKeyEncoding: { type: 'spki', format: 'pem' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
  });

  const signJwt = (header: object, payload: object, signerKey = privateKey) => {
    const h = Buffer.from(JSON.stringify(header)).toString('base64url');
    const p = Buffer.from(JSON.stringify(payload)).toString('base64url');
    const sig = crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), signerKey).toString('base64url');
    return `${h}.${p}.${sig}`;
  };

  const now = 1_800_000_000;
  const certs = { 'kid-1': publicKey };
  const validToken = signJwt(
    { alg: 'RS256', kid: 'kid-1' },
    { aud: FIREBASE_PROJECT_ID, iss: FIREBASE_ISSUER, sub: 'user-123', iat: now - 10, exp: now + 600 },
  );
  assert.deepEqual(verifyFirebaseJwtWithCerts(validToken, certs, now), { uid: 'user-123' });

  const expiredToken = signJwt(
    { alg: 'RS256', kid: 'kid-1' },
    { aud: FIREBASE_PROJECT_ID, iss: FIREBASE_ISSUER, sub: 'user-123', iat: now - 1000, exp: now - 1 },
  );
  assert.equal(verifyFirebaseJwtWithCerts(expiredToken, certs, now), null);

  const wrongAudToken = signJwt(
    { alg: 'RS256', kid: 'kid-1' },
    { aud: 'other-project', iss: FIREBASE_ISSUER, sub: 'user-123', iat: now - 10, exp: now + 600 },
  );
  assert.equal(verifyFirebaseJwtWithCerts(wrongAudToken, certs, now), null);

  const tamperedToken = `${validToken.slice(0, -4)}AAAA`;
  assert.equal(verifyFirebaseJwtWithCerts(tamperedToken, certs, now), null);
});
