import assert from 'node:assert/strict';
import test from 'node:test';
import {
  DISCORD_ISSUER,
  buildDiscordAuthorizeUrl,
  createStateStore,
  createTicketStore,
  discordAvatarUrl,
  getDiscordRedirectUri,
  isValidDiscordIssuer,
  parseCookieHeader,
  renderOAuthPopupHtml,
  resolveAppBaseUrl,
  signSessionToken,
  toDiscordSessionUser,
  verifySessionToken,
} from './discordOAuth.ts';

test('resolveAppBaseUrl and getDiscordRedirectUri derive exact callback URL from APP_URL', () => {
  assert.equal(resolveAppBaseUrl(undefined), 'http://localhost:3000');
  assert.equal(resolveAppBaseUrl('MY_APP_URL'), 'http://localhost:3000');
  assert.equal(
    getDiscordRedirectUri('https://ais-dev-example.run.app/'),
    'https://ais-dev-example.run.app/auth/discord/callback',
  );
  assert.equal(
    getDiscordRedirectUri('https://ais-dev-example.run.app', 'https://custom.example/cb/'),
    'https://custom.example/cb',
  );
});

test('buildDiscordAuthorizeUrl builds standard Discord authorization code URL with state', () => {
  const raw = buildDiscordAuthorizeUrl({
    clientId: '157730590492196864',
    redirectUri: 'https://app.example.run.app/auth/discord/callback',
    state: 'state-xyz',
  });
  const parsed = new URL(raw);
  assert.equal(parsed.origin + parsed.pathname, 'https://discord.com/oauth2/authorize');
  assert.equal(parsed.searchParams.get('response_type'), 'code');
  assert.equal(parsed.searchParams.get('client_id'), '157730590492196864');
  assert.equal(parsed.searchParams.get('scope'), 'identify email');
  assert.equal(parsed.searchParams.get('state'), 'state-xyz');
  assert.equal(parsed.searchParams.get('prompt'), 'consent');
});

test('isValidDiscordIssuer enforces RFC 9207 issuer check', () => {
  assert.equal(isValidDiscordIssuer(DISCORD_ISSUER), true);
  assert.equal(isValidDiscordIssuer(undefined), true);
  assert.equal(isValidDiscordIssuer('https://evil.example'), false);
});

test('CSRF state store is single-use and expires', () => {
  const store = createStateStore(1000);
  const state = store.issue(100);
  assert.equal(store.consume(state, 500), true);
  assert.equal(store.consume(state, 500), false);
  const expired = store.issue(100);
  assert.equal(store.consume(expired, 1200), false);
});

test('One-time ticket store and HMAC session tokens validate and reject tampering', () => {
  const user = toDiscordSessionUser({
    id: '268473310986240001',
    username: 'discorduser',
    global_name: 'Discord User',
    avatar: 'f749bb0cbeeb26ef21eca719337d20f1',
    email: 'user@example.com',
  });
  assert.equal(user.id, 'discord:268473310986240001');
  assert.equal(
    discordAvatarUrl(user.discordId, 'f749bb0cbeeb26ef21eca719337d20f1'),
    'https://cdn.discordapp.com/avatars/268473310986240001/f749bb0cbeeb26ef21eca719337d20f1.png?size=128',
  );

  const tickets = createTicketStore<typeof user>(1000);
  const ticket = tickets.issue(user, 100);
  assert.deepEqual(tickets.consume(ticket, 200), user);
  assert.equal(tickets.consume(ticket, 200), null);

  const token = signSessionToken(user, 'test-secret', 60, 1000);
  assert.deepEqual(verifySessionToken(token, 'test-secret', 1030), user);
  assert.equal(verifySessionToken(token, 'wrong-secret', 1030), null);
  assert.equal(verifySessionToken(token, 'test-secret', 1061), null);
});

test('parseCookieHeader and renderOAuthPopupHtml handle special characters safely', () => {
  const cookies = parseCookieHeader('foo=bar; openspec_discord_session=abc%2Edef');
  assert.equal(cookies.openspec_discord_session, 'abc.def');

  const html = renderOAuthPopupHtml({
    type: 'DISCORD_OAUTH_ERROR',
    error: '</script><script>alert(1)</script>',
  });
  assert.equal(html.includes('</script><script>alert(1)'), false);
  assert.match(html, /\\u003c\/script\\u003e/);
});
