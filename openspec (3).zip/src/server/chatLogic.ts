import { byteLength } from '../api.ts';
import { analyzeText, MAX_ENGINE_BYTES } from './engine.ts';
import type { Chat, SendRequest, ValidFileAttachment } from './types.ts';

export const MAX_ATTACHMENTS = 10;
export const MAX_FILE_BYTES = MAX_ENGINE_BYTES;
export const MAX_TOTAL_FILE_BYTES = 192 * 1024;
export const MAX_PROMPT_BYTES = 12000;

export function excerpt(value: string, limit: number): string {
  const chars = [...value];
  if (chars.length <= limit) {
    return value;
  }
  return chars.slice(0, limit).join('') + '…';
}

export function validRequest(input: SendRequest): boolean {
  if (
    typeof input.prompt !== 'string' ||
    !Array.isArray(input.files) ||
    byteLength(input.prompt) > MAX_PROMPT_BYTES ||
    input.files.length > MAX_ATTACHMENTS ||
    (input.prompt === '' && input.files.length === 0)
  ) {
    return false;
  }

  let total = 0;
  for (const file of input.files) {
    if (
      !file ||
      typeof file.name !== 'string' ||
      typeof file.content !== 'string' ||
      file.name.trim() === '' ||
      byteLength(file.name) > 255 ||
      /[/\\\x00\r\n]/.test(file.name) ||
      file.content.includes('\0')
    ) {
      return false;
    }
    const contentBytes = byteLength(file.content);
    if (contentBytes > MAX_FILE_BYTES) {
      return false;
    }
    total += contentBytes;
  }

  return total <= MAX_TOTAL_FILE_BYTES;
}

export function isValidProfileName(name: string): boolean {
  return [...name].length <= 40 && !/[\x00\r\n]/.test(name);
}

export function titleFor(input: SendRequest): string {
  const collapsed = input.prompt.trim().split(/\s+/).filter(Boolean).join(' ');
  const title = collapsed || input.files[0]?.name || 'แชตใหม่';
  return excerpt(title, 66);
}

export function summarizeChat(chat: Chat): string {
  if (chat.turns.length === 0) {
    return 'แชตนี้ยังไม่มีข้อความให้สรุป';
  }
  const parts: string[] = [`สรุปแชต · ${chat.turns.length} รอบ`];
  const first = Math.max(0, chat.turns.length - 5);
  if (first > 0) {
    parts.push('แสดง 5 รอบล่าสุด');
  }
  for (const turn of chat.turns.slice(first)) {
    let topic = turn.prompt.trim().split(/\s+/).filter(Boolean).join(' ');
    if (!topic && turn.files.length > 0) {
      topic = turn.files[0].name;
    }
    const replySummary = turn.reply.trim().split(/\s+/).filter(Boolean).join(' ');
    parts.push(`\n• ${excerpt(topic, 120)}\n  ${excerpt(replySummary, 160)}`);
  }
  return parts.join('\n').trim();
}

export function analyzeFilesReply(files: ValidFileAttachment[]): string {
  if (files.length === 0) {
    return (
      'Workspace พร้อมวิเคราะห์ไฟล์โค้ด กด + แล้วแนบไฟล์เพื่อดูจำนวนบรรทัด ขนาดไฟล์ และตำแหน่ง TODO/FIXME\n\n' +
      'ถ้าต้องการถามเรื่องโค้ด ให้เลือกโมเดล AI ในเมนูโมเดล'
    );
  }

  const sections: string[] = ['ผลวิเคราะห์ไฟล์'];
  for (const file of files) {
    if (file.preview?.kind === 'image') {
      sections.push(`\n${file.name}\nภาพ ${file.preview.width} × ${file.preview.height} พิกเซล · ${file.preview.size} ไบต์\nดูภาพตัวอย่างได้ในแชต`);
      continue;
    }
    if (file.preview?.kind === 'archive') {
      sections.push('\n' + file.name + '\n' + file.content);
      continue;
    }
    const report = analyzeText(file.content);
    const lines: string[] = [
      '',
      file.name,
      `${report.bytes} ไบต์ · ${report.lines} บรรทัด · ${report.non_blank} บรรทัดที่มีข้อความ`,
      `บรรทัดยาวที่สุด ${report.longest} ตัวอักษร`,
    ];
    if (report.notes.length === 0) {
      lines.push('ไม่พบ TODO หรือ FIXME');
    } else {
      for (const note of report.notes) {
        lines.push(`บรรทัด ${note.line}  ${note.text}`);
      }
    }
    sections.push(lines.join('\n'));
  }

  return sections.join('\n').trim();
}
