import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import test from 'node:test'
import { imageDimensions, imageSizeAllowed } from '../imageDimensions.ts'

const fixture = (name: string) => new Uint8Array(readFileSync(new URL(`./fixtures/${name}`, import.meta.url)))

test('reads dimensions from PNG, JPEG, GIF and WebP headers', () => {
  for (const name of ['a.png', 'a.jpg', 'a.gif', 'a.webp', 'b.webp']) {
    assert.deepEqual(imageDimensions(fixture(name)), { width: 321, height: 123 }, name)
  }
})

test('rejects oversized or unreadable images', () => {
  assert.equal(imageSizeAllowed(imageDimensions(fixture('wide.png'))), false)
  assert.equal(imageSizeAllowed({ width: 8000, height: 8001 }), false)
  assert.equal(imageSizeAllowed({ width: 4000, height: 3000 }), true)
  assert.equal(imageDimensions(new Uint8Array([1, 2, 3, 4])), null)
  assert.equal(imageSizeAllowed(null), false)
  assert.equal(imageDimensions(new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 0, 0])), null)
})
