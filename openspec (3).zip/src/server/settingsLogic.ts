import { byteLength } from '../api.ts';
import { isStoredProfileImage } from '../profileImage.ts';
import { estimateAiUsage } from './usageExtractors.ts';
import type {
  AccentColor,
  AiUsageEvent,
  BillingCycle,
  ConnectorSettings,
  DashboardStats,
  LanguagePreference,
  ModelUsageBreakdown,
  PlanId,
  ThemePreference,
  Workspace,
  WorkspaceSettings,
} from './types.ts';

export const ALLOWED_THEMES = new Set<ThemePreference>(['dark', 'light', 'system']);
export const ALLOWED_ACCENT_COLORS = new Set<AccentColor>([
  '#4a8dff',
  '#2f6df0',
  '#1fa3e8',
  '#a855f7',
  '#ec4899',
  '#f59e0b',
  '#84cc16',
  '#8b8b92',
]);
export const ALLOWED_LANGUAGES = new Set<LanguagePreference>(['th', 'en', 'ja']);
export const ALLOWED_TIMEZONES = new Set<string>([
  'Asia/Bangkok',
  'UTC',
  'America/New_York',
  'Asia/Tokyo',
]);
export const ALLOWED_PLANS = new Set<PlanId>(['free', 'go', 'go_plus', 'lite', 'pro', 'max']);
export const ALLOWED_BILLING_CYCLES = new Set<BillingCycle>(['daily', 'weekly', 'monthly', 'quarterly', 'annually']);
export const ALLOWED_CONNECTORS = new Set<keyof ConnectorSettings>([
  'telegram',
  'discord',
  'line',
  'github',
]);

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function defaultSettings(): WorkspaceSettings {
  return {
    theme: 'dark',
    accentColor: '#4a8dff',
    language: 'th',
    timezone: 'Asia/Bangkok',
    email: '',
    plan: 'free',
    billingCycle: 'monthly',
    improveModel: false,
    connectors: {
      telegram: false,
      discord: false,
      line: false,
      github: false,
    },
  };
}

export function normalizeSettings(raw?: Partial<WorkspaceSettings> | null): WorkspaceSettings {
  const base = defaultSettings();
  if (!raw || typeof raw !== 'object') {
    return base;
  }

  if (isStoredProfileImage(raw.avatar)) base.avatar = raw.avatar;
  if (raw.theme && ALLOWED_THEMES.has(raw.theme)) {
    base.theme = raw.theme;
  }
  if (raw.accentColor && ALLOWED_ACCENT_COLORS.has(raw.accentColor)) {
    base.accentColor = raw.accentColor;
  }
  if (raw.language && ALLOWED_LANGUAGES.has(raw.language)) {
    base.language = raw.language;
  }
  if (typeof raw.timezone === 'string' && ALLOWED_TIMEZONES.has(raw.timezone)) {
    base.timezone = raw.timezone;
  }
  if (typeof raw.email === 'string' && raw.email.trim().length <= 120) {
    const trimmed = raw.email.trim();
    if (trimmed === '' || EMAIL_PATTERN.test(trimmed)) {
      base.email = trimmed;
    }
  }
  if (raw.plan && ALLOWED_PLANS.has(raw.plan)) {
    base.plan = raw.plan;
  }
  if (raw.billingCycle && ALLOWED_BILLING_CYCLES.has(raw.billingCycle)) {
    base.billingCycle = raw.billingCycle;
  }
  if (typeof raw.improveModel === 'boolean') {
    base.improveModel = raw.improveModel;
  }
  if (raw.connectors && typeof raw.connectors === 'object') {
    for (const key of ALLOWED_CONNECTORS) {
      const value = (raw.connectors as Record<string, unknown>)[key];
      if (typeof value === 'boolean') {
        base.connectors[key] = value;
      }
    }
  }
  return base;
}

export function validateAndMergeSettings(
  current: WorkspaceSettings,
  patch: Record<string, unknown>,
): { ok: true; next: WorkspaceSettings } | { ok: false; error: string } {
  const next: WorkspaceSettings = {
    ...current,
    connectors: { ...current.connectors },
  };

  if ('avatar' in patch) {
    if (patch.avatar === '') {
      delete next.avatar;
    } else if (isStoredProfileImage(patch.avatar)) {
      next.avatar = patch.avatar;
    } else {
      return { ok: false, error: 'รูปโปรไฟล์ไม่ถูกต้อง' };
    }
  }

  if ('theme' in patch) {
    if (typeof patch.theme !== 'string' || !ALLOWED_THEMES.has(patch.theme as ThemePreference)) {
      return { ok: false, error: 'รูปแบบธีมไม่ถูกต้อง' };
    }
    next.theme = patch.theme as ThemePreference;
  }

  if ('accentColor' in patch) {
    if (
      typeof patch.accentColor !== 'string' ||
      !ALLOWED_ACCENT_COLORS.has(patch.accentColor as AccentColor)
    ) {
      return { ok: false, error: 'สีธีมที่เลือกไม่ถูกต้อง' };
    }
    next.accentColor = patch.accentColor as AccentColor;
  }

  if ('language' in patch) {
    if (
      typeof patch.language !== 'string' ||
      !ALLOWED_LANGUAGES.has(patch.language as LanguagePreference)
    ) {
      return { ok: false, error: 'ภาษาที่เลือกไม่รองรับ' };
    }
    next.language = patch.language as LanguagePreference;
  }

  if ('timezone' in patch) {
    if (typeof patch.timezone !== 'string' || !ALLOWED_TIMEZONES.has(patch.timezone)) {
      return { ok: false, error: 'เขตเวลาที่เลือกไม่ถูกต้อง' };
    }
    next.timezone = patch.timezone;
  }

  if ('email' in patch) {
    if (typeof patch.email !== 'string') {
      return { ok: false, error: 'รูปแบบอีเมลไม่ถูกต้อง' };
    }
    const email = patch.email.trim();
    if (email.length > 120 || (email !== '' && !EMAIL_PATTERN.test(email))) {
      return { ok: false, error: 'กรุณากรอกอีเมลให้ถูกต้อง (ไม่เกิน 120 ตัวอักษร)' };
    }
    next.email = email;
  }

  if ('plan' in patch) {
    if (typeof patch.plan !== 'string' || !ALLOWED_PLANS.has(patch.plan as PlanId)) {
      return { ok: false, error: 'แพ็กเกจที่เลือกไม่ถูกต้อง' };
    }
    next.plan = patch.plan as PlanId;
  }

  if ('billingCycle' in patch) {
    if (
      typeof patch.billingCycle !== 'string' ||
      !ALLOWED_BILLING_CYCLES.has(patch.billingCycle as BillingCycle)
    ) {
      return { ok: false, error: 'รอบบิลที่เลือกไม่ถูกต้อง' };
    }
    next.billingCycle = patch.billingCycle as BillingCycle;
  }

  if ('improveModel' in patch) {
    if (typeof patch.improveModel !== 'boolean') {
      return { ok: false, error: 'ค่าสถานะความเป็นส่วนตัวไม่ถูกต้อง' };
    }
    next.improveModel = patch.improveModel;
  }

  if ('connectors' in patch) {
    if (!patch.connectors || typeof patch.connectors !== 'object' || Array.isArray(patch.connectors)) {
      return { ok: false, error: 'ข้อมูลการเชื่อมต่อไม่ถูกต้อง' };
    }
    const entries = Object.entries(patch.connectors as Record<string, unknown>);
    for (const [key, value] of entries) {
      if (!ALLOWED_CONNECTORS.has(key as keyof ConnectorSettings) || typeof value !== 'boolean') {
        return { ok: false, error: 'ข้อมูลการเชื่อมต่อไม่ถูกต้อง' };
      }
      next.connectors[key as keyof ConnectorSettings] = value;
    }
  }

  return { ok: true, next };
}

export async function publicWorkspaceId(rawId: string): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`bluezycode:${rawId}`));
  const hash = Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('');
  return `bz_${hash.slice(0, 14)}`;
}

function dayKeyInZone(date: Date, timeZone: string): string {
  try {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(date);
  } catch {
    return date.toISOString().slice(0, 10);
  }
}

export const FIVE_HOUR_WINDOW_MS = 5 * 60 * 60 * 1000;
export const WEEKLY_WINDOW_MS = 7 * 24 * 60 * 60 * 1000;

export function usageLimitsForPlan(plan: PlanId): { fiveHourLimit: number; weeklyLimit: number } {
  switch (plan) {
    case 'go':
    case 'lite':
      return { fiveHourLimit: 80, weeklyLimit: 400 };
    case 'go_plus':
    case 'pro':
      return { fiveHourLimit: 200, weeklyLimit: 1000 };
    case 'max':
      return { fiveHourLimit: 500, weeklyLimit: 2500 };
    case 'free':
    default:
      return { fiveHourLimit: 20, weeklyLimit: 100 };
  }
}

function nonNegInt(value: unknown): number {
  return typeof value === 'number' && Number.isFinite(value) && value > 0 ? Math.round(value) : 0;
}

function normalizeUsageEntry(raw: string | AiUsageEvent, nowMs: number): AiUsageEvent | null {
  const cutoff = nowMs - WEEKLY_WINDOW_MS;
  if (typeof raw === 'string') {
    const ms = Date.parse(raw);
    if (!Number.isFinite(ms) || ms < cutoff || ms > nowMs + 60_000) return null;
    return {
      at: new Date(ms).toISOString(),
      modelId: 'ai',
      modelName: 'AI',
      engine: 'cloud',
      promptTokens: 0,
      completionTokens: 0,
      totalTokens: 0,
      exactTokens: false,
    };
  }
  if (!raw || typeof raw !== 'object' || typeof raw.at !== 'string') return null;
  const ms = Date.parse(raw.at);
  if (!Number.isFinite(ms) || ms < cutoff || ms > nowMs + 60_000) return null;
  const promptTokens = nonNegInt(raw.promptTokens);
  const completionTokens = nonNegInt(raw.completionTokens);
  const totalTokens = Math.max(promptTokens + completionTokens, nonNegInt(raw.totalTokens));
  return {
    at: new Date(ms).toISOString(),
    modelId: typeof raw.modelId === 'string' && raw.modelId.trim() ? raw.modelId : 'ai',
    modelName: typeof raw.modelName === 'string' && raw.modelName.trim() ? raw.modelName : 'AI',
    engine: raw.engine === 'local' ? 'local' : 'cloud',
    promptTokens,
    completionTokens,
    totalTokens,
    exactTokens: Boolean(raw.exactTokens),
  };
}

export function collectUsageEvents(ws: Workspace, nowMs: number): AiUsageEvent[] {
  const cutoff = nowMs - WEEKLY_WINDOW_MS;
  const events: AiUsageEvent[] = [];

  if (Array.isArray(ws.usageEvents)) {
    for (const raw of ws.usageEvents) {
      const normalized = normalizeUsageEntry(raw, nowMs);
      if (normalized) events.push(normalized);
    }
    return events.sort((a, b) => Date.parse(a.at) - Date.parse(b.at));
  }

  const allChats = [...(ws.chats ?? []), ...(ws.archivedChats ?? [])];
  for (const chat of allChats) {
    const chatUpdatedMs = Date.parse(chat.updated);
    for (const turn of chat.turns ?? []) {
      const usedAi = turn.usedAi !== false && Boolean(turn.prompt || (turn.files?.length ?? 0) === 0);
      if (!usedAi) continue;
      const turnMs = turn.createdAt ? Date.parse(turn.createdAt) : chatUpdatedMs;
      if (!Number.isFinite(turnMs) || turnMs < cutoff || turnMs > nowMs + 60_000) continue;
      const usage = turn.usage ?? estimateAiUsage(turn.prompt ?? '', turn.reply ?? '');
      const modelName = turn.model?.trim() || 'AI';
      events.push({
        at: new Date(turnMs).toISOString(),
        modelId: modelName === 'Speconi' ? 'ai' : modelName,
        modelName,
        engine: modelName === 'Speconi' ? 'local' : 'cloud',
        ...usage,
      });
    }
  }
  return events.sort((a, b) => Date.parse(a.at) - Date.parse(b.at));
}

export function collectUsageTimestampsMs(ws: Workspace, nowMs: number): number[] {
  return collectUsageEvents(ws, nowMs).map((event) => Date.parse(event.at));
}

export function pruneUsageEvents(
  events: readonly (string | AiUsageEvent)[] | undefined,
  nowMs: number,
): (string | AiUsageEvent)[] {
  const cutoff = nowMs - WEEKLY_WINDOW_MS;
  const kept: (string | AiUsageEvent)[] = [];
  for (const raw of events ?? []) {
    if (typeof raw === 'string') {
      const ms = Date.parse(raw);
      if (Number.isFinite(ms) && ms >= cutoff && ms <= nowMs + 60_000) {
        kept.push(new Date(ms).toISOString());
      }
      continue;
    }
    const normalized = normalizeUsageEntry(raw, nowMs);
    if (normalized) {
      kept.push(normalized);
    }
  }
  return kept;
}

export function formatResetCountdown(resetAt: string | null, now = new Date()): string {
  if (!resetAt) return 'พร้อมใช้งานเต็มโควตา';
  const resetMs = Date.parse(resetAt);
  if (!Number.isFinite(resetMs)) return 'พร้อมใช้งาน';
  const diffMs = Math.max(0, resetMs - now.getTime());
  if (diffMs < 60_000) return 'รีเซ็ตใน < 1 นาที';
  const totalMinutes = Math.ceil(diffMs / 60_000);
  const days = Math.floor(totalMinutes / (24 * 60));
  const hours = Math.floor((totalMinutes % (24 * 60)) / 60);
  const minutes = totalMinutes % 60;
  if (days > 0) {
    return hours > 0 ? `รีเซ็ตใน ${days} วัน ${hours} ชม.` : `รีเซ็ตใน ${days} วัน`;
  }
  if (hours > 0) {
    return minutes > 0 ? `รีเซ็ตใน ${hours} ชม. ${minutes} นาที` : `รีเซ็ตใน ${hours} ชม.`;
  }
  return `รีเซ็ตใน ${minutes} นาที`;
}

export function computeDashboardStats(
  ws: Workspace,
  maxStorageBytes: number,
  now = new Date(),
): DashboardStats {
  const normalized = normalizeSettings(ws.settings);
  const tz = normalized.timezone;
  const nowMs = now.getTime();
  const todayKey = dayKeyInZone(now, tz);
  const activeChats = ws.chats ?? [];
  const archived = ws.archivedChats ?? [];
  const allChats = [...activeChats, ...archived];

  let totalTurns = 0;
  let todayTurns = 0;
  let totalFiles = 0;

  for (const chat of allChats) {
    totalTurns += chat.turns.length;
    for (const turn of chat.turns) {
      totalFiles += turn.files.length;
      const turnDate = new Date(turn.createdAt ?? chat.updated);
      if (!Number.isNaN(turnDate.getTime()) && dayKeyInZone(turnDate, tz) === todayKey) {
        todayTurns += 1;
      }
    }
  }

  const events = collectUsageEvents(ws, nowMs);
  const fiveHourCutoff = nowMs - FIVE_HOUR_WINDOW_MS;
  const fiveHourEvents = events.filter((event) => Date.parse(event.at) >= fiveHourCutoff);
  const weeklyEvents = events;
  const { fiveHourLimit, weeklyLimit } = usageLimitsForPlan(normalized.plan);

  const fiveHourResetAt = fiveHourEvents.length > 0
    ? new Date(Date.parse(fiveHourEvents[0].at) + FIVE_HOUR_WINDOW_MS).toISOString()
    : null;
  const weeklyResetAt = weeklyEvents.length > 0
    ? new Date(Date.parse(weeklyEvents[0].at) + WEEKLY_WINDOW_MS).toISOString()
    : null;

  let todayAiCalls = 0;
  let fiveHourAiTokens = 0;
  let weeklyAiTokens = 0;
  let aiPromptTokens = 0;
  let aiCompletionTokens = 0;
  let exactAiCalls = 0;
  const breakdownMap = new Map<string, ModelUsageBreakdown>();

  for (const event of fiveHourEvents) {
    fiveHourAiTokens += event.totalTokens;
  }

  for (const event of weeklyEvents) {
    const eventDate = new Date(event.at);
    if (!Number.isNaN(eventDate.getTime()) && dayKeyInZone(eventDate, tz) === todayKey) {
      todayAiCalls += 1;
    }
    weeklyAiTokens += event.totalTokens;
    aiPromptTokens += event.promptTokens;
    aiCompletionTokens += event.completionTokens;
    if (event.exactTokens) exactAiCalls += 1;

    const key = `${event.engine}:${event.modelId}:${event.modelName}`;
    const existing = breakdownMap.get(key);
    if (existing) {
      existing.calls += 1;
      existing.totalTokens += event.totalTokens;
      if (event.exactTokens) existing.exactCalls += 1;
      if (event.at > existing.lastUsedAt) existing.lastUsedAt = event.at;
    } else {
      breakdownMap.set(key, {
        modelId: event.modelId,
        modelName: event.modelName,
        engine: event.engine,
        calls: 1,
        totalTokens: event.totalTokens,
        exactCalls: event.exactTokens ? 1 : 0,
        lastUsedAt: event.at,
      });
    }
  }

  const modelBreakdown = Array.from(breakdownMap.values()).sort(
    (a, b) => b.calls - a.calls || b.lastUsedAt.localeCompare(a.lastUsedAt),
  );

  const storageBytes = byteLength(JSON.stringify(ws));
  const totalProjects = Array.isArray(ws.content?.projects) ? ws.content.projects.length : 0;
  const totalArtifacts = Array.isArray(ws.content?.artifacts) ? ws.content.artifacts.length : 0;

  return {
    totalChats: activeChats.length,
    archivedChats: archived.length,
    chatLimit: 40,
    totalTurns,
    todayTurns,
    totalFiles,
    totalProjects,
    totalArtifacts,
    estimatedTokens: weeklyAiTokens,
    storageBytes,
    maxStorageBytes,
    fiveHourUsed: fiveHourEvents.length,
    fiveHourLimit,
    fiveHourResetAt,
    weeklyUsed: weeklyEvents.length,
    weeklyLimit,
    weeklyResetAt,
    todayAiCalls,
    fiveHourAiTokens,
    weeklyAiTokens,
    aiPromptTokens,
    aiCompletionTokens,
    aiTotalTokens: weeklyAiTokens,
    exactAiCalls,
    modelBreakdown,
  };
}

