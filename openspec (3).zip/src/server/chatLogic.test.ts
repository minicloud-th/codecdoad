import assert from 'node:assert/strict';
import test from 'node:test';
import {
  analyzeFilesReply,
  excerpt,
  isValidProfileName,
  summarizeChat,
  titleFor,
  validRequest,
} from './chatLogic.ts';
import { publicChat, searchChats } from './store.ts';
import type { Chat, Workspace } from './types.ts';

test('workspace search matches titles, both sides of a turn and file names without searching archived chats', () => {
  const first: Chat = { id: 'first', title: 'แก้โค้ด', updated: '', turns: [
    { prompt: 'เปิดไฟล์ config', reply: 'ตั้งค่า Cache ให้เหมาะสม', model: 'AI', files: [{ name: 'cache.ts', content: 'private secret' }] },
  ] };
  const titled: Chat = { id: 'title', title: 'Cache notes', updated: '', turns: [] };
  const archived: Chat = { id: 'archive', title: 'Cache archive', updated: '', turns: [] };
  const workspace: Workspace = { name: 'Test', chats: [first, titled], archivedChats: [archived] };

  assert.deepEqual(searchChats(workspace, ' CACHE ').map(match => match.id), ['title', 'first']);
  assert.match(searchChats(workspace, 'เหมาะสม')[0]?.snippet ?? '', /Cache/);
  assert.equal(searchChats(workspace, 'config')[0]?.id, 'first');
  assert.equal(searchChats(workspace, 'cache.ts')[0]?.snippet, 'cache.ts');
  assert.deepEqual(searchChats(workspace, 'private secret'), []);
  assert.deepEqual(searchChats(workspace, ' '), []);
});

test('validRequest enforces prompt, file count, filename, and size rules', () => {
  assert.equal(validRequest({ chatId: '', prompt: '', model: 'workspace', files: [] }), false);
  assert.equal(validRequest({ chatId: '', prompt: 'hello', model: 'workspace', files: [] }), true);
  const files = Array.from({ length: 11 }, (_, index) => ({ name: `file-${index}.ts`, content: 'x' }));
  assert.equal(validRequest({ chatId: '', prompt: '', model: 'workspace', files: files.slice(0, 10) }), true);
  assert.equal(validRequest({ chatId: '', prompt: '', model: 'workspace', files }), false);
  assert.equal(
    validRequest({
      chatId: '',
      prompt: '',
      model: 'workspace',
      files: [{ name: '../bad.ts', content: 'x' }],
    }),
    false,
  );
  assert.equal(
    validRequest({
      chatId: '',
      prompt: '',
      model: 'workspace',
      files: [{ name: 'ok.ts', content: '// TODO: fix' }],
    }),
    true,
  );
});

test('titleFor and excerpt truncate long strings safely by code points', () => {
  assert.equal(excerpt('สวัสดีครับ', 4), 'สวัส…');
  assert.equal(
    titleFor({ chatId: '', prompt: '   hello   world  ', model: 'workspace', files: [] }),
    'hello world',
  );
  assert.equal(
    titleFor({
      chatId: '',
      prompt: '',
      model: 'workspace',
      files: [{ name: 'main.ts', content: 'code' }],
    }),
    'main.ts',
  );
});

test('analyzeFilesReply formats Thai workspace report with TODO/FIXME notes', () => {
  const emptyReply = analyzeFilesReply([]);
  assert.match(emptyReply, /Workspace พร้อมวิเคราะห์ไฟล์โค้ด/);

  const report = analyzeFilesReply([
    { name: 'sample.ts', content: 'const a = 1;\n// TODO: refactor\n' },
  ]);
  assert.match(report, /ผลวิเคราะห์ไฟล์/);
  assert.match(report, /sample\.ts/);
  assert.match(report, /2 บรรทัด/);
  assert.match(report, /บรรทัด 2 {2}\/\/ TODO: refactor/);
});

test('summarizeChat and publicChat strip file contents and summarize recent turns', () => {
  const chat: Chat = {
    id: 'abc',
    title: 'Test',
    updated: '2026-01-01T00:00:00.000Z',
    turns: [
      {
        prompt: 'Check file',
        reply: 'Done',
        model: 'Workspace',
        files: [{ name: 'index.ts', content: 'secret content' }],
      },
    ],
    redo: [{ prompt: 'Old', reply: 'Old reply', model: 'Workspace', files: [] }],
  };

  const pub = publicChat(chat);
  assert.equal(pub.canRedo, true);
  assert.equal(pub.turns[0].files[0].content, undefined);
  assert.match(summarizeChat(chat), /สรุปแชต · 1 รอบ/);
});

test('isValidProfileName validates input', () => {
  assert.equal(isValidProfileName('Alice'), true);
  assert.equal(isValidProfileName('ก'.repeat(41)), false);
  assert.equal(isValidProfileName('Bad\nName'), false);
});
