import test from 'node:test'
import assert from 'node:assert/strict'
import {
  APINEX_MODEL_ID,
  APINEX_MODEL_NAME,
  DEFAULT_SKILLS,
  EFFORT_LEVELS,
  EFFORT_MODEL_SPECS,
  GEMINI_FLASH_LITE_MODEL_ID,
  GEMINI_FLASH_LITE_MODEL_NAME,
  GEMINI_HYDROGEN_MODEL_ID,
  GEMINI_HYDROGEN_MODEL_NAME,
  LOCAL_PLAN_MODEL_NAME,
  NUMES_MODEL_ID,
  NUMES_MODEL_NAME,
  activeModelDisplayLabel,
  apinexMaxTokens,
  buildModelWorkerRequest,
  buildPromptWithSkills,
  clampEffortRatio,
  computeSliderRatio,
  effortFromRatio,
  effortIndex,
  effortMaxTokens,
  effortStopRatio,
  formatAutoAnalysisReply,
  formatModelDisplayName,
  geminiThinkingLabel,
  isCloudModelId,
  isGeminiModelId,
  isLocalModelName,
  isNumesModelId,
  modelForEffort,
  neutralizeStreamingLabel,
  numesMaxTokens,
  resolveTurnToolSituation,
} from './composerLogic'

test('formatModelDisplayName labels Gemini free models, DeepSeek V4.1 Flash, GLM-5.3 FlashX, and Speconi clearly under Plan Free', () => {
  assert.deepEqual(formatModelDisplayName({ id: GEMINI_HYDROGEN_MODEL_ID, name: GEMINI_HYDROGEN_MODEL_NAME }), {
    title: 'Gemini 4 Flash',
    badge: 'Plan Free',
  })
  assert.deepEqual(formatModelDisplayName({ id: GEMINI_FLASH_LITE_MODEL_ID, name: GEMINI_FLASH_LITE_MODEL_NAME }), {
    title: 'Gemini 3.1 Flash Lite',
    badge: 'Plan Free',
  })
  assert.deepEqual(formatModelDisplayName({ id: NUMES_MODEL_ID, name: NUMES_MODEL_NAME }), {
    title: 'DeepSeek V4.1 Flash',
    badge: 'Plan Free',
  })
  assert.deepEqual(formatModelDisplayName({ id: APINEX_MODEL_ID, name: APINEX_MODEL_NAME }), {
    title: 'GLM-5.3 FlashX',
    badge: 'Plan Free',
  })
  assert.deepEqual(formatModelDisplayName({ id: 'ai', name: LOCAL_PLAN_MODEL_NAME }), {
    title: 'Speconi',
    badge: 'Plan Free · AI จากเครื่อง',
  })
  assert.equal(activeModelDisplayLabel(GEMINI_HYDROGEN_MODEL_ID, 'Max'), 'Gemini 4 Flash')
  assert.equal(activeModelDisplayLabel(GEMINI_FLASH_LITE_MODEL_ID, 'Low'), 'Gemini 3.1 Flash Lite')
  assert.equal(activeModelDisplayLabel(NUMES_MODEL_ID, 'Max'), 'DeepSeek V4.1 Flash')
  assert.equal(activeModelDisplayLabel(APINEX_MODEL_ID, 'Max'), 'GLM-5.3 FlashX')
  assert.equal(activeModelDisplayLabel('ai', 'Max'), 'Speconi')
  assert.equal(isGeminiModelId(GEMINI_HYDROGEN_MODEL_ID), true)
  assert.equal(isGeminiModelId(GEMINI_FLASH_LITE_MODEL_ID), true)
  assert.equal(isGeminiModelId(NUMES_MODEL_ID), false)
  assert.equal(isGeminiModelId(APINEX_MODEL_ID), false)
  assert.equal(isNumesModelId(NUMES_MODEL_ID), true)
  assert.equal(isNumesModelId(GEMINI_HYDROGEN_MODEL_ID), false)
  assert.equal(isCloudModelId(GEMINI_HYDROGEN_MODEL_ID), true)
  assert.equal(isCloudModelId(NUMES_MODEL_ID), true)
  assert.equal(isCloudModelId(APINEX_MODEL_ID), true)
  assert.equal(isCloudModelId('ai'), false)
  assert.equal(geminiThinkingLabel(GEMINI_HYDROGEN_MODEL_ID, 'Max'), 'XHigh')
  assert.equal(geminiThinkingLabel(GEMINI_FLASH_LITE_MODEL_ID, 'Low'), 'Minimal')
  assert.ok(apinexMaxTokens('Low') < apinexMaxTokens('Max'))
  assert.ok(numesMaxTokens('Low') < numesMaxTokens('Max'))
  assert.equal(isLocalModelName('Speconi'), true)
  assert.equal(isLocalModelName('DeepSeek V4.1 Flash'), true)
  assert.equal(isLocalModelName('GLM-5.3 FlashX'), true)
  assert.equal(isLocalModelName('Gemini 4 Flash'), true)
  assert.equal(isLocalModelName('Gemini 3.1 Flash Lite'), true)
})

test('effortFromRatio, effortIndex, and continuous slider helpers map 4 stops cleanly', () => {
  assert.equal(EFFORT_LEVELS.length, 4)
  assert.equal(effortFromRatio(-0.2), 'Low')
  assert.equal(effortFromRatio(0.33), 'Medium')
  assert.equal(effortFromRatio(0.67), 'High')
  assert.equal(effortFromRatio(1.4), 'Max')
  assert.equal(effortIndex('Low'), 0)
  assert.equal(effortIndex('Max'), 3)
  assert.equal(clampEffortRatio(Number.NaN), 1)
  assert.equal(clampEffortRatio(-0.5), 0)
  assert.equal(clampEffortRatio(0.42), 0.42)
  assert.equal(effortStopRatio('Low'), 0)
  assert.equal(effortStopRatio('Max'), 1)
  assert.equal(computeSliderRatio(16, 0, 232, 16), 0)
  assert.equal(computeSliderRatio(216, 0, 232, 16), 1)
  assert.equal(computeSliderRatio(116, 0, 232, 16), 0.5)
})

test('effortMaxTokens scales generation budget across effort levels', () => {
  assert.ok(effortMaxTokens('Low') < effortMaxTokens('Medium'))
  assert.ok(effortMaxTokens('Medium') < effortMaxTokens('High'))
  assert.ok(effortMaxTokens('High') < effortMaxTokens('Max'))
})

test('EFFORT_MODEL_SPECS maps each Effort level on Plan Free to a progressively higher model', () => {
  const ordered = EFFORT_LEVELS.map(level => modelForEffort(level))
  const uniqueRepos = new Set(ordered.map(spec => spec.repoId))
  assert.equal(uniqueRepos.size, 4)
  for (let i = 1; i < ordered.length; i++) {
    assert.ok(ordered[i].parameterBillions > ordered[i - 1].parameterBillions)
    assert.ok(ordered[i].approxBytesMB > ordered[i - 1].approxBytesMB)
    assert.ok(ordered[i].maxNewTokens > ordered[i - 1].maxNewTokens)
  }
  for (const spec of Object.values(EFFORT_MODEL_SPECS)) {
    assert.match(spec.repoId, /^onnx-community\//)
    assert.match(spec.revision, /^[0-9a-f]{40}$/)
    assert.equal(isLocalModelName(spec.displayName), true)
  }
  assert.equal(isLocalModelName('Plan Free'), true)
  assert.equal(isLocalModelName('Workspace'), false)
})

test('buildModelWorkerRequest builds effort-specific Hugging Face ONNX payloads', () => {
  const messages = [{ role: 'user' as const, content: 'สวัสดี' }]
  const lowReq = buildModelWorkerRequest('Low', messages)
  const medReq = buildModelWorkerRequest('Medium', messages)
  const highReq = buildModelWorkerRequest('High', messages)
  const maxReq = buildModelWorkerRequest('Max', messages)

  assert.equal(lowReq.modelId, 'onnx-community/Qwen3-0.6B-ONNX-OPT')
  assert.equal(lowReq.displayName, 'Speconi')
  assert.equal(lowReq.supportsThinkingControl, true)
  assert.equal(medReq.modelId, 'onnx-community/gemma-3-1b-it-ONNX')
  assert.equal(medReq.displayName, 'Speconi')
  assert.equal(medReq.supportsThinkingControl, false)
  assert.equal(highReq.modelId, 'onnx-community/Qwen2.5-1.5B-Instruct')
  assert.equal(highReq.dtype, 'q8')
  assert.equal(maxReq.modelId, 'onnx-community/Qwen3-1.7B-ONNX')
  assert.equal(maxReq.dtype, 'q8')
  assert.equal(maxReq.supportsThinkingControl, true)
  assert.notEqual(lowReq.modelKey, medReq.modelKey)
  assert.notEqual(medReq.modelKey, highReq.modelKey)
  assert.notEqual(highReq.modelKey, maxReq.modelKey)
})

test('buildPromptWithSkills prepends active skill instructions without losing prompt', () => {
  assert.equal(buildPromptWithSkills('  hello  ', []), 'hello')
  const combined = buildPromptWithSkills('ตรวจไฟล์นี้ให้หน่อย', [DEFAULT_SKILLS[0]])
  assert.match(combined, /\[Skill: เขียนสเปค OpenSpec\]/)
  assert.match(combined, /ตรวจไฟล์นี้ให้หน่อย$/)
})

test('formatAutoAnalysisReply combines automatic file analysis and AI reply cleanly', () => {
  assert.equal(formatAutoAnalysisReply('ผลวิเคราะห์ไฟล์'), 'ผลวิเคราะห์ไฟล์')
  assert.equal(formatAutoAnalysisReply('', 'คำตอบจาก AI'), 'คำตอบจาก AI')
  assert.equal(
    formatAutoAnalysisReply('ผลวิเคราะห์ไฟล์', 'คำตอบจาก AI'),
    'ผลวิเคราะห์ไฟล์\n\n---\n\nคำตอบจาก AI',
  )
})

test('resolveTurnToolSituation returns situation-specific Thai labels per state', () => {
  const downloading = resolveTurnToolSituation({
    streaming: true,
    progressText: 'กำลังดาวน์โหลด Gemma 3 1B · 48%',
    fileCount: 0,
    prompt: 'สรุปให้หน่อย',
    modelName: 'Gemma 3 1B',
  })
  assert.equal(downloading?.state, 'searching')
  assert.match(downloading?.label ?? '', /กำลังดาวน์โหลด Gemma 3 1B/)

  const scanning = resolveTurnToolSituation({
    streaming: true,
    progressText: '',
    fileCount: 2,
    prompt: '',
    modelName: 'Qwen3 0.6B',
  })
  assert.equal(scanning?.label, 'กำลังสแกนและวิเคราะห์ 2 ไฟล์แนบ...')

  const doneFiles = resolveTurnToolSituation({
    streaming: false,
    fileCount: 2,
    prompt: 'ตรวจโค้ด',
    modelName: 'Qwen3 0.6B',
  })
  assert.equal(doneFiles?.state, 'done')
  assert.equal(doneFiles?.label, 'วิเคราะห์ 2 ไฟล์แนบแล้ว')
  assert.equal(doneFiles?.headerLabel, 'ไฟล์ที่วิเคราะห์')

  const connectingCloud = resolveTurnToolSituation({
    streaming: true,
    progressText: 'กำลังเชื่อมต่อ GLM-5.3 FlashX...',
    fileCount: 0,
    prompt: 'Optimize SQL query execution plan for large tables.',
    modelName: 'GLM-5.3 FlashX',
  })
  assert.equal(connectingCloud?.state, 'searching')
  assert.equal(connectingCloud?.headerLabel, 'กำลังเชื่อมต่อโมเดล')

  const plainDone = resolveTurnToolSituation({
    streaming: false,
    fileCount: 0,
    prompt: 'สวัสดี',
    modelName: 'Qwen3 0.6B',
  })
  assert.equal(plainDone, null)
})

test('neutralizeStreamingLabel removes AI model names while keeping neutral state', () => {
  assert.equal(neutralizeStreamingLabel('กำลังเชื่อมต่อ Gemini 4 Flash...'), 'กำลังเชื่อมต่อ...')
  assert.equal(neutralizeStreamingLabel('DeepSeek V4.1 Flash กำลังตอบ...'), 'กำลังตอบ...')
  assert.equal(neutralizeStreamingLabel('กำลังดาวน์โหลด Gemma 3 1B · 48%'), 'กำลังเตรียมข้อมูล · 48%')
  assert.equal(neutralizeStreamingLabel(''), 'กำลังคิดคำตอบ...')
})
