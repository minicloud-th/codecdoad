import type { ReactNode } from 'react'
import { motion } from 'motion/react'
import { Popover } from 'radix-ui'
import type { DashboardStats } from './api'
import {
  ChevronRight,
  CreditCard,
  Home,
  Lightbulb,
  MessageSquare,
  Plug,
} from './icons'
import { IOS_SNAPPY_SPRING } from './motion'
import { formatResetCountdown } from './server/settingsLogic'
import { UsageIcon } from './UsageIcon'
import { useMobileNav } from './useMobileNav'

import type { RailSection } from './navigation'

const MID_ITEMS: {
  id: RailSection
  title: string
  mobileLabel: string
  desktopOnlyOnMobile?: boolean
  icon: typeof Home
}[] = [
  { id: 'home', title: 'หน้าหลัก', mobileLabel: 'หน้าหลัก', icon: Home },
  { id: 'chats', title: 'แชตทั้งหมด', mobileLabel: 'แชต', icon: MessageSquare },
  { id: 'subscription', title: 'Subscription', mobileLabel: 'แพ็กเกจ', desktopOnlyOnMobile: true, icon: CreditCard },
  { id: 'plugins', title: 'ปลั๊กอิน', mobileLabel: 'ปลั๊กอิน', desktopOnlyOnMobile: true, icon: Plug },
  { id: 'ideas', title: 'เทมเพลตคำสั่ง', mobileLabel: 'เทมเพลต', desktopOnlyOnMobile: true, icon: Lightbulb },
]

type RailProps = {
  section: RailSection
  chatCount: number
  stats?: DashboardStats
  busy: boolean
  onSelectSection(section: RailSection): void
  accountMenu: ReactNode
}

function remainingCapacity(used = 0, limit = 0) {
  return limit > 0 ? Math.min(100, Math.max(0, 100 * (limit - used) / limit)) : 0
}

function formatRemainingPercent(remaining: number) {
  return remaining > 0 && remaining < 1 ? '<1%' : Math.floor(remaining) + '%'
}

export function Rail({
  section,
  chatCount,
  stats,
  busy,
  onSelectSection,
  accountMenu,
}: RailProps) {
  const isMobile = useMobileNav()
  const ready = Boolean(stats)
  const fiveHourRemaining = remainingCapacity(stats?.fiveHourUsed, stats?.fiveHourLimit)
  const weeklyRemaining = remainingCapacity(stats?.weeklyUsed, stats?.weeklyLimit)
  const aiRemaining = Math.min(fiveHourRemaining, weeklyRemaining)
  const chatRemaining = remainingCapacity(stats?.totalChats, stats?.chatLimit ?? 40)
  const storageRemaining = remainingCapacity(stats?.storageBytes, stats?.maxStorageBytes)
  const workspaceRemaining = Math.min(chatRemaining, storageRemaining)
  const fiveHourLabel = formatRemainingPercent(fiveHourRemaining)
  const weeklyLabel = formatRemainingPercent(weeklyRemaining)
  const storageLabel = formatRemainingPercent(storageRemaining)
  const workspaceLabel = formatRemainingPercent(workspaceRemaining)

  function renderItem(item: (typeof MID_ITEMS)[number]) {
    const ItemIcon = item.icon
    const active = section === item.id
    const hiddenOnMobile = Boolean(item.desktopOnlyOnMobile) && isMobile
    if (hiddenOnMobile) return null
    return (
      <motion.button
        key={item.id}
        type="button"
        className={'oc-rb' + (active ? ' on' : '')}
        title={item.title}
        aria-label={item.title}
        aria-current={active ? 'page' : undefined}
        disabled={!ready || busy}
        whileTap={!ready || busy ? undefined : { scale: 0.88 }}
        transition={IOS_SNAPPY_SPRING}
        onClick={() => onSelectSection(item.id)}
      >
        {active && (
          <motion.span
            layoutId="rail-active-pill"
            className="oc-rb-bg"
            transition={IOS_SNAPPY_SPRING}
            aria-hidden="true"
          />
        )}
        <span className="oc-rb-icon">
          <ItemIcon size={isMobile ? 22 : 20} className="relative z-1" />
          {item.id === 'chats' && chatCount > 0 && (
            <span className="oc-bd tabular-nums">{chatCount}</span>
          )}
        </span>
        <span className="oc-rb-label">{item.mobileLabel}</span>
      </motion.button>
    )
  }

  return (
    <nav className="oc-rail" aria-label="แถบนำทางหลัก">
      <span className="oc-rail-brand">
        <span className="openspec-site-icon" role="img" aria-label="OPENSPEC" />
      </span>

      <div className="oc-rail-mid">
        {MID_ITEMS.map(renderItem)}
      </div>

      <div className="oc-rail-bot">
        {!isMobile && (
          <Popover.Root>
            <Popover.Trigger asChild>
              <motion.button type="button"
                className={'oc-rb usage-button' + (section === 'dashboard' ? ' on' : '')}
                aria-label="การใช้งาน"
                title={ready
                  ? `AI 5 ชม. เหลือ ${fiveHourLabel} · สัปดาห์เหลือ ${weeklyLabel} · Workspace เหลือ ${workspaceLabel}`
                  : 'การใช้งาน'}
                disabled={!ready || busy}
                whileTap={!ready || busy ? undefined : { scale: 0.9 }}
                transition={IOS_SNAPPY_SPRING}
              >
                {section === 'dashboard' && (
                  <motion.span
                    layoutId="rail-active-pill"
                    className="oc-rb-bg"
                    transition={IOS_SNAPPY_SPRING}
                    aria-hidden="true"
                  />
                )}
                <span className="oc-rb-icon">
                  <UsageIcon ai={aiRemaining} workspace={workspaceRemaining} />
                </span>
                <span className="oc-rb-label">ใช้งาน</span>
              </motion.button>
            </Popover.Trigger>
            <Popover.Portal>
              <Popover.Content className="usage-popover" aria-label="สรุปการใช้งาน AI และ Workspace"
                side="right"
                align="end"
                sideOffset={11}
                collisionPadding={10}>
                <p className="usage-heading">การใช้งาน · AI จริง + Workspace</p>
                <dl className="usage-rows">
                  <div>
                    <dt>
                      AI · ขีดจำกัด 5 ชม.
                      <small>{formatResetCountdown(stats?.fiveHourResetAt ?? null)}</small>
                    </dt>
                    <dd>
                      เหลือ {fiveHourLabel}
                      <small>{stats?.fiveHourUsed ?? 0} / {stats?.fiveHourLimit ?? 0}</small>
                    </dd>
                  </div>
                  <div>
                    <dt>
                      AI · ขีดจำกัดสัปดาห์
                      <small>{formatResetCountdown(stats?.weeklyResetAt ?? null)}</small>
                    </dt>
                    <dd>
                      เหลือ {weeklyLabel}
                      <small>{stats?.weeklyUsed ?? 0} / {stats?.weeklyLimit ?? 0}</small>
                    </dd>
                  </div>
                  <div className="usage-row-compact">
                    <dt>โทเคน AI จริง (7 วัน)</dt>
                    <dd>{(stats?.aiTotalTokens ?? 0).toLocaleString()}</dd>
                  </div>
                  <div className="usage-row-compact usage-row-divider">
                    <dt>Workspace · แชต</dt>
                    <dd>{stats?.totalChats ?? 0} / {stats?.chatLimit ?? 40}</dd>
                  </div>
                  <div className="usage-row-compact">
                    <dt>Workspace · พื้นที่จัดเก็บ</dt>
                    <dd>เหลือ {storageLabel}</dd>
                  </div>
                </dl>
                <Popover.Close asChild>
                  <button type="button" className="usage-manage" onClick={() => onSelectSection('dashboard')}>
                    จัดการการใช้งาน <ChevronRight size={15} />
                  </button>
                </Popover.Close>
              </Popover.Content>
            </Popover.Portal>
          </Popover.Root>
        )}
        {accountMenu}
      </div>
    </nav>
  )
}
