export const IOS_SPRING = {
  type: 'spring' as const,
  stiffness: 440,
  damping: 34,
  mass: 0.82,
}

export const IOS_SNAPPY_SPRING = {
  type: 'spring' as const,
  stiffness: 560,
  damping: 36,
  mass: 0.68,
}

export const IOS_SOFT_SPRING = {
  type: 'spring' as const,
  stiffness: 340,
  damping: 30,
  mass: 0.9,
}

export const IOS_SHEET_SPRING = {
  type: 'spring' as const,
  stiffness: 400,
  damping: 33,
  mass: 0.84,
}

export const IOS_LIQUID_SPRING = {
  type: 'spring' as const,
  stiffness: 490,
  damping: 32,
  mass: 0.74,
}

export const IOS_POPOVER_SPRING = {
  type: 'spring' as const,
  stiffness: 520,
  damping: 31,
  mass: 0.7,
}

export const IOS_SLIDER_SPRING = {
  type: 'spring' as const,
  stiffness: 580,
  damping: 34,
  mass: 0.6,
}

export const IOS_EASE = [0.22, 1, 0.36, 1] as const
