import { useCallback, useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import type { FormEvent, KeyboardEvent, PointerEvent as ReactPointerEvent } from 'react'
import {
  AnimatePresence,
  motion,
  useMotionValue,
  useReducedMotion,
  useSpring,
  useTransform,
} from 'motion/react'
import {
  ArrowUp,
  Check,
  ChevronDown,
  ChevronRight,
  Paperclip,
  Plus,
  Sparkles,
  X,
} from 'lucide-react'
import { byteLength, errorMessage } from './api'
import type { Attachment, Model } from './api'
import { Icon } from './icons'
import { AttachmentCard } from './AttachmentCard'
import { ProgressRing } from './ProgressRing'
import { prepareAttachment } from './attachmentReader'
import {
  APINEX_MODEL_ID,
  DEFAULT_SKILLS,
  EFFORT_LEVELS,
  GEMINI_FLASH_LITE_MODEL_ID,
  GEMINI_HYDROGEN_MODEL_ID,
  GEMINI_HYDROGEN_MODEL_NAME,
  LOCAL_PLAN_MODEL_NAME,
  NUMES_MODEL_ID,
  apinexMaxTokens,
  computeSliderRatio,
  effortFromRatio,
  effortIndex,
  effortStopRatio,
  formatModelDisplayName,
  geminiThinkingLabel,
  isCloudModelId,
  isGeminiModelId,
  isNumesModelId,
  modelForEffort,
  numesMaxTokens,
} from './composerLogic'
import type { EffortLevel, SkillItem } from './composerLogic'
import { MAX_ATTACHMENTS, MAX_TOTAL_FILE_BYTES } from './server/chatLogic'
import {
  IOS_EASE,
  IOS_LIQUID_SPRING,
  IOS_POPOVER_SPRING,
  IOS_SLIDER_SPRING,
  IOS_SNAPPY_SPRING,
} from './motion'

export const commands = [
  { name: '/new', description: 'เปิดแชตใหม่' },
  { name: '/models', description: 'เลือกโมเดล' },
  { name: '/undo', description: 'ย้อนข้อความล่าสุด' },
  { name: '/redo', description: 'คืนข้อความที่ย้อน' },
  { name: '/share', description: 'ดาวน์โหลดแชตเป็น Markdown' },
  { name: '/compact', description: 'ดูสรุปแชต' },
  { name: '/help', description: 'ดูคำสั่งทั้งหมด' },
] as const
export type Command = typeof commands[number]['name']

type Props = {
  busy: boolean
  ready: boolean
  draft: string
  files: Attachment[]
  model: string
  effort: EffortLevel
  skills: SkillItem[]
  models: Model[]
  onDraft(value: string): void
  onFiles(files: Attachment[]): void
  onModel(id: string): void
  onEffort(effort: EffortLevel): void
  onSkills(skills: SkillItem[]): void
  onSend(): void
  onCommand(command: Command): void
  onError(message: string): void
}

type PendingFile = { name: string; progress: number; file?: Attachment; failure?: string }

const ATTACHMENT_REVEAL_MS = 700

function DropHint({ target, reducedMotion }: { target: HTMLElement; reducedMotion: boolean }) {
  return createPortal(
    <motion.div className="stage-drop" aria-hidden="true"
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      transition={{ duration: reducedMotion ? 0 : 0.18, ease: IOS_EASE }}>
      <motion.div className="stage-drop-panel"
        initial={reducedMotion ? false : { y: 7, scale: 0.98 }} animate={{ y: 0, scale: 1 }}
        transition={{ duration: reducedMotion ? 0 : 0.23, ease: IOS_EASE }}>
        <span className="stage-drop-icon"><Icon name="plus" size={23} /></span>
        <strong>ปล่อยไฟล์เพื่อแนบ</strong>
        <small>รูปภาพ · ZIP · ไฟล์ข้อความ UTF-8</small>
      </motion.div>
    </motion.div>, target,
  )
}

export function Composer(props: Props) {
  const {
    busy,
    ready,
    draft,
    files,
    model,
    effort,
    skills,
    models,
    onDraft,
    onFiles,
    onModel,
    onEffort,
    onSkills,
    onSend,
    onCommand,
    onError,
  } = props
  const form = useRef<HTMLFormElement>(null)
  const input = useRef<HTMLTextAreaElement>(null)
  const picker = useRef<HTMLInputElement>(null)
  const plusButton = useRef<HTMLButtonElement>(null)
  const plusPopup = useRef<HTMLDivElement>(null)
  const popup = useRef<HTMLDivElement>(null)
  const modelButton = useRef<HTMLButtonElement>(null)
  const firstModel = useRef<HTMLButtonElement>(null)
  const sliderTrack = useRef<HTMLDivElement>(null)
  const [cursor, setCursor] = useState(0)
  const [active, setActive] = useState(0)
  const [focused, setFocused] = useState(false)
  const [dismissed, setDismissed] = useState(false)
  const [showPlusMenu, setShowPlusMenu] = useState(false)
  const [showSkillList, setShowSkillList] = useState(false)
  const [customSkillName, setCustomSkillName] = useState('')
  const [showModels, setShowModels] = useState(false)
  const [draggingEffort, setDraggingEffort] = useState(false)
  const [pending, setPending] = useState<PendingFile[]>([])
  const [dropTarget, setDropTarget] = useState<HTMLElement | null>(null)
  const upload = useRef<AbortController | null>(null)
  const reducedMotion = useReducedMotion() === true
  const rawEffortRatio = useMotionValue(effortStopRatio(effort))
  const smoothEffortRatio = useSpring(rawEffortRatio, {
    stiffness: reducedMotion ? 10000 : IOS_SLIDER_SPRING.stiffness,
    damping: reducedMotion ? 1000 : IOS_SLIDER_SPRING.damping,
    mass: reducedMotion ? 0.1 : IOS_SLIDER_SPRING.mass,
  })
  const thumbLeft = useTransform(smoothEffortRatio, r => `calc(3px + ${r} * (100% - 34px))`)
  const fillWidth = useTransform(smoothEffortRatio, r => `calc(16px + ${r} * (100% - 32px))`)
  const reading = pending.length > 0
  const blocked = busy || reading || !ready
  const sendLabel = reading ? 'กำลังเตรียมไฟล์แนบ' : 'ส่ง'

  useEffect(() => () => upload.current?.abort(), [])

  useEffect(() => {
    if (!draggingEffort) {
      rawEffortRatio.set(effortStopRatio(effort))
    }
  }, [draggingEffort, effort, rawEffortRatio])

  useEffect(() => {
    if (!showModels) return
    firstModel.current?.focus()
    function closeOutside(event: PointerEvent) {
      const target = event.target as Node
      if (!popup.current?.contains(target) && !modelButton.current?.contains(target)) {
        setShowModels(false)
      }
    }
    document.addEventListener('pointerdown', closeOutside)
    return () => document.removeEventListener('pointerdown', closeOutside)
  }, [showModels])

  useEffect(() => {
    if (!showPlusMenu) return
    function closeOutside(event: PointerEvent) {
      const target = event.target as Node
      if (!plusPopup.current?.contains(target) && !plusButton.current?.contains(target)) {
        setShowPlusMenu(false)
        setShowSkillList(false)
      }
    }
    document.addEventListener('pointerdown', closeOutside)
    return () => document.removeEventListener('pointerdown', closeOutside)
  }, [showPlusMenu])

  const token = draft.slice(0, cursor).match(/(?:^|\s)(\/\S*|@\S*)$/)?.[1]
  const isCommand = token?.startsWith('/') && token.length === cursor
  const fileOptions = [
    ...files.map(({ name }) => ({ name: '@' + name, description: 'ไฟล์แนบ' })),
    { name: '@', description: 'แนบไฟล์จากเครื่อง', picker: true },
  ]
  const options = focused && !dismissed && !showModels && !showPlusMenu && token && !blocked
    ? (isCommand ? commands : token.startsWith('@') ? fileOptions : []).filter(
        option => option.name.toLowerCase().startsWith(token.toLowerCase()),
      )
    : []
  const selectedIndex = Math.min(active, options.length - 1)
  const canSend = !blocked && Boolean(draft.trim() || files.length || skills.length)

  const displayModels: Model[] = models.filter(item => item.id !== 'workspace')
  const priorityOrder = [
    GEMINI_HYDROGEN_MODEL_ID,
    GEMINI_FLASH_LITE_MODEL_ID,
    NUMES_MODEL_ID,
    APINEX_MODEL_ID,
    'ai',
  ]
  const orderedModels: Model[] = displayModels.length
    ? [
        ...priorityOrder.flatMap(id => displayModels.filter(item => item.id === id)),
        ...displayModels.filter(item => !priorityOrder.includes(item.id)),
      ]
    : [{ id: GEMINI_HYDROGEN_MODEL_ID, name: GEMINI_HYDROGEN_MODEL_NAME }]
  const activeModel = orderedModels.find(item => item.id === model) ?? orderedModels[0]
  const isCloud = isCloudModelId(activeModel.id)
  const isGemini = isGeminiModelId(activeModel.id)
  const isNumes = isNumesModelId(activeModel.id)
  const isApinex = activeModel.id === APINEX_MODEL_ID
  const activeDisplay = formatModelDisplayName(activeModel)
  const activeEffortModel = modelForEffort(effort)

  function applyOption(index: number) {
    const choice = options[index]
    if (!choice || !token) return
    const before = draft.slice(0, cursor - token.length)
    const after = draft.slice(cursor)
    if ('picker' in choice) {
      onDraft(before + after)
      picker.current?.click()
    } else if (choice.name === '/models') {
      onDraft(after.trimStart())
      setShowModels(true)
    } else {
      const value = before + choice.name + ' ' + after
      const position = before.length + choice.name.length + 1
      onDraft(value)
      setCursor(position)
      requestAnimationFrame(() => input.current?.setSelectionRange(position, position))
    }
    setDismissed(true)
  }

  function submit(event?: FormEvent) {
    event?.preventDefault()
    if (blocked) return
    setDismissed(true)
    setShowModels(false)
    setShowPlusMenu(false)
    setShowSkillList(false)
    const command = commands.find(item => item.name === draft.trim())
    if (command?.name === '/models') {
      onDraft('')
      setShowModels(true)
      return
    }
    if (command) {
      onCommand(command.name)
      return
    }
    onSend()
  }

  function handleKeys(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.nativeEvent.isComposing) return
    if (options.length) {
      if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        event.preventDefault()
        setActive((selectedIndex + (event.key === 'ArrowDown' ? 1 : -1) + options.length) % options.length)
        return
      }
      if ((event.key === 'Tab' || event.key === 'Enter') && !event.shiftKey) {
        event.preventDefault()
        applyOption(selectedIndex)
        return
      }
      if (event.key === 'Escape') {
        event.preventDefault()
        setDismissed(true)
        return
      }
    }
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault()
      submit()
    }
  }

  function toggleSkill(skill: SkillItem) {
    const exists = skills.some(item => item.id === skill.id)
    if (exists) {
      onSkills(skills.filter(item => item.id !== skill.id))
    } else {
      onSkills([...skills, skill])
    }
  }

  function addCustomSkill() {
    const trimmed = customSkillName.trim()
    if (!trimmed) return
    const id = 'custom:' + trimmed.toLowerCase().replace(/\s+/g, '-')
    if (!skills.some(item => item.id === id)) {
      onSkills([
        ...skills,
        {
          id,
          label: trimmed,
          description: 'สกิลที่กำหนดเอง',
          instruction: `ใช้แนวทางและบทบาทของสกิล "${trimmed}" ในการตอบและวิเคราะห์`,
        },
      ])
    }
    setCustomSkillName('')
    setShowSkillList(false)
    setShowPlusMenu(false)
    input.current?.focus()
  }

  function scrubEffortFromClientX(clientX: number) {
    const track = sliderTrack.current
    if (!track) return
    const rect = track.getBoundingClientRect()
    const ratio = computeSliderRatio(clientX, rect.left, rect.width, 16)
    rawEffortRatio.set(ratio)
    const next = effortFromRatio(ratio)
    if (next !== effort) {
      onEffort(next)
    }
  }

  function handleSliderPointerDown(event: ReactPointerEvent<HTMLDivElement>) {
    if (blocked) return
    event.preventDefault()
    event.currentTarget.setPointerCapture(event.pointerId)
    setDraggingEffort(true)
    scrubEffortFromClientX(event.clientX)
  }

  function handleSliderPointerMove(event: ReactPointerEvent<HTMLDivElement>) {
    if (!draggingEffort) return
    scrubEffortFromClientX(event.clientX)
  }

  function handleSliderPointerUp(event: ReactPointerEvent<HTMLDivElement>) {
    if (!draggingEffort) return
    setDraggingEffort(false)
    rawEffortRatio.set(effortStopRatio(effort))
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId)
    }
  }

  const addFiles = useCallback(async (list: FileList | null) => {
    const chosen = Array.from(list ?? [])
    if (!chosen.length || blocked || upload.current) return
    if (files.length + chosen.length > MAX_ATTACHMENTS) {
      onError(`แนบได้สูงสุด ${MAX_ATTACHMENTS} ไฟล์ต่อข้อความ`)
      if (picker.current) picker.current.value = ''
      return
    }

    const batch = new AbortController()
    upload.current = batch
    const update = (index: number, patch: Partial<PendingFile>) => {
      if (!batch.signal.aborted) setPending(current => current.map((entry, i) =>
        i === index ? { ...entry, ...patch } : entry,
      ))
    }
    setPending(chosen.map(file => ({ name: file.name, progress: 0 })))
    // Keep one reveal window per batch while the actual file reads run immediately.
    const loadingVisible = reducedMotion ? Promise.resolve() :
      new Promise<void>(resolve => window.setTimeout(resolve, ATTACHMENT_REVEAL_MS))
    onError('')
    const attachments = [...files]
    const failures: string[] = []
    let bytes = files.reduce((total, file) => total + byteLength(file.content), 0)
    try {
      for (const [index, original] of chosen.entries()) {
        try {
          const file = await prepareAttachment(original, progress => update(index, { progress }), batch.signal)
          batch.signal.throwIfAborted()
          const length = byteLength(file.content)
          if (bytes + length > MAX_TOTAL_FILE_BYTES) {
            throw new Error(original.name + ' ทำให้ข้อมูลไฟล์แนบรวมเกิน 192 KiB')
          }
          bytes += length
          attachments.push(file)
          void loadingVisible.then(() => update(index, { file }))
        } catch (error) {
          if (batch.signal.aborted) return
          const failure = errorMessage(error)
          failures.push(failure)
          update(index, { failure })
        }
      }
      if (attachments.length > files.length) await loadingVisible
      if (batch.signal.aborted) return
      onFiles(attachments)
      if (failures.length) onError(failures.join(' · '))
    } finally {
      upload.current = null
      if (!batch.signal.aborted) {
        setPending([])
        if (picker.current) picker.current.value = ''
        input.current?.focus()
      }
    }
  }, [blocked, files, onFiles, onError, reducedMotion])

  useEffect(() => {
    const target = form.current?.closest<HTMLElement>('.stage') ?? form.current
    if (!target) return
    let depth = 0
    const hasFiles = (event: DragEvent) => event.dataTransfer?.types.includes('Files')
    const clear = () => {
      depth = 0
      setDropTarget(null)
    }
    const enter = (event: DragEvent) => {
      if (!hasFiles(event)) return
      event.preventDefault()
      depth += 1
      if (!blocked) setDropTarget(target)
    }
    const over = (event: DragEvent) => {
      if (!hasFiles(event)) return
      event.preventDefault()
      if (event.dataTransfer) event.dataTransfer.dropEffect = blocked ? 'none' : 'copy'
    }
    const leave = () => {
      depth = Math.max(0, depth - 1)
      if (!depth) clear()
    }
    const drop = (event: DragEvent) => {
      if (!hasFiles(event)) return
      event.preventDefault()
      clear()
      void addFiles(event.dataTransfer?.files ?? null)
    }
    target.addEventListener('dragenter', enter)
    target.addEventListener('dragover', over)
    target.addEventListener('dragleave', leave)
    target.addEventListener('drop', drop)
    window.addEventListener('dragend', clear)
    return () => {
      target.removeEventListener('dragenter', enter)
      target.removeEventListener('dragover', over)
      target.removeEventListener('dragleave', leave)
      target.removeEventListener('drop', drop)
      window.removeEventListener('dragend', clear)
    }
  }, [addFiles, blocked])

  const attachmentCounts = new Map<string, number>()
  const entries = [
    ...files.map((file, index) => ({ name: file.name, file, index, progress: undefined, failure: undefined })),
    ...pending.map(entry => ({ ...entry, index: undefined })),
  ].map(entry => {
    const count = (attachmentCounts.get(entry.name) ?? 0) + 1
    attachmentCounts.set(entry.name, count)
    return { ...entry, key: `${entry.name}#${count}` }
  })

  const activeEffortStep = effortIndex(effort)

  return <form className="composer" ref={form} onSubmit={submit}>
    <AnimatePresence>
      {!blocked && dropTarget && <DropHint key="drop-hint" target={dropTarget} reducedMotion={reducedMotion} />}
    </AnimatePresence>
    <AnimatePresence>
      {options.length > 0 && <motion.div
        key="suggestions"
        id="suggestions"
        className="picker suggestions"
        role="listbox"
        aria-label="คำแนะนำ"
        initial={reducedMotion ? false : { opacity: 0, y: 12, scale: 0.93, filter: 'blur(6px)' }}
        animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
        exit={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 8, scale: 0.95, filter: 'blur(4px)' }}
        transition={IOS_POPOVER_SPRING}
        style={{ transformOrigin: 'bottom center' }}
      >
        {options.map((option, index) => <div key={option.name} role="option"
          id={'suggestion-' + index} aria-selected={index === selectedIndex}
          onPointerDown={event => event.preventDefault()} onClick={() => applyOption(index)}
          className={'picker-option' + (index === selectedIndex ? ' selected' : '')}>
          <span className="option-name">{option.name}</span><span>{option.description}</span>
        </div>)}
      </motion.div>}
    </AnimatePresence>

    <AnimatePresence initial={false}>
      {entries.length > 0 && <motion.ul
        className="attachments"
        aria-label={`ไฟล์แนบ ${entries.length} รายการ`}
        tabIndex={0}
        initial={reducedMotion ? false : { height: 0, marginBottom: 0, opacity: 0 }}
        animate={{ height: 'auto', marginBottom: 8, opacity: 1 }}
        exit={reducedMotion ? { opacity: 0 } : { height: 0, marginBottom: 0, opacity: 0 }}
        transition={IOS_LIQUID_SPRING}
      >
        {entries.map(({ name, file, progress, failure, index, key }) => <motion.li
          key={key}
          initial={reducedMotion ? false : { opacity: 0, y: -6, scale: 0.94 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={IOS_LIQUID_SPRING}
        >
          <AttachmentCard name={name} preview={file?.preview}
            progress={file || failure ? undefined : progress} failure={failure} />
          {index !== undefined && <button type="button" aria-label={'เอา ' + name + ' ออก'} disabled={blocked}
            onClick={() => onFiles(files.filter((_, item) => item !== index))}><Icon name="close" size={13} /></button>}
        </motion.li>)}
      </motion.ul>}
    </AnimatePresence>

    <AnimatePresence initial={false}>
      {skills.length > 0 && (
        <motion.div
          className="composer-skills"
          aria-label="สกิลที่เปิดใช้งาน"
          initial={reducedMotion ? false : { opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={reducedMotion ? { opacity: 0 } : { opacity: 0, height: 0 }}
          transition={IOS_LIQUID_SPRING}
        >
          <AnimatePresence initial={false}>
            {skills.map(skill => (
              <motion.span
                key={skill.id}
                layout={!reducedMotion}
                className="composer-skill-chip"
                initial={reducedMotion ? false : { opacity: 0, scale: 0.85, y: 4 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={reducedMotion ? { opacity: 0 } : { opacity: 0, scale: 0.85, y: -2 }}
                transition={IOS_LIQUID_SPRING}
              >
                <Sparkles size={12} aria-hidden="true" />
                <span>{skill.label}</span>
                <button
                  type="button"
                  aria-label={`เอาสกิล ${skill.label} ออก`}
                  disabled={blocked}
                  onClick={() => onSkills(skills.filter(item => item.id !== skill.id))}
                >
                  <X size={11} />
                </button>
              </motion.span>
            ))}
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>

    <span className="sr-only" role="status">{reading ? 'กำลังอ่านไฟล์แนบ' : ''}</span>
    <label className="sr-only" htmlFor="prompt">ข้อความ</label>
    <textarea id="prompt" ref={input} value={draft} rows={2} maxLength={12000}
      disabled={busy || !ready} aria-autocomplete="list"
      aria-controls={options.length ? 'suggestions' : undefined}
      aria-activedescendant={options.length ? 'suggestion-' + selectedIndex : undefined}
      placeholder="Send a Message"
      onChange={event => {
        onDraft(event.target.value)
        setCursor(event.target.selectionStart)
        setActive(0)
        setDismissed(false)
      }}
      onSelect={event => setCursor(event.currentTarget.selectionStart)}
      onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} onKeyDown={handleKeys} />

    <div className="tools">
      <input ref={picker} type="file" multiple hidden onChange={event => void addFiles(event.target.files)} />

      <div className="plus-wrapper">
        <motion.button
          ref={plusButton}
          className="composer-circle-btn"
          type="button"
          aria-label={showPlusMenu ? 'ปิดเมนูแนบและสกิล' : 'เปิดเมนูแนบและสกิล'}
          aria-expanded={showPlusMenu}
          aria-controls="plus-menu"
          disabled={blocked}
          whileTap={blocked ? undefined : { scale: 0.88 }}
          transition={IOS_SNAPPY_SPRING}
          onClick={() => {
            setShowModels(false)
            setShowPlusMenu(prev => {
              if (prev) setShowSkillList(false)
              return !prev
            })
          }}
        >
          <motion.span
            className="inline-grid place-items-center"
            animate={{ rotate: showPlusMenu ? 45 : 0 }}
            transition={IOS_LIQUID_SPRING}
          >
            <Plus size={16} />
          </motion.span>
        </motion.button>

        <AnimatePresence>
          {showPlusMenu && (
            <motion.div
              key="plus-menu"
              id="plus-menu"
              ref={plusPopup}
              role="menu"
              aria-label="เพิ่มไฟล์หรือสกิล"
              className="picker plus-picker"
              initial={reducedMotion ? false : { opacity: 0, y: 12, scale: 0.9, filter: 'blur(6px)' }}
              animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
              exit={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 8, scale: 0.93, filter: 'blur(4px)' }}
              transition={IOS_POPOVER_SPRING}
              style={{ transformOrigin: 'bottom left' }}
              onKeyDown={event => {
                if (event.key === 'Escape') {
                  setShowPlusMenu(false)
                  setShowSkillList(false)
                  plusButton.current?.focus()
                }
              }}
            >
              <AnimatePresence mode="wait" initial={false}>
                {!showSkillList ? (
                  <motion.div
                    key="plus-root"
                    initial={reducedMotion ? false : { opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={reducedMotion ? { opacity: 0 } : { opacity: 0, x: -10 }}
                    transition={IOS_LIQUID_SPRING}
                  >
                    <button
                      type="button"
                      role="menuitem"
                      className="picker-option plus-picker-item"
                      onClick={() => setShowSkillList(true)}
                    >
                      <span className="plus-item-left">
                        <Sparkles size={15} aria-hidden="true" />
                        <span>เพิ่มสกิล</span>
                      </span>
                      <ChevronRight size={14} className="plus-item-arrow" aria-hidden="true" />
                    </button>
                    <button
                      type="button"
                      role="menuitem"
                      className="picker-option plus-picker-item"
                      onClick={() => {
                        setShowPlusMenu(false)
                        setShowSkillList(false)
                        picker.current?.click()
                      }}
                    >
                      <span className="plus-item-left">
                        <Paperclip size={15} aria-hidden="true" />
                        <span>อัปโหลดไฟล์</span>
                      </span>
                    </button>
                  </motion.div>
                ) : (
                  <motion.div
                    key="plus-skills"
                    className="skill-submenu"
                    initial={reducedMotion ? false : { opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={reducedMotion ? { opacity: 0 } : { opacity: 0, x: 10 }}
                    transition={IOS_LIQUID_SPRING}
                  >
                    <div className="skill-submenu-head">
                      <button
                        type="button"
                        className="skill-back-btn"
                        onClick={() => setShowSkillList(false)}
                      >
                        ← กลับ
                      </button>
                      <span>เลือกสกิล</span>
                    </div>
                    <div className="skill-submenu-list">
                      {DEFAULT_SKILLS.map(skill => {
                        const activeSkill = skills.some(item => item.id === skill.id)
                        return (
                          <button
                            key={skill.id}
                            type="button"
                            className={'picker-option skill-option' + (activeSkill ? ' selected' : '')}
                            aria-pressed={activeSkill}
                            onClick={() => toggleSkill(skill)}
                          >
                            <span className="skill-option-text">
                              <strong>{skill.label}</strong>
                              <small>{skill.description}</small>
                            </span>
                            {activeSkill && <Check size={14} aria-hidden="true" />}
                          </button>
                        )
                      })}
                    </div>
                    <div className="skill-custom-row">
                      <label htmlFor="custom-skill-input" className="sr-only">
                        เพิ่มชื่อสกิลเอง
                      </label>
                      <input
                        id="custom-skill-input"
                        type="text"
                        value={customSkillName}
                        maxLength={40}
                        placeholder="พิมพ์ชื่อสกิล..."
                        onChange={event => setCustomSkillName(event.target.value)}
                        onKeyDown={event => {
                          if (event.key === 'Enter') {
                            event.preventDefault()
                            addCustomSkill()
                          }
                        }}
                      />
                      <button
                        type="button"
                        disabled={!customSkillName.trim()}
                        onClick={addCustomSkill}
                      >
                        เพิ่ม
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="tools-right">
        <div className="model-wrapper">
          <motion.button
            type="button"
            className="model-button"
            aria-expanded={showModels}
            aria-controls="models"
            ref={modelButton}
            disabled={blocked}
            whileTap={blocked ? undefined : { scale: 0.96 }}
            transition={IOS_SNAPPY_SPRING}
            onClick={() => {
              setShowPlusMenu(false)
              setShowSkillList(false)
              setShowModels(prev => !prev)
            }}
          >
            <span className="model-trigger-name">{activeDisplay.title}</span>
            <span className="model-trigger-effort-wrap">
              <AnimatePresence mode="popLayout" initial={false}>
                <motion.span
                  key={isCloud ? `cloud-${effort}` : effort}
                  className="model-trigger-effort"
                  initial={reducedMotion ? false : { opacity: 0, y: 5, filter: 'blur(2px)' }}
                  animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                  exit={reducedMotion ? { opacity: 0 } : { opacity: 0, y: -5, filter: 'blur(2px)' }}
                  transition={IOS_LIQUID_SPRING}
                >
                  {isCloud ? `${effort} · Free` : `${effort} · ${activeEffortModel.approxDownload}`}
                </motion.span>
              </AnimatePresence>
            </span>
            <motion.span
              className="model-trigger-chevron inline-grid place-items-center"
              animate={{ rotate: showModels ? 180 : 0 }}
              transition={IOS_LIQUID_SPRING}
              aria-hidden="true"
            >
              <ChevronDown size={13} />
            </motion.span>
          </motion.button>

          <AnimatePresence>
            {showModels && (
              <motion.div
                key="models"
                id="models"
                className="picker model-picker"
                ref={popup}
                role="group"
                aria-label="เลือกโมเดลและระดับ Effort"
                initial={reducedMotion ? false : { opacity: 0, y: 12, scale: 0.9, filter: 'blur(6px)' }}
                animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
                exit={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 8, scale: 0.93, filter: 'blur(4px)' }}
                transition={IOS_POPOVER_SPRING}
                style={{ transformOrigin: 'bottom right' }}
                onKeyDown={event => {
                  if (event.key === 'Escape') {
                    setShowModels(false)
                    modelButton.current?.focus()
                  }
                }}
              >
                <div className="model-list">
                  {orderedModels.map((item, index) => {
                    const display = formatModelDisplayName(item)
                    const selected = item.id === model
                    return (
                      <button
                        type="button"
                        key={item.id}
                        ref={index === 0 ? firstModel : undefined}
                        className={'picker-option model-option' + (selected ? ' selected' : '')}
                        aria-pressed={selected}
                        onClick={() => {
                          onModel(item.id)
                        }}
                      >
                        <span className="model-option-label">
                          <span>{display.title}</span>
                          {display.badge && (
                            <span className="model-option-badge">{display.badge}</span>
                          )}
                        </span>
                        {selected && <Check size={14} aria-hidden="true" />}
                      </button>
                    )
                  })}
                </div>

                <div className="effort-divider" />

                <div className="effort-section">
                  <div className="effort-header">
                    <div className="effort-header-left">
                      <span className="effort-label">Effort</span>
                      <span className="effort-value">{effort}</span>
                    </div>
                    <span className="effort-model-meta">
                      {isGemini
                        ? `Thinking · ${geminiThinkingLabel(activeModel.id, effort)}`
                        : isNumes
                          ? `DeepSeek V4.1 · ${numesMaxTokens(effort)} tok`
                          : isApinex
                            ? `GLM-5.3X · ${apinexMaxTokens(effort)} tok`
                            : `พื้นที่โหลด ${activeEffortModel.approxDownload}`}
                    </span>
                  </div>
                  <div
                    ref={sliderTrack}
                    role="slider"
                    tabIndex={0}
                    aria-label="ระดับ Effort"
                    aria-valuemin={0}
                    aria-valuemax={EFFORT_LEVELS.length - 1}
                    aria-valuenow={activeEffortStep}
                    aria-valuetext={`${effort} · ${isCloud ? activeDisplay.title : `${LOCAL_PLAN_MODEL_NAME} · พื้นที่โหลด ${activeEffortModel.approxDownload}`}`}
                    className={'effort-slider' + (draggingEffort ? ' dragging' : '')}
                    onPointerDown={handleSliderPointerDown}
                    onPointerMove={handleSliderPointerMove}
                    onPointerUp={handleSliderPointerUp}
                    onPointerCancel={handleSliderPointerUp}
                    onKeyDown={event => {
                      if (event.key === 'ArrowRight' || event.key === 'ArrowUp') {
                        event.preventDefault()
                        const next = Math.min(EFFORT_LEVELS.length - 1, activeEffortStep + 1)
                        onEffort(EFFORT_LEVELS[next])
                      } else if (event.key === 'ArrowLeft' || event.key === 'ArrowDown') {
                        event.preventDefault()
                        const next = Math.max(0, activeEffortStep - 1)
                        onEffort(EFFORT_LEVELS[next])
                      }
                    }}
                  >
                    <motion.div
                      className="effort-fill"
                      aria-hidden="true"
                      style={{ width: fillWidth }}
                    />
                    <div className="effort-ticks" aria-hidden="true">
                      {EFFORT_LEVELS.map((level, idx) => (
                        <span
                          key={level}
                          className={
                            'effort-tick' +
                            (idx <= activeEffortStep ? ' passed' : '') +
                            (level === effort ? ' active' : '')
                          }
                        />
                      ))}
                    </div>
                    <motion.div
                      className="effort-thumb"
                      animate={{
                        scale: draggingEffort ? 1.08 : 1,
                      }}
                      transition={IOS_SLIDER_SPRING}
                      style={{ left: thumbLeft }}
                    />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <motion.button
          className={'send-button' + (reading ? ' send-button-loading' : '')}
          title={sendLabel}
          aria-label={sendLabel}
          disabled={!canSend}
          animate={{ scale: canSend || reading ? 1 : 0.96 }}
          whileTap={canSend ? { scale: 0.9 } : undefined}
          transition={IOS_SNAPPY_SPRING}
        >
          <AnimatePresence initial={false}>
            <motion.span key={reading ? 'loading' : 'send'} className="send-button-icon" aria-hidden="true"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              transition={{ duration: reducedMotion ? 0 : 0.16, ease: IOS_EASE }}>
              {reading ? <ProgressRing /> : <ArrowUp size={15} strokeWidth={2.2} />}
            </motion.span>
          </AnimatePresence>
        </motion.button>
      </div>
    </div>
  </form>
}
