import { useState } from 'react'
import type { ReactNode } from 'react'
import { motion } from 'motion/react'
import type { BillingCycle, ChatSummary, ContentChange, PlanId, Workspace } from './api'
import { FileText, Monitor } from './icons'
import { IOS_EASE } from './motion'
import type { Navigate, WorkspaceRoute } from './navigation'
import type { ContentAction } from './workspaceContent'
import { SubscriptionPage } from './SubscriptionPage'

type PageProps = {
  route: WorkspaceRoute
  workspace: Workspace
  busy: boolean
  error: string
  navigate: Navigate
  onOpenChat(chat: ChatSummary): void
  onNewChat(model?: string): void
  onUpdate(action: ContentAction): Promise<ContentChange | undefined>
  onSelectPlan(plan: PlanId, billingCycle: BillingCycle): Promise<boolean>
}

function PageHeader({ title, description, action }: { title: string; description?: string; action?: ReactNode }) {
  return <header className="chat-library-header workspace-header">
    <div><h1>{title}</h1>{description && <p>{description}</p>}</div>
    {action}
  </header>
}

function Row({ icon: Icon, title, description, onClick }: {
  icon: typeof FileText; title: string; description?: string; onClick(): void
}) {
  return <button type="button" className="workspace-row" onClick={onClick}>
    <span className="workspace-row-icon"><Icon size={20} /></span>
    <span className="workspace-row-title"><b>{title}</b>{description && <small>{description}</small>}</span>
  </button>
}

function PluginsPage({ onNewChat }: Pick<PageProps, 'onNewChat'>) {
  const [json, setJson] = useState('')
  const [valid, setValid] = useState(false)
  const [formatError, setFormatError] = useState('')

  function formatJson() {
    try {
      setJson(JSON.stringify(JSON.parse(json), null, 2))
      setFormatError('')
      setValid(true)
    } catch {
      setFormatError('รูปแบบ JSON ไม่ถูกต้อง')
      setValid(false)
    }
  }

  return <>
    <PageHeader title="ปลั๊กอิน" description="เครื่องมือที่ใช้งานได้ใน OPENSPEC" />
    <div className="workspace-list">
      <Row icon={FileText} title="วิเคราะห์ไฟล์อัตโนมัติ" description="แนบไฟล์ในแชตเพื่อตรวจโครงสร้าง ดูสถิติ และหา TODO/FIXME อัตโนมัติ"
        onClick={() => onNewChat('ai')} />
      <Row icon={Monitor} title="Plan Free · AI จากเครื่อง" description="เปิดแชตด้วยโมเดลที่ทำงานในเบราว์เซอร์"
        onClick={() => onNewChat('ai')} />
    </div>
    <section className="workspace-form" aria-labelledby="json-tool-title">
      <h2 id="json-tool-title">จัดรูปแบบ JSON</h2>
      <label htmlFor="plugin-json">ข้อมูล JSON</label>
      <textarea id="plugin-json" value={json} rows={7} maxLength={65536}
        onChange={event => { setJson(event.target.value); setValid(false); setFormatError('') }} />
      {formatError && <p className="error" role="alert">{formatError}</p>}
      {valid && <p role="status">JSON ถูกต้อง</p>}
      <div className="workspace-actions">
        <button type="button" className="tool-action tool-action-primary" disabled={!json.trim()} onClick={formatJson}>จัดรูปแบบ</button>
      </div>
    </section>
  </>
}

export function WorkspacePages(props: PageProps) {
  const { route, error, workspace, busy, onSelectPlan } = props
  const isSubscription = route.section === 'subscription'

  if (isSubscription) {
    return (
      <SubscriptionPage
        workspace={workspace}
        busy={busy}
        error={error}
        onSelectPlan={onSelectPlan}
      />
    )
  }

  return <div className="oc-page">
    <motion.section className="workspace-page" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
      transition={{ duration: 0.18, ease: IOS_EASE }}>
      {error && <p className="error" role="alert">{error}</p>}
      <PluginsPage onNewChat={props.onNewChat} />
    </motion.section>
  </div>
}
