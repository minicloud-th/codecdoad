export type AttachmentPreview =
  | { kind: 'text'; size: number }
  | { kind: 'image'; size: number; thumbnail: string; width: number; height: number }
  | { kind: 'archive'; size: number; entries: number; extracted: number }

export function attachmentExtension(name: string) {
  return /\.([a-z0-9]{1,10})$/i.exec(name)?.[1].toLowerCase() ?? ''
}

const imageExtensions = new Set(['png', 'jpg', 'jpeg', 'gif', 'webp'])

export function hasImageExtension(name: string) {
  return imageExtensions.has(attachmentExtension(name))
}

export function formatAttachmentSize(bytes: number) {
  if (bytes < 1024) return `${bytes} ${bytes === 1 ? 'Byte' : 'Bytes'}`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`
}
