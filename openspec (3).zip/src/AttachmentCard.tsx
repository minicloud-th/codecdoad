import { CodeXml, File, FileArchive, FileCode, FileJson, FileSpreadsheet, FileText } from 'lucide-react'
import type { ComponentType } from 'react'
import type { AttachmentPreview } from './attachmentTypes'
import { attachmentExtension, formatAttachmentSize, hasImageExtension } from './attachmentTypes'
import { ProgressRing } from './ProgressRing'

function ScriptFileIcon({ strokeWidth }: { strokeWidth: number }) {
  return <><File strokeWidth={strokeWidth} /><CodeXml className="attachment-code-mark" strokeWidth={1.6} /></>
}

const fileIcons: Record<string, ComponentType<{ strokeWidth: number }>> = {
  zip: FileArchive,
  html: FileCode, xml: FileCode, svg: FileCode, css: FileCode, scss: FileCode,
  js: ScriptFileIcon, jsx: ScriptFileIcon, ts: ScriptFileIcon, tsx: ScriptFileIcon, py: ScriptFileIcon,
  go: ScriptFileIcon, rs: ScriptFileIcon, java: ScriptFileIcon, kt: ScriptFileIcon,
  c: ScriptFileIcon, cpp: ScriptFileIcon, cs: ScriptFileIcon, php: ScriptFileIcon, rb: ScriptFileIcon, sh: ScriptFileIcon,
  json: FileJson, yaml: FileJson, yml: FileJson, toml: FileJson,
  csv: FileSpreadsheet, tsv: FileSpreadsheet,
}

export function AttachmentCard({ name, preview, progress, failure }: {
  name: string
  preview?: AttachmentPreview
  progress?: number
  failure?: string
}) {
  const ext = attachmentExtension(name)
  const isReading = progress !== undefined
  const isImage = preview?.kind === 'image' || (isReading && hasImageExtension(name))
  const label = ext ? name.slice(0, -(ext.length + 1)) || name : name
  const type = ext.toUpperCase() || 'TXT'
  const TypeIcon = fileIcons[ext] ?? FileText
  const note = failure ?? (isReading
    ? `${progress}%`
    : preview?.kind === 'image' ? `${preview.width} × ${preview.height}`
      : preview ? `${type} ${formatAttachmentSize(preview.size)}` : type)

  return (
    <div className={'attachment-card' + (isImage ? ' attachment-card-image' : '')}
      data-reading={isReading || undefined} title={name + ' · ' + note}>
      {preview?.kind === 'image'
        ? <img className="attachment-thumb" src={preview.thumbnail} alt="" />
        : isImage
          ? <span className="attachment-image-loading" aria-hidden="true">
              <ProgressRing />
              <span className="attachment-image-percent">{note}</span>
            </span>
          : <span className="attachment-type" aria-hidden="true"><TypeIcon strokeWidth={1.1} /></span>}
      <span className={'attachment-info' + (isImage ? ' sr-only' : '')}>
        <span className="attachment-name">{isImage ? name : label}</span>
        <small key={isReading ? 'reading' : 'ready'}
          className={'attachment-meta' + (isReading ? ' attachment-meta-loading' : '')}>
          {isReading && !isImage && <ProgressRing />}
          {isReading && <span className="sr-only">กำลังอ่านไฟล์ </span>}
          <span>{note}</span>
        </small>
      </span>
    </div>
  )
}
