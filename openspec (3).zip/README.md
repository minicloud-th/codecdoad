# OPENSPEC

หน้าแชตใช้ React และ TypeScript บน ChatGPT Sites และรัน Qwen3 0.6B บนเบราว์เซอร์ด้วย WebAssembly ไม่ต้องตั้ง runtime environment variables เพื่อแชตหรือวิเคราะห์ไฟล์ใน Workspace

Workspace รุ่นใหม่เก็บข้อมูลใน IndexedDB ของเบราว์เซอร์เดิม ต้องลงชื่อเข้าใช้ด้วย Firebase ก่อนเปิด Workspace ประวัติจากโหมดเดิมในเบราว์เซอร์และ D1 จะย้ายเข้าบัญชีแรกที่ลงชื่อเข้าใช้บนเบราว์เซอร์เดิม API เดิมยังให้บริการผ่าน Go และ Rust WebAssembly บน Worker

## สร้างเวอร์ชัน ChatGPT Sites

ใช้ Node.js 22.12 ขึ้นไป Go 1.24 ขึ้นไป และ Rust 1.86 ขึ้นไปพร้อม target `wasm32-unknown-unknown`

```sh
npm --prefix web ci
npm run build
```

Worker อยู่ที่ `dist/server/index.js` พร้อมไฟล์ที่ใช้เผยแพร่ใน `dist/` และใช้ D1 binding เดิมชื่อ `DB` เพื่อรองรับประวัติจากเวอร์ชันก่อน

## รันหน้าเว็บในเครื่อง

```sh
npm --prefix web ci
npm --prefix web run dev
```

โหมด AI ดาวน์โหลดโมเดลประมาณ 400 MB ในการใช้ครั้งแรก โหมด Workspace ใช้วิเคราะห์ไฟล์ทันที การลงชื่อเข้าใช้ Google ในตัวแอปต้องเพิ่มโดเมนจริงใน Firebase Authorized domains

## ไอคอน

ไอคอนในแอปใช้ไฟล์ SVG จาก [Google Material Symbols Rounded](https://github.com/google/material-design-icons/tree/10ecc14790612ca8fd164e3f4ffe9c16fc50d5b7/symbols/web) ภายใต้ [Apache License 2.0](web/public/google-icons/LICENSE.txt) เครื่องหมายบนปุ่มลงชื่อเข้าใช้มาจาก [ชุดไฟล์ Google Identity](https://developers.google.com/identity/branding-guidelines) และใช้สำหรับปุ่มลงชื่อเข้าใช้ด้วย Google
